var dealerId=new Array();
$(function() {
	$.ajax({
				url : "broker/dealerCompare",
				type : 'get',
				success : function(date) {
					date = eval("(" + date + ")");
					var dealerList = date.dealerList;
					var hdTitleHtml = "<td class='col-titl'></td>";
					var mrTitleHtml = "<tr class='first-row'><td class='col-titl'></td>";
					var contenrHtml = "";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
							if (dealerList[i]!= null) {
								hdTitleHtml += "<td class='col-item'>"
										+ "<div class='hd-item-wrap'>"
										+ "<a style='text-align: center;' href='broker/detail/"+dealerList[i].dealerId+"' target='_blank' class='a_detail_css'>"+dealerList[i].name+dealerList[i].chnName+"</a>"
										+ "<div class='item-logo'><img style='border: 1px solid #e3e3e3;width: 118px;height: initial;' src='showFile?url="
										+ dealerList[i].logoUrl + "' alt=''></div>"
										+ "<a class='remove-item' value='"+dealerList[i].dealerId+"'></a>" + "</div>"
										+ "</td>";
								mrTitleHtml += "<td class='col-item'>"
										+ "<a target='_blank' href='broker/detail/"+dealerList[i].dealerId+"''><p class='item-name'>"+dealerList[i].name+dealerList[i].chnName+"</p></a>"
										+ "<div class='item-logo' style='margin: 10px auto;'>" + "<img style='border: 1px solid #e3e3e3;width: 168px;height: initial;' src='showFile?url="
										+ dealerList[i].logoUrl + "' alt=''>"
										+ "<a class='remove-item' value='"+dealerList[i].dealerId+"'></a>" + "</div>"
										+ "</td>";
							} else {
										hdTitleHtml += "<td class='col-item'>"
												+ "<div class='hd-item-wrap'>"
												+ "<a class='add-item' href='broker/home'><img src='resources/images/broker-list/icon-add-24.png' alt=''></a>"
												+ "<a class='add-item-titl' href='broker/home'>添加交易商</a>"
												+ "</div>" + "</td>";
										mrTitleHtml += "<td class='col-item '>"
												+ "<a href='broker/home'><p class='item-name'>选择另一家交易商比较</p></a>"
												+ "<a class='add-item'  style='margin: 10px auto;'  href='broker/home'><img src='resources/images/broker-list/icon-add-31.png' alt=''></a>"
												+ "</td>";
									}
						}else {
							hdTitleHtml += "<td class='col-item'>"
									+ "<div class='hd-item-wrap'>"
									+ "<a class='add-item' href='broker/home'><img src='resources/images/broker-list/icon-add-24.png' alt=''></a>"
									+ "<a class='add-item-titl' href='broker/home'>添加交易商</a>"
									+ "</div>" + "</td>";
							mrTitleHtml += "<td class='col-item '>"
									+ "<a href='broker/home'><p class='item-name'>选择另一家交易商比较</p></a>"
									+ "<a class='add-item' href='broker/home'><img src='resources/images/broker-list/icon-add-31.png' alt=''></a>"
									+ "</td>";
						}
					}
					contenrHtml += mrTitleHtml;
					contenrHtml += "<tr class='second-row'>"
							+ "<td class='col-titl' colspan='2' style='font-size: 18px;font-weight: bold;'>平台返现</td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>" + "</tr>";
					contenrHtml += "<tr>" + "<td class='col-titl'>返现周期</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
								if (dealerList[i] != null) {
								contenrHtml += "<td class='col-item'>"
										+ changeNull(dealerList[i].rebatePeriodTypeName)
										+ "</td>";
								} else {
									contenrHtml += "<td class='col-item'></td>";
								}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>外汇返佣</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
								if (dealerList[i] != null) {
								contenrHtml += "<td class='col-item'>"
										+ changeNull(dealerList[i].forexRatio )+ "</td>";
								} else {
									contenrHtml += "<td class='col-item'></td>";
								}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>黄金返佣</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
							if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].goldRatio )+ "</td>";
								} else {
									contenrHtml += "<td class='col-item'></td>";
								}
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>白银返佣</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].silverRatio )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>原油返佣</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].crudeOilRatio )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>返佣持仓限制</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
							if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].positionLimit )+ "</td>";
							} else {
								contenrHtml += "<td class='col-item'></td>";
							}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl' colspan='2' style='font-size: 18px;font-weight: bold;'>交易点差及利息</td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>点差类型</td>";
					for (var i = 0; i < 4; i++) {				
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].pipsType )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>欧美点差</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].occidentPips )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>黄金点差</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].goldPips )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>原油点差</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].crudeOilPips )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>离岸人民币点差</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){
							if (dealerList[i] != null) {
						
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].cnh )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}
						}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>A股指数点差</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].aShareIndex )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>隔夜利息</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].rollovers )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl' colspan='2' style='font-size: 18px;font-weight: bold;'>平台模式</td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>平台模式</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].platformMode )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}}else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>平台类型</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].platformType )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>交易品种</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].transactionType )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>最低入金金额</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].minMoney )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>最大杠杆</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].maxLeverage )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>最小手数</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].tradeMinAmount )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>最大交易量</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].maxBusiness )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>爆仓比例</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].explosionra )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>剥头皮</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].scalp )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>" + "<td class='col-titl'>对冲</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].hedging )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl' colspan='2' style='font-size: 18px;font-weight: bold;'>平台出入金</td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>人民币出入金</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].rmbInOut )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>出入金方式</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].inOutWays )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>入金手续费</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].inFee )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>出金手续费</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].outFee )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>入金到账周期</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].inTransferCycle )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>出金到账周期</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].outTransferCycle )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>账户结算币种</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].closeCurrency )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl' colspan='2' style='font-size: 18px;font-weight: bold;'>平台信息</td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
							+ "<td class='col-titl'></td>"
					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>平台成立时间</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].foundingTime)+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>" + "<td class='col-titl'>语言</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].language )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>公司名称</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].companyName)+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>官方网站</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].websiteUrl )+ "</td>";
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}

					contenrHtml += "</tr><tr>"
							+ "<td class='col-titl'>监管机构</td>";
					for (var i = 0; i < 4; i++) {
						if(dealerList!=null){   
							if (dealerList[i] != null) {
							contenrHtml += "<td class='col-item'>"
									+ changeNull(dealerList[i].regulatoryOrg )+ "</td>";
							} else {
								contenrHtml += "<td class='col-item'></td>";
							}
						} else {
							contenrHtml += "<td class='col-item'></td>";
						}
					}
					contenrHtml += "</tr>";
					$("#hd_title").html(hdTitleHtml);
					$("#dealer_content").html(contenrHtml);
				}
			});
	
	$("#compare_broker").on("click",".remove-item",function(event){// 移除item
		event.preventDefault();
		var id=$(this).attr("value");
		var dealerItem=getCookieValue("dealerItem");
		if(null!=dealerItem){
			var cookieArr=dealerItem.split(",");
			for(var i=0;i<cookieArr.length-1;i++){
				dealerId[i]=new Array();
				dealerId[i][0]=cookieArr[i].split("||")[0];
				dealerId[i][1]=cookieArr[i].split("||")[1];
			}
		}
		removeByValue(dealerId,id);
		addCookieDealer();
		window.location.reload();
	});

});


function addCookieDealer(){
	var str="";
	for(var i=0;i<dealerId.length;i++){
		str+=dealerId[i][0]+"||"+dealerId[i][1]+",";
	}
	addCookie("dealerItem",str,0);
}


function removeByValue(arr, val) {
  for(var i=0; i<arr.length; i++) {
	  if(arr[i][0]== val) {
	      arr.splice(i, 1);
	      break;
	  }
  }
}

function changeNull(object){
	object=$.trim(object);
	  if(object==null||object=="null"||object==""||object==" "){
		  object="--";
	  }
	  return object;
}

function changeDate(mydate){// 将当前时间转换成yyyy-mm-dd格式
	if(mydate==null||mydate=="null"||mydate==""||mydate==" "){
		return null;
	}
	var mydate=new Date(mydate);
    var str = "" + mydate.getFullYear();
    var mm = mydate.getMonth()+1
    if(mydate.getMonth()>9){
     str += "-"+mm;
    }
    else{
     str += "-0" + mm;
    }
    if(mydate.getDate()>9){
     str += "-"+mydate.getDate();
    }
    else{
     str += "-0" + mydate.getDate();
    }
    return str;
  }