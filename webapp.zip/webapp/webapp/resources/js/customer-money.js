var offset=0;
var limit = 10;
var currentPage = 1;
var moneytype = "money";
function loadData(num,total){
	var myPageCount = total;//分页的总页数
    var myPageSize = limit;//分页的展示条数
    var countindex = Math.ceil(myPageCount/myPageSize);
    loadpage(countindex,myPageCount,num);
}

function loadpage(countindex,myPageCount,num) {
    $.jqPaginator('#pagination', {
        totalPages: countindex,
        visiblePages: 5,
        currentPage: 1,
        first: '<li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',
        onPageChange: function (num, type) {
            if (type == "change") {
            	currentPage  = num;
            	offset = limit * (num-1);
            	searchFlow(moneytype);
            	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
            	$(window).scrollTop($("table").offset().top);
            }
        }
    });
	$("#pagination").jqPaginator('option', { 
		totalPages: countindex,
		totalCounts:myPageCount,
	});
	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
}

function searchbtn(type){
	offset=0;
	limit = 10;
	currentPage = 1;
	searchFlow(type);
}

function searchFlow(type){
	moneytype = type;
	if($("#starttime").val()=='' && $("#endtime").val()!=''){
		$("#starttime").focus();
		return false;
	}
	if($("#starttime").val()!='' && $("#endtime").val()==''){
		$("#endtime").focus();
		return false;
	}
	var wSearchParms = {};
	wSearchParms.starttime=$("#starttime").val();
	wSearchParms.endtime=$("#endtime").val();
	wSearchParms.offset = offset;
	wSearchParms.limit  = limit;
	if(type=="money"){
		wSearchParms.moneyType = "money";
		wSearchParms.tradeType=$("#incomeType").val();
		wSearchParms.dealerId=$("#dealer").val();
	}else if(type=="rebate"){
		wSearchParms.moneyType = "rebate";
		wSearchParms.dealerId=$("#dealer").val();
	}else if(type=="withdrawl"){
		wSearchParms.moneyType = "withdrawl";
		wSearchParms.currency=$("#currency").val();
		wSearchParms.tradeStatus=$("#statusType").val();
	}
	$.ajax({
		type: "POST",
	    url: "customer/money/flowing",
        dataType:"json",
        contentType:"application/json", 
	    async:false,//取消异步请求
	    data: JSON.stringify(wSearchParms),
	    success:function(r){
	    	var flowings = eval(r.cFlowings);
	    	var total = eval(r.total);
	    	var html="";
	    	if(flowings==null||flowings.length == 0){
	    		html+="<span style='font-size: 16px;position: absolute;left: 45%;top: 50%;'>还没有记录</span>";
	    		$("#pageInfo").html('');
	    		$.jqPaginator('#pagination', {
    				totalPages:1,
    				first:'',
    		        prev: '',
    		        next: '',
    		        last: '',
    		        page: '',
	    		});
	    	}else{
		    	for(var i in flowings){
		    		var flowing =getWithoutNull(flowings[i]);
		    		if(type=="money"){
			    		html+="<tr>"+
		                          "<td><span class='text_gray9'>"+flowing.operateDateView+"</span></td>"+
		                          "<td>"+flowing.tradeTypeName+"</td>"+
		                          "<td><span class='text_red'>"+getWithoutNaN(parseFloat(flowing.amount).toFixed(2))+"</span></td>"+
		                          "<td>"+flowing.acctNoView+"</td>"+
		                          "<td>"+flowing.dealerName+"</td>"+
		                          "<td>"+flowing.describes+"</td>"+
		                      "</tr>";
		    		}else if(type=="rebate"){
		    			html+="<tr>"+
		                          "<td><span class='text_gray9'>"+flowing.startDateView+"  -  "+flowing.endDateView+"</span></td>"+
		                          "<td><span class='text_red'>"+getWithoutNaN(parseFloat(flowing.amount).toFixed(2))+"</span></td>"+
		                          "<td>"+flowing.acctNoView+"</td>"+
		                          "<td>"+flowing.dealerName+"</td>"+
		                          "<td>"+flowing.statusName+"</td>"+
		                       "</tr>";
		    		}else if(type=="withdrawl"){
		    			html+="<tr>"+
		                        "<td><span class='text_gray9'>"+flowing.operateDateView+"</span></td>"+
		                        "<td><span class='text_red'>"+getWithoutNaN(parseFloat(flowing.amount).toFixed(2))+"USD</span></td>"+
		                        "<td>"+getWithoutNaN(parseFloat(flowing.withdrawalFee).toFixed(2))+"</td>"+
		                        "<td><span class='text_blue'>"+getWithoutNaN(parseFloat(flowing.withdrawalAmountCurrency).toFixed(2))+"</span></td>"+
		                        "<td><span class='text_blue'>"+flowing.withdrawalCurrencyName+"</span></td>"+
		                        "<td>"+flowing.acctNoView+"</td>"+
		                        "<td>"+flowing.describes+"</td>"+
		                        "<td>"+flowing.statusName+"</td>"+
		                      "</tr>";
		    		}
		    	}
	    	}
	    	$("#moneyDetail").html(html);
	    	loadData(currentPage,total);
	    }
    });
}
