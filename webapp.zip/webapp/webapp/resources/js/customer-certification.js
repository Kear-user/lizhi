$(function(){
	v = getCookieValue("cfc_validate_secondsremained");//获取
    if(v>0){
        settimes($("#btn_uc_smscode"));//开始倒计时
    }
	var vld_error=$("#bp_error");
	var ni_error=$("#ni_error");
    vld_error.html("");
	vld_error.css("display","none");
	//var reg=/^1(3|4|5|7|8)\d{9}$/;
    $("#btn_uc_smscode").click(function(){
		$.get("user/smrzCode",function(r){
			r=eval("("+r+")");
			if(r.code==0){
				addCookie("cfc_validate_secondsremained",60,60);
				settimes($("#btn_uc_smscode"));
				vld_error.html(r.msg);
				vld_error.attr("class","vld-ok");
				vld_error.css("display","block");
			}
		});
	});
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
    $("#btn_up_sub").click(function(){
    	var cCode=getByTrim($("#certification_code").val());
    	var userName = getByTrim($("#userName").val());
    	var idNumb = getByTrim($("#idNumb").val());
	    if(!isNull(cCode)){
			vld_error.html("请输入验证码");
			vld_error[0].className="vld-error col-sm-2";
			vld_error.css("display","block");
			$("#certification_code").focus();
			 return  false; 
		}else if(!isNull(userName)){
			ni_error.html("请输入真实姓名");
			ni_error[0].className="vld-error col-sm-2";
			ni_error.css("display","block");
			$("#userName").focus();
			return  false; 
		}else if(!isChineseChar(userName)){
			ni_error.html("请输入中文姓名");
			ni_error[0].className="vld-error col-sm-2";
			ni_error.css("display","block");
			$("#userName").focus();
			return  false; 
		}else if(!isNull(idNumb)){
			ni_error.html("请输入身份证号码");
			ni_error[0].className="vld-error col-sm-2";
			ni_error.css("display","block");
			$("#idNumb").focus();
			return  false; 
		}else if(!isCardNo(idNumb)){
	        ni_error.html("身份证输入不合法");
			ni_error[0].className="vld-error col-sm-2";
			ni_error.css("display","block");
			$("#idNumb").focus();
	        return  false;  
		}else{
			ni_error.css("display","none");
			vld_error.css("display","none");
			$("#form_c_card").cryptPOST({
	    		success : function(r) {
	    			if(r.code==0){
	    				addCookie("cfc_validate_secondsremained",0,0);
	    				window.location.href=$("#basePath").val()+"user/certificationSuccess";
	    			}else if(r.code_error!=null){
	    				vld_error.html(r.code_error);
	    				vld_error[0].className="vld-error col-sm-2";
	    				vld_error.css("display","block");
	    				$("#certification_code").focus();
	    			}else{
	    				window.location.href=$("#basePath").val()+"user/certificationFaild";
	    			}
	    		}
	    	});
		}
    });
});
function settimes(obj) { 
	countdown=getCookieValue("cfc_validate_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("cfc_validate_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}