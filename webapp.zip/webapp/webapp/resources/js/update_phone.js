$(function(){
	v = getCookieValue("up_phone_secondsremained");//获取
    if(v>0){
        settimes($("#btn_bp_smscode"));//开始倒计时
    }
    
    var vld_error=$("#bp_error");
    vld_error.html("");
	vld_error.css("display","none");
	var reg=/^1(3|4|5|7|8)\d{9}$/;
    $("#btn_bp_smscode").click(function(){
		var phone=$.trim($("#boundPhone").val());
		if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else{
			$.get("user/smsCode?phone="+phone+"&registType=0",function(r){
				r=eval("("+r+")");
				if(r.code==0){
					addCookie("up_phone_secondsremained",60,60);//
					settimes($("#btn_bp_smscode"));
					vld_error.html(r.msg);
					vld_error.attr("class","vld-ok");
					vld_error.css("display","block");
				}else{
					vld_error.html("手机号码已存在");
					vld_error.attr("class","vld-error");
					vld_error.css("display","block");
				}
			});
		}
	});
    
    $('#boundSms').keydown(function(e){
		if(e.keyCode==13){
			var phone=$.trim($("#boundPhone").val());
	    	var smsCode=$.trim($("#boundSms").val());
	    	if(phone==""||phone.length==0){
				vld_error.html("请输入手机号");
				vld_error.attr("class","vld-error");
				vld_error.css("display","block");
			}else 
				if(!reg.test(phone)){
				vld_error.html("请输入正确的手机号");
				vld_error.attr("class","vld-error");
				vld_error.css("display","block");
			}else 
				if(smsCode==""||smsCode.length==0){
				vld_error.html("请输入验证码");
				vld_error.attr("class","vld-error");
				vld_error.css("display","block");
			}else{
		    	$("#form_update_phone").cryptPOST({
		    		success : function(r) {
		    			if(r.code==0){
		    				addCookie("up_phone_secondsremained",0,0);
		    				window.location.href=$("#basePath").val()+"user/updatePhoneSuccess?phone="+phone;
		    			}else{
		    				vld_error.html(r.msg);
		    				vld_error.attr("class","vld-error");
		    				vld_error.css("display","block");
		    			}
		    		}
		    	});
			}
		}
	});
    
    
    $("#btn_bp_sub").click(function(){
    	var phone=$.trim($("#boundPhone").val());
    	var smsCode=$.trim($("#boundSms").val());
    	if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else 
			if(smsCode==""||smsCode.length==0){
			vld_error.html("请输入验证码");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else{
	    	$("#form_update_phone").cryptPOST({
	    		success : function(r) {
	    			if(r.code==0){
	    				addCookie("up_phone_secondsremained",0,0);
	    				window.location.href=$("#basePath").val()+"user/updatePhoneSuccess?phone="+phone;
	    			}else{
	    				vld_error.html(r.msg);
	    				vld_error.attr("class","vld-error");
	    				vld_error.css("display","block");
	    			}
	    		}
	    	});
		}
    });
});


function settimes(obj) { 
	countdown=getCookieValue("up_phone_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("up_phone_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}