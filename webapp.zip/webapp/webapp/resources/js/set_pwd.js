$(function(){
	v = getCookieValue("set_pwd_secondsremained");//获取
    if(v>0){
        settimes($("#btn_set_smscode"));//开始倒计时
    }
    
    var vld_error=$("#bp_error");
    vld_error.html("");
	vld_error.css("display","none");
	var reg=/^1(3|4|5|7|8)\d{9}$/;
    $("#btn_set_smscode").click(function(){
		var phone=$.trim($("#form_set_pwd input[name='phone']").val());
		$.get("user/smsCode?phone="+phone+"&registType=2",function(r){
			r=eval("("+r+")");
			if(r.code==0){
				addCookie("set_pwd_secondsremained",60,60);//
				settimes($("#btn_set_smscode"));
				vld_error.html(r.msg);
				vld_error.attr("class","vld-ok");
				vld_error.css("display","block");
			}else{
				vld_error.html(r.msg);
				vld_error.attr("class","vld-error");
				vld_error.css("display","block");
			}
		});
	});
    
    
    $('#setPwdSms').keydown(function(e){
		if(e.keyCode==13){
			var smsCode=$.trim($("#setPwdSms").val());
			if(smsCode==""||smsCode.length==0){
				vld_error.html("请输入验证码");
				vld_error.attr("class","vld-error");
				vld_error.css("display","block");
			}else{
		    	$("#form_set_pwd").cryptPOST({
		    		success : function(r) {
		    			if(r.code==0){
		    				addCookie("set_pwd_secondsremained",0,0);
		    				window.location.href=$("#basePath").val()+"user/settingNewPwd";
		    			}else{
		    				vld_error.html(r.msg);
		    				vld_error.attr("class","vld-error");
		    				vld_error.css("display","block");
		    			}
		    		}
		    	});
			}
		}
    });
    
    $("#btn_set_pwd").click(function(){
    	var smsCode=$.trim($("#setPwdSms").val());
		if(smsCode==""||smsCode.length==0){
			vld_error.html("请输入验证码");
			vld_error.attr("class","vld-error");
			vld_error.css("display","block");
		}else{
	    	$("#form_set_pwd").cryptPOST({
	    		success : function(r) {
	    			if(r.code==0){
	    				addCookie("set_pwd_secondsremained",0,0);
	    				window.location.href=$("#basePath").val()+"user/settingNewPwd";
	    			}else{
	    				vld_error.html(r.msg);
	    				vld_error.attr("class","vld-error");
	    				vld_error.css("display","block");
	    			}
	    		}
	    	});
		}
    });
});


function settimes(obj) { 
	countdown=getCookieValue("set_pwd_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("set_pwd_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}