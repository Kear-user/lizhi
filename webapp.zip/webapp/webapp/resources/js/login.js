var countdown=60;
$(function(){
	v = getCookieValue("l_secondsremained");//获取
    if(v>0){
        settimes($("#btn_sms_code"));//开始倒计时
    }
    
	var ele_pass = $("#passWord");
	var ele_eye = $("#pwd_i");
	ele_eye.click(function(){
		var state = this.getAttribute("state");
		if(state === "off") {
			ele_pass.attr("type", "text");
			ele_eye.attr("state", "on");
			ele_eye.css("opacity",0.5);
		} else {
			ele_pass.attr("type", "password");
			ele_eye.attr("state", "off");
			ele_eye.css("opacity",1);
		}
	});
	
	var formName="#form_login_pwd";
	var vld_error=$("#pwd_error");
	$("#pwdLogin").click(function(){
		formName="#form_login_pwd";
		vld_error=$("#pwd_error");
	});
	$("#phoneLogin").click(function(){
		formName="#form_login_phone";
		vld_error=$("#phone_error");
	});
	vld_error.html("");
	vld_error.css("display","none");
	
	//
	$("#btn_sms_code").click(function(){
		var phone=$.trim($("#loginPhone").val());
		var reg=/^1(3|4|5|7|8)\d{9}$/;
		if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.css("display","block");
		}else{
			$.get("user/smsCode?phone="+phone+"&registType=2",function(r){
				r=eval("("+r+")");
				if(r.code==0){
					addCookie("l_secondsremained",60,60);//
					settimes($("#btn_sms_code"));
					vld_error.html(r.msg);
					vld_error.attr("class","vld-ok");
					vld_error.css("display","block");
				}else{
					vld_error.html(r.msg);
					vld_error.attr("class","vld-error");
					vld_error.css("display","block");
				}
			});
		}
	});
	
	//
	$("#form_login_pwd button").click(function () {
		$("#loginTypePwd").attr("value",1);
		var userName=$.trim($("#userName").val());
		var passWord=$.trim($("#passWord").val());
		if(userName==""||userName.length==0){
			vld_error.html("请输入帐号");
			vld_error.css("display","block");
		}else if(passWord==""||passWord.length==0){
			vld_error.html("请输入密码");
			vld_error.css("display","block");
		}else{
			loginSub(formName,vld_error);
		}
    });
	
	$("#btn_phone_login").click(function () {
		$("#loginTypePhone").attr("value",0);
		var reg=/^1(3|4|5|7|8)\d{9}$/;
		var phone=$.trim($("#loginPhone").val());
		var smsCode=$.trim($("#smsCode").val());
		if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.css("display","block");
		}else 
			if(smsCode==""||smsCode.length==0){
			vld_error.html("请输入验证码");
			vld_error.css("display","block");
		}else{
			loginSub(formName,vld_error);
		}
	});
	
	
	$('#userName').keydown(function(e){
		if(e.keyCode==13){
			$("#loginTypePwd").attr("value",1);
			var userName=$.trim($("#userName").val());
			var passWord=$.trim($("#passWord").val());
			if(userName==""||userName.length==0){
				vld_error.html("请输入帐号");
				vld_error.css("display","block");
			}else if(passWord==""||passWord.length==0){
				vld_error.html("请输入密码");
				vld_error.css("display","block");
			}else{
				loginSub(formName,vld_error);
			}
		}
	});
	$('#passWord').keydown(function(e){
		if(e.keyCode==13){
			$("#loginTypePwd").attr("value",1);
			var userName=$.trim($("#userName").val());
			var passWord=$.trim($("#passWord").val());
			if(userName==""||userName.length==0){
				vld_error.html("请输入帐号");
				vld_error.css("display","block");
			}else if(passWord==""||passWord.length==0){
				vld_error.html("请输入密码");
				vld_error.css("display","block");
			}else{
				loginSub(formName,vld_error);
			}
		}
	});
	
	$('#loginPhone').keydown(function(e){
		if(e.keyCode==13){
			$("#loginTypePhone").attr("value",0);
			var reg=/^1(3|4|5|7|8)\d{9}$/;
			var phone=$.trim($("#loginPhone").val());
			var smsCode=$.trim($("#smsCode").val());
			if(phone==""||phone.length==0){
				vld_error.html("请输入手机号");
				vld_error.css("display","block");
			}else 
				if(!reg.test(phone)){
				vld_error.html("请输入正确的手机号");
				vld_error.css("display","block");
			}else 
				if(smsCode==""||smsCode.length==0){
				vld_error.html("请输入验证码");
				vld_error.css("display","block");
			}else{
				loginSub(formName,vld_error);
			}
		}
	});
	$('#smsCode').keydown(function(e){
		if(e.keyCode==13){
			$("#loginTypePhone").attr("value",0);
			var reg=/^1(3|4|5|7|8)\d{9}$/;
			var phone=$.trim($("#loginPhone").val());
			var smsCode=$.trim($("#smsCode").val());
			if(phone==""||phone.length==0){
				vld_error.html("请输入手机号");
				vld_error.css("display","block");
			}else 
				if(!reg.test(phone)){
				vld_error.html("请输入正确的手机号");
				vld_error.css("display","block");
			}else 
				if(smsCode==""||smsCode.length==0){
				vld_error.html("请输入验证码");
				vld_error.css("display","block");
			}else{
				loginSub(formName,vld_error);
			}
		}
	});
});

function loginSub(formName,vld_error){
	$(formName).cryptPOST({
		success : function(r) {
			if(r.code==0){
				addCookie("l_secondsremained",0,0);//
				vld_error.html("");
				vld_error.css("display","none");
				if(r.href!=""){
					window.open(r.href);
//					window.location.href=r.href;
				}else{
					var curPath = window.document.location.href;
				    var pathName = window.document.location.pathname;
				    var pos = curPath.indexOf(pathName);
				    var localhostPaht = curPath.substring(0, pos);
				    var projectName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);
				    var historyUrl=document.referrer;
				    var re_historyUrl=historyUrl.replace(localhostPaht,"");
					if(re_historyUrl.indexOf(projectName)!=-1){
						re_historyUrl=re_historyUrl.replace(projectName,"");
					}
					if(re_historyUrl=="/user/success_save"){
						window.location.href=$("#basePath").val()+"index";
					}else if(historyUrl.indexOf("user/login")!=-1){
						window.location.href=$("#basePath").val()+"index";
					}else if(historyUrl.indexOf("forgot")!=-1){
						window.location.href=$("#basePath").val()+"index";
					}else if(historyUrl.indexOf("email")!=-1){
						window.location.href=$("#basePath").val()+"index";
					}else if(window.location.href.indexOf("indiana")!=-1){
						window.location.href=$("#basePath").val()+"indiana";
					}else if(window.location.href.indexOf("user/invite")!=-1){
						window.location.href=$("#basePath").val()+"user/invite";
					}else{
						window.location.href=historyUrl;
					}
				}
			}else if(r.code==500){
				$("#phone_error").attr("class","vld-error");
				vld_error.html(r.msg);
				vld_error.css("display","block");
			}else{
				vld_error.html(r.msg);
				vld_error.css("display","block");
			}
		}
	});
}

function settimes(obj) { 
	countdown=getCookieValue("l_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("l_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}