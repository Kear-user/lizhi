$(function(){
	
	
	
	$("#btn_unionpay_account").click(function(){//银行卡提交
		var accountAcct = $("#accountAcct").val();
		var reAccountAcct = $("#reAccountAcct").val();
		var bank  = $("#banks").val();
		
		if(!isNull(accountAcct)){
			$("#error_bankAccount").text("请输入银行卡");
			$("#accountAcct").focus();
			return false;
		}else{
			$("#error_bankAccount").text("*");
		} 
		if(!isBankCard(accountAcct)){
			$("#error_bankAccount").text("银行卡格式有误");
			$("#accountAcct").focus();
			return false;
		}else{
			$("#error_bankAccount").text("*");
		} 
		if(accountAcct!=reAccountAcct){
			$("#r_error_bankAccount").text("银行卡输入不一致");
			$("#reAccountAcct").focus();
			return false;
		}else{
			$("#r_error_bankAccount").text("*");
		}
		if(!isNull(bank)){
			$("#error_bankName").val("请选择银行");
			$("#banks").focus();
			return false;
		}else{
			$("#error_bankName").val("*");
		}
		$("#form_unionpay_account").cryptPOST({
			success : function(r) {
				if(r.code==0){
					window.location.reload();
				}else{
					alert(r.msg);
				}
			}
		});
	});
	
	$("#btn_dianhui_account").click(function(){//电汇提交
		var firstName = $("#firstName").val();
		var lastName = $("#lastName").val();
		var accountAcct  = $("#accountAcctD").val();
		var reAccountAcct  = $("#reAccountAcctD").val();
		var bank  = $("#banksD").val();
		var bankKName  = $("#bankKNameD").val();
		//var bankAddress  = $("#bankAddress").val();
		var swiftCode  = $("#swiftCode").val();
		var payeeAddress  = $("#payeeAddress").val();
		
		if(firstName!=null && lastName!=null){
			if(!isNull(firstName)){
				$("#error_first_name").text("请输入FirstName");
				$("#firstName").focus();
				return false;
			}else{
				$("#error_first_name").text("*");
			}
			if(!isNull(lastName)){
				$("#error_last_name").text("请输入LastName");
				$("#lastName").focus();
				return false;
			}else{
				$("#error_last_name").text("*");
			}
		}
		
		if(!isNull(accountAcct)){
			$("#error_account_acct").text("请输入银行卡号");
			$("#accountAcctD").focus();
			return false;
		}else{
			$("#error_account_acct").text("*");
		} 
		if(!isWireTransfer(accountAcct)){
			$("#error_account_acct").text("银行卡格式有误");
			$("#accountAcctD").focus();
			return false;
		}else{
			$("#error_account_acct").text("*");
		} 
		if(accountAcct!=reAccountAcct){
			$("#re_error_account_acct").text("银行卡输入不一致");
			$("#reAccountAcctD").focus();
			return false;
		}else{
			$("#re_error_account_acct").text("*");
		}
		if(!isNull(bank)){
			$("#error_bankD").text("请输入银行名称");
			$("#banksD").focus();
			return false;
		}else{
			$("#error_bankD").text("*");
		}
		
		if(!isNull(bankKName)){
			$("#error_opening_bankD").text("请输入开户行");
			$("#bankKNameD").focus();
			return false;
		}else{
			$("#error_opening_bankD").text("*");
		}
/*		
		if(!isNull(bankAddress)){
			$("#error_bank_addressD").text("请输入银行地址");
			$("#bankAddress").focus();
			return false;
		}else{
			$("#error_bank_addressD").text("*");
		}*/
		
		if(!isNull(swiftCode)){
			$("#error_swift_code").text("请输入SWIFT码");
			$("#swiftCode").focus();
			return false;
		}else{
			$("#error_swift_code").text("*");
		}
		
		if(!isNull(payeeAddress)){
			$("#error_payee_address").text("请输入收款人地址");
			$("#payeeAddress").focus();
			return false;
		}else{
			$("#error_payee_address").text("*");
		}
		
		$("#form_dianhui_account").cryptPOST({
			success : function(r) {
				if(r.code==0){
					window.location.reload();
				}else{
					alert(r.msg);
				}
			}
		});
	});
	
	/**
	$("#btn_alipay_account").click(function(){
		if(!isNull($("#accountAcctZ").val())){
			$("#error_account_z").text("请输入支付宝账号");
			$("#accountAcctZ").focus();
			return false;
		}else if(!isEmail($("#accountAcctZ").val())&&!isPhone($("#accountAcctZ").val())){
			$("#error_account_z").text("账号格式有误");
			$("#accountAcctZ").focus();
			return false;
		}else{
			$("#error_account_z").text("*");
			
			$("#form_alipay_account").cryptPOST({
				success : function(r) {
					if(r.code==0){
						window.location.reload();
					}else{
						alert(r.msg);
					}
				}
			});
		}
	});
	*/
	
	$("#btn_skrill_account").click(function(){//Skrill提交
		var firstName = $("#firstNameS").val();
		var lastName = $("#lastNameS").val();
		var accountAcct  = $("#accountAcctS").val();
		if(firstName!=null && lastName!=null){
			if(!isNull(firstName)){
				$("#error_first_nameS").text("请输入FirstName");
				$("#firstNameS").focus();
				return false;
			}else{
				$("#error_first_nameS").text("*");
			}
			if(!isNull(lastName)){
				$("#error_last_nameS").text("请输入LastName");
				$("#lastNameS").focus();
				return false;
			}else{
				$("#error_last_nameS").text("*");
			}
		}
		
		if(!isNull(accountAcct)){
			$("#error_account_s").text("请输入Skrill账号");
			$("#accountAcctD").focus();
			return false;
		}else{
			$("#error_account_s").text("*");
		} 
		if(!isEmail(accountAcct)){
			$("#error_account_s").text("Skrill账号格式有误");
			$("#accountAcctD").focus();
			return false;
		}else{
			$("#error_account_s").text("*");
		} 
		
		$("#form_skrill_account").cryptPOST({
			success : function(r) {
				if(r.code==0){
					window.location.reload();
				}else{
					alert(r.msg);
				}
			}
		});
	});
	
	
});	

//加载银行
function loadBank(){
	$("#banks").html("<option value=''>请选择银行</option>");
	//先判断有没有设置交易密码
	var banksHtml = '';
	$.get("ecustomeraccountinfo/getBanks",function(data){
		banks = eval('('+data+')');
		for(var i in banks){
			banksHtml+='<option value="'+banks[i]+'">'+banks[i]+'</option>';
		}
		$("#banks").append(banksHtml);
	});
}

function haveName(isName,type){
	//先判断有没有实名认证
	if(isName!="yes"){
		$("#dlg-set-name").modal('show');
	}else{
		//if(type==2)$("#dlg-add-alipay").modal('show');
		//if(type==3)$("#dlg-add-payment-method-skrillcards").modal('show');
		//if(type==4)$("#dlg-add-payment-method-paypal").modal('show');
		if(type==0){
			loadBank();
			$("#dlg-add-unionpay-account").modal('show');
		}
	}
}
