$(function(){  //初始化
    	var _handle =true;
        var cells = $('.day-count .wd');
        var cellsv = $('.day-count-v .wdv');
        var clen = cells.length;
        var formatDate = function(date){       
	        var month = (date.getMonth()+1)+'/';
	        var day = date.getDate();
            return month+day;
        };
        var addDate= function(date,n){
        	date.setDate(date.getDate()+n);    
       		return date;
        };
     	var setDate = function(date){   
     		var week = date.getDay()-1;
     		
     		//cells[week].className= "able-qiandao";
     		if(week!=-1){
     			$(cells[week]).addClass("able-qiandao");
     			date = addDate(date,week*-1);
     		}else if(week==-1){
     			$(cells[6]).addClass("able-qiandao");
     			date = addDate(date,week*7);
     		}
     		
	        currentFirstDate = new Date(date);
	        for(var i = 0;i<clen;i++){         
	        	cellsv[i].innerHTML = formatDate(i==0 ? date : addDate(date,1));
	        }        
      };       
      setDate(new Date());
      
      $(".day-count").on("click", ".wd", function() {
              if ($(this).hasClass('able-qiandao') && _handle &&!$(this).hasClass('checked')) {
                  $(this).addClass('checked');
                  qiandao();
                  _handle=false;
              }
      });//签到（日期）
      
      $("#qiandaoBtn").click(function(){//签到（按钮）
      	if(_handle&&!$('.able-qiandao').hasClass('checked')){
      		qiandao();
      		_handle=false;
      	}
    });
      function qiandao(){
    	  $.get("customer/attendance",function(r){
	    	    r = JSON.parse(r);
	    	    if(r.code == 0){
	    	    	var left = $(".able-qiandao").position().left;
	    	    	$("#showigl").css("left",left);
	    	    	$(".able-qiandao").addClass("checked");
		    		yiqiandao();
		    		if(r.bonuses=="draw"){
		    			$("#showigl").html("免费抽奖+1");
		    			var st = setTimeout("hideshowigl()",1000);
		    		}else{
		    			if($('.able-qiandao').hasClass('box')){
		    				$(".able-qiandao").addClass("opened");
		    			}
		    			$("#showigl").html("积分+"+r.bonuses);
		    			$(".igl").html(parseInt($(".mypoints-number").text())+parseInt(r.bonuses));
		    			var st =  setTimeout("hideshowigl()",1000);
		    		}
		    		//alert(r.msg);
	    	    }else if(r.code == 500){
					alert(r.msg);
	    	    }
	    	});
      }
      if($('.able-qiandao').hasClass('checked')){
			yiqiandao();
	  	}
      
      function yiqiandao(){
    	  $(".qiandaoBtn").eq(0).html("已签到");
    	  $(".qiandaoBtn").eq(1).html("今日已签到");
      }
      
      //所有个人中心模式款关闭
      $(".common-dlg-panel .title-row a").click(function(){
    		$("#dlg-tixian").modal("hide");
    		$("#dlg-add-unionpay-account").modal("hide");
    		$("#dlg-addr").modal("hide");
      });
    }); 
function hideshowigl(){
	
	  $("#showigl").fadeOut(2000);
};


