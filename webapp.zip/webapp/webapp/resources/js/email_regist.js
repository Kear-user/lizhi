var hash={   
		 'qq.com': 'http://mail.qq.com',   
		 'gmail.com': 'http://mail.google.com',   
		 'sina.com': 'http://mail.sina.com.cn',   
		 '163.com': 'http://mail.163.com',   
		 '126.com': 'http://mail.126.com',   
		 'yeah.net': 'http://www.yeah.net/',   
		 'sohu.com': 'http://mail.sohu.com/',   
		 'tom.com': 'http://mail.tom.com/',   
		 'sogou.com': 'http://mail.sogou.com/',   
		 '139.com': 'http://mail.10086.cn/',   
		 'hotmail.com': 'http://www.hotmail.com',   
		 'live.com': 'http://login.live.com/',   
		 'live.cn': 'http://login.live.cn/',   
		 'live.com.cn': 'http://login.live.com.cn',   
		 '189.com': 'http://webmail16.189.cn/webmail/',   
		 'yahoo.com.cn': 'http://mail.cn.yahoo.com/',   
		 'yahoo.cn': 'http://mail.cn.yahoo.com/',   
		 'eyou.com': 'http://www.eyou.com/',   
		 '21cn.com': 'http://mail.21cn.com/',   
		 '188.com': 'http://www.188.com/',   
		 'foxmail.com': 'http://www.foxmail.com'   
}; 
var countdown=0; 
$(function(){   
	 $("#email").each(function() {   
	   var url = $(this).text().split('@')[1];   
	   for (var j in hash){   
	       $("#go_email").attr("href", hash[url]);   
	   }   
	 });
	 countdown=getCookieValue("e_secondsremained");
	 if(countdown>0){
		settimes($("#sendTimes"));//开始倒计时
	 }
	 
	 $("#sendTimes").click(function(){
     	$.get("user/activeUserAgain?email="+$("#email").text(),function(r){
         	r=eval("("+r+")");
     		if(r.code==0){
        		addCookie("e_secondsremained",60,60);//
        		settimes($("#sendTimes"));
         		window.location.reload();
         	}
         });
     });
});
function settimes(obj) { 
	countdown=getCookieValue("e_secondsremained");
    if (countdown == 0) {
    	obj.text("重新发送"); 
        countdown = 60; 
        $("#sendTimes").attr("disabled",false);
        //
        return;
    } else { 
    	obj.text("(" + countdown + "s)后重新发送");
    	$("#sendTimes").attr("disabled",true);
        countdown--; 
        editCookie("e_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}