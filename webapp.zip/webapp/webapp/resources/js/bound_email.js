$(function(){
	var vld_error=$("#bp_error");
	vld_error.html("");vld_error
	vld_error.css("display","none");
//	var reg_email=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
	var reg_email=/^[A-Za-z0-9_-]+([-_.][A-Za-z0-9_-]+)*@([A-Za-z0-9_-]+[-.])+[A-Za-zd]{2,5}$/;
	$("#bound_email").bind('input propertychange', function() { 
		var email=$.trim($("#bound_email").val());
		if(reg_email.test(email)){
			vld_error.html("");
			vld_error.css("display","none");
		}
	});
	
	
	$('#bound_email').keydown(function(e){
		if(e.keyCode==13){
			var email=$.trim($("#bound_email").val());
			if(email==""||email.length==0){
				vld_error.html("请输入邮箱");
				vld_error.css("display","block");
			}else 
				if(!reg_email.test(email)){
				vld_error.html("请输入正确的邮箱");
				vld_error.css("display","block");
			}else {
				$("#btn_bp_sub").attr("disabled","disabled");
				var i=0;
				sendLoading(i,vld_error);
				$("#form_bound_email").cryptPOST({
		    		success : function(r) {
		    			$("#btn_bp_sub").removeAttr("disabled"); 
		    			vld_error.html("");
		            	vld_error.attr("class","vld-error");
						vld_error.css("display","none");
		    			if(r.code==0){
		    				window.location.href=$("#basePath").val()+"user/emailSendSuccess?email="+email;
		    			}else{
		    				vld_error.html(r.msg);
		    				vld_error.css("display","block");
		    			}
		    		}
		    	});
			}
		}
	});
	
	
	$("#btn_bp_sub").click(function(){
		var email=$.trim($("#bound_email").val());
		if(email==""||email.length==0){
			vld_error.html("请输入邮箱");
			vld_error.css("display","block");
		}else 
			if(!reg_email.test(email)){
			vld_error.html("请输入正确的邮箱");
			vld_error.css("display","block");
		}else {
			$("#btn_bp_sub").attr("disabled","disabled");
			var i=0;
			sendLoading(i,vld_error);
			$("#form_bound_email").cryptPOST({
	    		success : function(r) {
	    			$("#btn_bp_sub").removeAttr("disabled"); 
	    			vld_error.html("");
	            	vld_error.attr("class","vld-error");
					vld_error.css("display","none");
	    			if(r.code==0){
	    				window.location.href=$("#basePath").val()+"user/emailSendSuccess?email="+email;
	    			}else{
	    				vld_error.html(r.msg);
	    				vld_error.css("display","block");
	    			}
	    		}
	    	});
		}
	});
});

function sendLoading(i,vld_error){ 
	console.log("1");
	if(i==0){
		vld_error.html("邮件发送中，请稍候...");
		i=1;
	}else{
		vld_error.html("邮件发送中，请稍候......");
		i=0;
	}
	vld_error.attr("class","vld-ok");
	vld_error.css("display","block");
    setTimeout(function(){sendLoading(i,vld_error)},1000);
}