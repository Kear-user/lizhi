$(function(){
	
	v = getCookieValue("f_secondsremained");//获取
    if(v>0){
        settimes($("#btn_get_code"));//开始倒计时
    }
	
	var vld_error=$("#code_error");
	var reg=/^1(3|4|5|7|8)\d{9}$/;
	$("#btn_get_code").click(function(){
		var phone=$.trim($("#forgotPhone").val());
		if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.css("display","block");
		}else{
			$.get("user/smsCode?phone="+phone+"&registType=1",function(r){
				r=eval("("+r+")");
				if(r.code==0){
					addCookie("f_secondsremained",60,60);//
					settimes($("#btn_get_code"));
					vld_error.html(r.msg);
					vld_error.attr("class","vld-ok");
					vld_error.css("display","block");
				}else{
					vld_error.html(r.msg);
					vld_error.attr("class","vld-error");
					vld_error.css("display","block");
				}
			});
		}
	});
	
	$("#btn_pvalidate_sub").click(function(){
		var phone=$("#forgotPhone").val();
		var smsCode=$("#forgotSmsCode").val();
		if(phone==""||phone.length==0){
			vld_error.html("请输入手机号");
			vld_error.css("display","block");
		}else 
			if(!reg.test(phone)){
			vld_error.html("请输入正确的手机号");
			vld_error.css("display","block");
		}else
			if(smsCode==""||smsCode.length==0){
				vld_error.html("请输入验证码");
				vld_error.css("display","block");	
		}else{
			addCookie("f_secondsremained",0,0);
			$("#form_phone_validate").submit();
		}
	});	
});

function settimes(obj) { 
	countdown=getCookieValue("f_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("f_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settimes(obj)},1000);
}