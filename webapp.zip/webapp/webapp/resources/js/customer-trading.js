$(function(){
	loadmore();
	$("#btn_acct_no_add").click(function(){
		addAttcNo();
	});
	$("#acceptCheck").change(function(){
		if(!$("#acceptCheck").is(':checked')){
			 $("#btn_acct_no_add").attr("disabled","disabled");
		 }else{
			 $("#btn_acct_no_add").removeAttr("disabled");
		 }
	});

	$("#dealerId").blur(function(){
		 if($("#dealerId").val()==null||$("#dealerId").val()==""){
			 $("#dealerMsg").text("请选择一个交易商");
		 }else{
			 $("#dealerMsg").text("*");
		 } 
	});
	$("#acctNo").blur(function(){
		 if($("#acctNo").val()==null || $("#acctNo").val() ==""){
			 $("#acctNoMsg").text("请输入交易账号");
		 }else{
			 $("#acctNoMsg").text("*");
		 } 
	});
	$("#holdName").blur(function(){
		 if($("#holdName").val()==null || $("#holdName").val() ==""){
			 $("#holdNameMsg").text("请输入开户人");
		 }else{
			 $("#holdNameMsg").text("*");
		 } 
	});
	$("#holderEmail").blur(function(){
		 if(!isEmail($("#holderEmail").val())){
			 $("#holderEmailMsg").text("邮箱格式不合法");
		 }else{
			 $("#holderEmailMsg").text("*");
		 } 
	});
	
});

function loadmore(){
	$.ajax({
		type: "POST",
	    url: "customer/trading/acctno",
	    contentType : 'application/json',
	   // data: JSON.stringify([offset,limit]),
	    beforeSend:function(){
	    	
	    },
	    success:function(r){
	    	var tradeAcctNos = eval(r);
	    	var html="";
	    	if(tradeAcctNos==null||tradeAcctNos.length == 0){
	    		html+="<span style='font-size: 16px;position: absolute;left: 45%;top: 10%;'>还没有记录</span>";
	    	}
	    	for(var i in tradeAcctNos){
	    		var tradeAcctNo = getWithoutNull(tradeAcctNos[i]);
	    		var status = "";
	    		var operation = "--";
	    		if(tradeAcctNo.checkStatus=='0'||tradeAcctNo.checkStatus=="1"){
	    			status = "审核中";
	    		}else if(tradeAcctNo.checkStatus=='2'){
	    			status = "<span class='text_red'>审核驳回</span> " +
	    					"<a href='javascript:;' title='"+tradeAcctNo.reasonDetail+"'>" +
	    					"<img src='resources/images/usercenter/icon-sm-ask.png'></a>";
	    		}else if(tradeAcctNo.checkStatus=='3'){
	    			status = "<img src='resources/images/usercenter/icon-sm-ok-14x14.png'>" +
	    					"<span class='text_green'>已绑定</span>";
	    			operation = "<a href='javascript:;' class='text_blue' onclick='confirmUnbind("+tradeAcctNo.tradeAcctId+","+tradeAcctNo.acctNo+")'>解绑</a>";
	    		}
	    		html+="<tr>"+
                          "<td>"+tradeAcctNo.submitDate+"</td>"+
                          "<td>"+tradeAcctNo.acctNo+"</td>"+
                          "<td>"+tradeAcctNo.dealerEnName+tradeAcctNo.dealerChnName+"</td>"+
                          "<td>"+tradeAcctNo.holderName+"</td>"+
                          "<td>"+tradeAcctNo.holderEmail+"</td>"+
                          "<td>"+status+"</td>"+
                          "<td>"+operation+"</td>"+
                        "</tr>";
	    	}
	    	$("#load_acct_no").html(html);
	    },
	    complete:function(){
	    	
	    }
	});
}
function confirmUnbind(taskId,acctNo){
	$("#dlg-unbind-jyzh").modal('show');
	$("#unbind_acct_no").text(acctNo);
	$("#btn_unbind_acct_no").click(function(){
		unBindAcctNo(taskId);
	});
}

//解绑
function unBindAcctNo(taskId){
	$.get("customer/trading/unbind/"+taskId,function(r){
		if(eval('('+r+')').code==0){
			alert("解绑成功！");
			window.location.reload();
		}else if(r.code==500){
			alert("解绑失败，请稍后再试！");
		}
	});
}
 function addAttcNo(){
	 var dealerId = toWithoutTrim($("#dealerId").val());
	 var acctNo = toWithoutTrim($("#acctNo").val());
	 var holdName = toWithoutTrim($("#holdName").val());
	 var holderEmail = toWithoutTrim($("#holderEmail").val());
	 if(dealerId==null||dealerId==""){
		 $("#dealerMsg").text("请选择一个交易商");
		 $("#dealerId").focus();
		 return false;
	 }else{
		 $("#dealerMsg").text("*");
	 } 
	 if(acctNo==null || acctNo ==""){
		 $("#acctNoMsg").text("请输入交易账号");
		 $("#acctNo").focus();
		 return false;
	 }else{
		 $("#acctNoMsg").text("*");
	 } 
	 if(holdName==null || holdName ==""){
		 $("#holdNameMsg").text("请输入开户人");
		 $("#holdName").focus();
		 return false;
	 }else{
		 $("#holdNameMsg").text("*");
	 } 
	 if(!isEmail(holderEmail)){
		 $("#holderEmailMsg").text("邮箱格式不合法");
		 $("#holderEmail").focus();
		 return false;
	 }else{
		 $("#holderEmailMsg").text("*");
	 } 
	 $("#form_add_trade_acct").cryptPOST({
		success : function(r) {
			if(r.code==0){
				alert(r.msg);
				window.location.reload();
			}else if(r.code==500){
				alert(r.msg);
			}
		}
	 });
 };