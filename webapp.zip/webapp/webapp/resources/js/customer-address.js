function saveOrUpdate(id){
	var receiver=$.trim($("#receiver").val());
	var telephone=$.trim($("#telephone").val());
	var prov=$.trim($("#prov").val());
	var city=$.trim($("#city").val());
	var area=$.trim($("#area").val());
	var address=$.trim($("#address").val());
	var vld_error=$("#bp_error");
    vld_error.html("");
	vld_error.css("display","none");
	var reg=/^1(3|4|5|7|8)\d{9}$/;
	if(receiver==""||receiver==null){
		vld_error.html("请输入收货人姓名");
		vld_error.css("display","block");
		$("#receiver").focus();
		return false;
	}else if(telephone==""||telephone==null){
		vld_error.html("请输入手机号");
		vld_error.css("display","block");
		$("#telephone").focus();
		return false;
	}else if(!reg.test(telephone)){
		vld_error.html("请输入正确的手机号");
		vld_error.css("display","block");
		$("#telephone").focus();
		return false;
	}else if(prov=="-1"||prov==null){
		vld_error.html("请选择省份/自治区");
		vld_error.css("display","block");
		$("#prov").focus();
		return false;
	}else if(city=="-1"||city==null){
		vld_error.html("请选择城市/地区");
		vld_error.css("display","block");
		$("#city").focus();
		return false;
	}else if(area=="-1"||area==null){
		vld_error.html("请选择区/县");
		vld_error.css("display","block");
		$("#area").focus();
		return false;
	}else if(address==""||address==null){
		vld_error.html("请输入详细地址");
		vld_error.css("display","block");
		$("#address").focus();
		return false;
	}else{
		vld_error.css("display","");
		$("#form_set_address").cryptPOST({
			success : function(r) {
				if(r.code==0){
					window.location.href="customer/setting/address";
				}else if(r.code==500){
					alert("删除失败");
				}
			}
		});
	}
}
function getInfo(addressID){
	$.get("ecustomeraddress/info/"+addressID,function(r){
		var customerAddress  = eval('('+r+')').customerAddress;
		$("#receiver").val(customerAddress.name);
    	$("#telephone").val(customerAddress.telephone);
		$("#prov").val(customerAddress.province);
		$("#prov").trigger("change");
		$("#city").val(customerAddress.city);
		$("#city").trigger("change");
		$("#area").val(customerAddress.county);
		$("#area").trigger("change");
		$("#address").val(customerAddress.address);
		if(customerAddress.isDefault=="1"){
			$("#isDefault").attr("checked","true");
		}else if(customerAddress.isDefault=="0"){
			$("#isDefault").removeAttr("checked");
		}
		$("#addressId").remove();
		$("#receiver").before('<input id ="addressId" name="addressId" type="hidden" value="'+addressID+'">');
		$("#btn_address_s").text("修改收货人信息");
		$("#btn_address_s").attr("onclick","saveOrUpdate("+addressID+")");
		$("#form_set_address").attr("action","ecustomeraddress/update");
		$("#dlg-addr").modal('show');
	});
};

function addAddress(){
	$("#receiver").val("");
	$("#telephone").val("");
	$("#prov").val("-1");
	$("#prov").trigger("change");
	$("#isDefault").removeAttr("checked");
	$("#addressId").remove();
	$("#address").val("");
	$("#btn_address_s").text("新增收货人信息");
	$("#btn_address_s").attr("onclick","saveOrUpdate()");
	$("#form_set_address").attr("action","ecustomeraddress/save");
	$("#dlg-addr").modal('show');
};

function deleteAr(addressId){
	$.get("ecustomeraddress/delete/"+addressId,function(result){
		var r  = eval('('+result+')');
		if(r.code==0){
			window.location.href="customer/setting/address";
		}else if(r.code==500){
			alert("删除失败");
		}
	});
};

function comfirmDelete(addressId){
	$('#dlg-delete-shdz').modal('show');
	$('#comfirm_btn').attr("onclick","deleteAr("+addressId+")");
};