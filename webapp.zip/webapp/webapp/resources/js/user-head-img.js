$(function(){
	$("#modify-user-pic-btn").click(function(event){//修改头像
		event.preventDefault();
		$(this).toggle();
		$("#modify-user-pic-row").toggle();
	});
	
	$("#userHeadImgs").on("click","img",function(){//选择头像
		selectImg(this);
	});
	
	$("#submit-modify-user-pic-btn").click(function(event){//提交修改头像
		event.preventDefault();
		updateImg();
	});
	
	$("#modify-user-alias-btn").click(function(event){//修改昵称
		event.preventDefault();
		$(this).toggle();
		$("#modify-user-alias-row").toggle();
		$("#inpName").focus();
	});
	
	$("#submit-modify-user-alias-btn").click(function(event){//提交修改昵称
		event.preventDefault();
		updateInfo();
	});
	
	$(".usercenter-left-block .row").mouseover(function(){
		$("#imgEdit").css("visibility","visible");
	}).mouseout(function(){
		$("#imgEdit").css("visibility","hidden");
	});
});

var headImg ="";
var name = "";
function selectImg(dom){
	var img = $(dom).attr("src");
	headImg = img;
	$("#user_img_show").attr("src",headImg);
}
function updateImg(){
	if(headImg!="" && getByTrim(headImg) != getByTrim($("#userImg").attr("src"))){
		$.get("customer/basic/info?headImg="+headImg,function(result){
			var r  = eval('('+result+')');
			if(r.code==0){
				$("#userImg").attr("src",headImg);
				headImg = "";
				$("#modify-user-pic-btn").toggle();
				$("#modify-user-pic-row").toggle();
			}else if(r.code==500){
				alert(r.msg);
			}
		});
	}else if(getByTrim(headImg) == "" || getByTrim(headImg) == getByTrim($("#userImg").attr("src"))){
		$("#modify-user-pic-btn").toggle();
		$("#modify-user-pic-row").toggle();
	}
}

function updateInfo(){
	name = $("#inpName").val();
	var vld_error=$("#bp_error");
	var bp_error_pname = $("#bp_error_pname");
    vld_error.html("");
	vld_error.css("display","none");

		if(!isNull(name) || name.length<2 || name.length>16){
			vld_error.html("请输入2-16个字符");
			bp_error_pname.css("display","none");
			vld_error.css("display","block");
			$("#inpName").focus();
			return false;
		}else if(getByTrim($($(".userName")[0]).text()) == getByTrim(name)){
			$("#modify-user-alias-btn").toggle();
			$("#modify-user-alias-row").toggle();
			return false;
		}
		$.get("customer/basic/info?name="+name,function(result){
			var r  = eval('('+result+')');
			if(r.code==0){
				$(".userName").text(name);
				name = "";
				$("#modify-user-alias-btn").toggle();
				$("#modify-user-alias-row").toggle();
				bp_error_pname.css("display","");
				vld_error.css("display","none");
			}
		});
}