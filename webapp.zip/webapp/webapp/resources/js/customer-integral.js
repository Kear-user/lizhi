var offset=0;
var limit = 10;
var currentPage = 1;
var igalType = "get";
var zf = "+";
function loadData(num,total){
	var myPageCount = total;//分页的总页数
    var myPageSize = limit;//分页的展示条数
    var countindex = Math.ceil(myPageCount/myPageSize);
    loadpage(countindex,myPageCount,num);
}

function loadpage(countindex,myPageCount,num) {
    $.jqPaginator('#pagination', {
        totalPages: countindex,
        visiblePages: 5,
        currentPage: 1,
        first: '<li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',
        onPageChange: function (num, type) {
            if (type == "change") {
            	currentPage  = num;
            	offset = limit * (num-1);
            	moreintegral();
            	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
            	$(window).scrollTop($(".usercenter-right-block").offset().top);
            }
        }
    });
	$("#pagination").jqPaginator('option', { 
		totalPages: countindex,
		totalCounts:myPageCount,
	});
	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
}
function setIgalType(dom,type){
	igalType = type;
	$(".IgalType>a").removeClass("active");
	$(dom).addClass("active");
	if(igalType == "get"){
		$("table").css("display","");
		$("#getIgInfo").css("display","none");
		zf="+";
	}else if(igalType == "out"){
		$("table").css("display","");
		$("#getIgInfo").css("display","none");
		zf="";
	}else if(igalType == "why"){
		$("#pageInfo").html("");
		$("table").css("display","none");
		$("#getIgInfo").css("display","");
		$.jqPaginator('#pagination', {
			totalPages:1,
			first:'',
	        prev: '',
	        next: '',
	        last: '',
	        page: '',
		});
		return false;
	}
	$("#itgralType").html("");
	$("#starttime").val("");
	$("#endtime").val("");
	$("#starttime").datetimepicker('setStartDate',"");
	$("#starttime").datetimepicker('setEndDate',"");
	currentPage  = 1;
	offset = 0;
	limit = 10;
	moreintegral();
}
function moreintegral(){
	if($("#starttime").val()=='' && $("#endtime").val()!=''){
		$("#starttime").focus();
		return false;
	}
	if($("#starttime").val()!='' && $("#endtime").val()==''){
		$("#endtime").focus();
		return false;
	}
	var wSearchParms = {};
	wSearchParms.starttime=$("#starttime").val();
	wSearchParms.endtime=$("#endtime").val();
	if($("#itgralType").val()!=null && $("#itgralType").val()!=""){
		wSearchParms.igalType = $("#itgralType").val();
	}else{
		wSearchParms.igalType = igalType;
	}
	wSearchParms.dealerId=$("#dealer").val();
	wSearchParms.offset = offset;
	wSearchParms.limit  = limit;
	$.ajax({
		type: "POST",
	    url: "customer/integral/flowing",
	    dataType:"json",
	    async:false,//取消异步请求
	    contentType : 'application/json',
	    data: JSON.stringify(wSearchParms),
	    success:function(r){
	    	var integrals = eval(r.inFlowings);
	    	var total = eval(r.total);
	    	var itgralTypes = eval(r.itgralTypes);
	    	var html="";
	    	if(integrals==null||integrals.length == 0){
	    		html+="<span style='font-size: 16px;position: absolute;left: 45%;top: 50%;'>还没有记录</span>";
	    		$("#pageInfo").html('');
	    		$.jqPaginator('#pagination', {
    				totalPages:1,
    				first:'',
    		        prev: '',
    		        next: '',
    		        last: '',
    		        page: '',
	    		});
	    	}else{
		    	for(var i in integrals){
		    		var integral = integrals[i];
		    		if(integral.amount<0){
		    			zf = "";
		    		}else{
		    			zf = "+";
		    		}
		    		html+="<tr style='border-bottom:1px solid #ddd;'>" +
			    			  "<td>"+integral.insertDate+"</td>" +
			    			  "<td><span class='text_red'>"+zf+integral.amount+"</span></td>" +
			    			  "<td>"+integral.typeName+"</td>" +
			    			  "<td>"+integral.describes+"</td>" +
	    				  "<tr>";
		    	}
	    	}
	    	if(wSearchParms.igalType=="get" || wSearchParms.igalType =="out"){
		    	var itgralTypehtml = "<option value=''>类型</option>";
		    	for(var i in itgralTypes){
		    		var itgralType = itgralTypes[i];
		    		itgralTypehtml+="<option value='"+itgralType.key+"'>"+itgralType.value+"</option>";
		    		
		    	}
		    	$("#itgralType").html(itgralTypehtml);
	    	}
	    	$("#igflowing").html(html);
	    	loadData(currentPage,total);
	    },
	    complete:function(){
	    	
	    }
	});
}