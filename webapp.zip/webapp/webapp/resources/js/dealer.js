var dealerPage={dicId:'',rmbInOut:'',rebatePeriodType:'',isKhzj:'',orderby:'default_sort',orderType:'',offset:'',limit:'',dealerName:''};
var availableTags =[];
var orderNum=[0,0];
var offset=0;
var limit = 18;
var currentPage = 1;
var dealerId=new Array();
var dealerName=new Array();
var compareNum=0;
$(function() {
	
	$(".nfx-step-row").hover(function(){
		changeNfcSetp(this);
	});

	setInterval(function(){
		var content_w=$(".hot-product-row .content").width();
		var $table=$(".hot-product-row .content table");	
		var table_left=parseInt($table.css("left"));
		var table_w=$table.width();
		if((table_left+table_w-200)<=content_w){
			$table.animate({"left": '-='+(table_left) }, 1000);
		}else{
			$table.animate({"left": '+='+(0-content_w) }, 1000);	
		}
	},5000);
	
	dealerPage.offset=1;
	$("#btn_jgjg_all").attr("class","btn btn-red2");
	$("#btn_fxzq_all").attr("class","btn btn-red2");
	$("#btn_rmbout_all").attr("class","btn btn-red2");
	initDate();
	initDealerItem();
	updateItemCount();
	
	
	$('#tags').keydown(function(e){
		if(e.keyCode==13){
			dealerPage={dicId:'',rmbInOut:'',rebatePeriodType:'',isKhzj:'',orderby:'',orderType:'',offset:'',dealerName:''};
			var className=$("#ckKgzj").attr("class");
			if(className.indexOf("checked")>0){
				dealerPage.isKhzj="1";
			}else{
				dealerPage.isKhzj="0";
			}
			dealerPage.offset=1;
			dealerPage.dealerName=$("#tags").val();
			initDate("search");
		}
	});
	
	
	$("#dealer_search").click(function(){
		dealerPage={dicId:'',rmbInOut:'',rebatePeriodType:'',isKhzj:'',orderby:'',orderType:'',offset:'',dealerName:''};
		var className=$("#ckKgzj").attr("class");
		if(className.indexOf("checked")>0){
			dealerPage.isKhzj="1";
		}else{
			dealerPage.isKhzj="0";
		}
		dealerPage.offset=1;
		dealerPage.dealerName=$("#tags").val();
		initDate("search");
	});
	
	$("#orderByDef").click(function(){
//		dealerPage.dealerName='';
		dealerPage.orderby="default_sort";
		orderNum[0]=0;
		$("#orderByRj").parent().attr("class","sort-item");
		$("#orderByfx").parent().attr("class","sort-item");
		initDate(null);
	});
	
	var orderByfxClass="";
	var orderByRjClass="";
	dealerPage.orderType="";

	$("#orderByfx").click(function(){
//		dealerPage.dealerName='';
		orderByfxClass=$("#orderByfx").parent().attr("class");
		$("#orderByRj").parent().attr("class","sort-item");
		orderNum[1]=0;
		if(orderNum[0]>1){
			orderNum[0]=0;
			$("#orderByfx").parent().attr("class",orderByfxClass.replace("sort-down",""));
			dealerPage.orderType="";
		}else{
			if(orderNum[0]==0){
				$("#orderByfx").parent().addClass("sort-up");
				dealerPage.orderType="";
			}else{
				$("#orderByfx").parent().attr("class",orderByfxClass.replace("sort-up","sort-down"));
				dealerPage.orderType="1";
			}
			dealerPage.orderby="forex_ratio";
			orderNum[0]+=1;
			initDate(null);
		}
	});
	$("#orderByRj").click(function(){
//		dealerPage.dealerName='';
		orderByRjClass=$("#orderByRj").parent().attr("class");
		$("#orderByfx").parent().attr("class","sort-item");
		orderNum[0]=0;
		if(orderNum[1]>1){
			orderNum[1]=0;
			$("#orderByRj").parent().attr("class",orderByRjClass.replace("sort-down",""));
			dealerPage.orderType="";
		}else{
			if(orderNum[1]==0){
				$("#orderByRj").parent().addClass("sort-up");
				dealerPage.orderType="";
			}else{
				$("#orderByRj").parent().attr("class",orderByRjClass.replace("sort-up","sort-down"));
				dealerPage.orderType="1";
			}
			dealerPage.orderby="min_money";
			orderNum[1]+=1;
			initDate(null);
		}
	});	
	
	$("#ckKgzj").click(function(){
//		dealerPage.dealerName='';
		var className=$("#ckKgzj").attr("class");
		if(className.indexOf("checked")>0){
			dealerPage.isKhzj="1";
		}else{
			dealerPage.isKhzj="0";
		}
		initDate(null);
	});
	
	
	
});

$(".btn-defaults").mouseover(function(){
	if($(this).attr("class")=="btn btn-defaults"){
		$(this).attr("class","btn btn-defaults");
	}
});

function jgjgClick(obj,id){
	dealerPage.dicId=id
	changeA("btn_jgjg",obj);
	initDate(null);
}

function fxzqClick(obj,id){
	dealerPage.rebatePeriodType=id;
	changeA("btn_fxzq",obj);
	initDate(null);
}

function rmbClick(obj,id){
	dealerPage.rmbInOut=id;
	changeA("btn_rmbout",obj);
	initDate(null);
}

function changeA(name,obj){
	$("a[name='"+name+"']").each(function(){
		if(this.text==obj.text){
			$(this).attr("class","btn btn-red2");
		}else{
			$(this).attr("class","btn btn-defaults");
		}
	});
}

function initDate(type){
	$("#dealerList").remove();
	$("#noDealer").remove();
	var html="";
	$.ajax({
		url:'broker/list',
		type:'post',
		async:false,
		data:{dicId:dealerPage.dicId,
			  rmbInOut:dealerPage.rmbInOut,
			  rebatePeriodType:dealerPage.rebatePeriodType,
			  isKhzj:dealerPage.isKhzj,
			  orderby:dealerPage.orderby,
			  offset:dealerPage.offset,
			  orderType:dealerPage.orderType,
			  dealerName:dealerPage.dealerName,
		},
		success:function(r){
			r=eval("("+r+")");
			if(r.list.length==0&&type=="search"){
				html+="<div id='noDealer' class='col-left' style='background-color: #fff; min-height: 1000px; padding-top: 100px;'>"
					+"<div class='searh-noresult' style='width: 540px;margin: 0 auto;'>"
					+"<img src='resources/images/search-noresult.png' />"
					+"<p style='padding-top: 50px;font-size: 18px;line-height: 1.8;'>"
                	+"抱歉，没有找到“"+$("#tags").val()+"”交易商，您可以联系客服，我们将协助您获得该交易商返佣，或选择其他优质交易商开户。"
                    +"</p>"
                    +"</div>"
                    +"</div>";
				$("#dealers").append(html);
			}else{
				for(var i in r.list){
					dealerName[r.list[i].dealerId]=r.list[i].name
					html += "<div class='brk-box'>"
						+ "<div class='brk-box-p1' style='width: 280px;'>"
						+ "<div class='pic'><img style='width: 100%;height: 100%;' src='showFile?url="+r.list[i].logoUrl3+"' /></div>"
						+ "<div class='ft'><p style='margin-top: 20px;font-size: 26px;;'>"+r.list[i].chnName+r.list[i].name+"</p></div>"
						+ "</div><!-- /.brk-box-p1 -->"
						+ "<div class='brk-box-p2'>"
						+ "<div class='hd'>"
						+ "<span class='titl'>"+r.list[i].name+r.list[i].chnName+"</span>"
						+ "<span class='more'></span>"
						+ "</div>"
						+ "<div class='bd'>"
						+ "<div class='list-item'><span class='titl'>• 返现周期</span><span class='right'>"+changeNull(r.list[i].rebatePeriodTypeName)+"</span></div>"
						+ "<div class='list-item'><span class='titl'>• 外汇</span><span class='right'>"+changeNull(r.list[i].forexRatio)+"</span></div>"
						+ "<div class='list-item'><span class='titl'>• 黄金</span><span class='right'>"+changeNull(r.list[i].goldRatio)+"</span></div>"
						+ "</div>"
						+ "<div class='btn-row'>"
						+ "<a class='btn btn-blue2' target='_blank' style='width: 170px; font-size: 15px; line-height: 38px; padding: 0;' href='broker/detail/"+r.list[i].dealerId+"'>查看详情</a>"
						+ "</div>"
						+ "<div class='ft'>"
						+ "<div class='row' style='padding: 10px; font-size: 12px;'>"
						+ "<div class='col-sm-6' style='text-align: left;'><p ><img align='absmiddle' src='resources/images/broker-list/icon-square.png' /> 点差信息</p></div>"
						+ "<div class='col-sm-6' style='text-align: right;'><label><input name='ckCompare' type='checkbox' onclick='addCompare(this,"+r.list[i].dealerId+");' id="+r.list[i].dealerId+" value='"+r.list[i].logoUrl+"'/> 加入对比</label></div>"
						+ "</div>"
						+ "<div class='row' style='text-align: left;padding : 0 10px; font-size: 14px;white-space: nowrap;'>"
						+ "<span>欧美: <span class='text_blue'>"+changeNull(r.list[i].occidentPips)+"</span></span>"
						+ "<span style='padding: 0 30px;'>黄金: <span class='text_blue'>"+changeNull(r.list[i].goldPips)+"</span></span>"
//						+ "<span>离岸人民币: <span class='text_blue'>"+changeNull(r.list[i].cnh)+"</span></span>"
						+ "</div></div></div></div>"
				}
				$("#dealers").append("<div id='dealerList' class='col-left'>"+html+
							"<div class='page-block' style='clear: left;'>"+
						       "<ul id='pageInfo'></ul>"+
						       "<ul class='pagination' id='pagination'></ul>"+
			        		"</div>"+
						"</div>");
			}
			loadData(currentPage,r.total);
			var j=0;
			for(var i in r.dealerList){
				availableTags[i]=r.dealerList[i].name;
				availableTags[r.dealerList.length+j]=r.dealerList[i].chnName;
				j++;
			}
			$( "#tags" ).autocomplete({
			      source: availableTags
			});
		}
	});
}


var itemDiv=$("#pop-compare-brokers").find(".compare-items").find(".dealer-item");
function addCompare(obj,id){
	if(obj.checked==true){
		if(dealerId.length>0){
			compareNum=dealerId.length;
		}
		if(compareNum<4){
			dealerId[compareNum]=new Array();
			dealerId[compareNum][0]=id;
			dealerId[compareNum][1]=obj.value;
			compareNum+=1;
			$(obj).parents(".brk-box").find(".brk-box-p2").css("display","block");
			$(obj).parents(".brk-box").find(".brk-box-p1").css("display","none");
		}else{
//			alert("最多对比4个交易商");
			$("#ck_message").modal();
			obj.checked = false;
		}
	}else{
		removeByValue(dealerId,id);
		compareNum-=1;
		$(obj).parents(".brk-box").find(".brk-box-p2").css("display","");
		$(obj).parents(".brk-box").find(".brk-box-p1").css("display","");
	}
	addCookieDealer();
	initItem();
	updateItemCount();
	$("#pop-compare-brokers").attr("class","");
	initDealerItem();
}

window.onfocus = function() {
	dealerId=new Array();
	initDealerItem();
	updateItemCount();
	
}

function initDealerItem(){
	var dealerItem=getCookieValue("dealerItem");
	if(null!=dealerItem&&""!=dealerItem){
		$("#pop-compare-brokers").attr("class","");
		var cookieArr=dealerItem.split(",");
		compareNum=cookieArr.length-1;
		for(var i=0;i<cookieArr.length-1;i++){
			dealerId[i]=new Array();
			dealerId[i][0]=cookieArr[i].split("||")[0];
			dealerId[i][1]=cookieArr[i].split("||")[1];
		}
		initItem();
	}else{
		compareNum=0;
		$("#pop-compare-brokers").attr("class","hide");
	}
	$("input[name='ckCompare").each(function(){
		var id=$(this).attr("id");
		var ckTrue=$(this).parents(".brk-box-p2")[0];
		var ckFalse=$(this).parents(".brk-box-p2").prev(".brk-box-p1")[0];
		if(inArrays(dealerId,id)){
			$(this).prop("checked",true);
			$(ckTrue).css("display","block");
			$(ckFalse).css("display","none");
		}else{
			$(this).prop("checked",false);
			$(ckFalse).css("display","");
			$(ckTrue).css("display","");
		}
	});
}

function addCookieDealer(){
	var str="";
	for(var i=0;i<dealerId.length;i++){
		str+=dealerId[i][0]+"||"+dealerId[i][1]+",";
	}
	addCookie("dealerItem",str,0);
}

function initItem(){
	for(var i=0;i<4;i++){
		itemDiv[i].className="dealer-item no-item";
		itemDiv[i].innerHTML="<span class='item-num'>"+(i+1)+"</span>"
		+"<span class='add-item'>你还可以继续添加</span>";
	}
	if(dealerId!=null){
		for(var i=0;i<dealerId.length;i++){
			itemDiv[i].className="dealer-item has-item";
			itemDiv[i].innerHTML="<span class='item-name'>"+dealerName[dealerId[i][0]]+" &gt;</span>"
			+"<div class='item-logo'><img src='showFile?url="+dealerId[i][1]+"' title='"+dealerName[dealerId[i][0]]+"' name='"+dealerId[i][0]+"'></div>"
			+"<a class='remove-item'></a>";
		}
	}
}

$("#pop-compare-brokers").on("click",".remove-item",function(event){//移除item
	event.preventDefault();
	var id=$(this).parent().find("img")[0].name;
	removeByValue(dealerId,id);
	compareNum-=1;
	addCookieDealer();
	initItem();
	updateItemCount();
	initDealerItem();
});

$("#pop-compare-brokers").find(".del-items").click(function(event){//清空对比栏
	event.preventDefault();
	compareNum=0;
	dealerId=[];
	addCookie("dealerItem","",-1);
	initItem();
	updateItemCount();
	initDealerItem();
});


function updateItemCount(){//更新item数量
	$("#pop-compare-brokers").find(".item-count").text($("#pop-compare-brokers").find(".has-item").length);
	//更新 item-num 数据
	$("#pop-compare-brokers .compare-items .no-item").each(function(){
		var $self=$(this);
		$self.find(".item-num").html(1+$self.index());
	});
}

function loadData(num,total){
	var myPageCount = total;
    var myPageSize = limit;
    var countindex =  Math.ceil(myPageCount/myPageSize);
    loadpage(countindex,myPageCount,num);
}


function loadpage(countindex,myPageCount,num) {
    $.jqPaginator('#pagination', {
        totalPages: countindex,
        visiblePages: 5,
        currentPage: num,
        first: '<li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',
        onPageChange: function (num, type) {
            if (type == "change") {
            	currentPage  = num;
            	offset = limit * (num-1);
            	dealerPage.offset=num;
            	initDate(null);
//            	$(window).scrollTop($("#startTop").offset().top);
            	$('html,body').animate({scrollTop:$('#startTop').offset().top-100}, 800);
//            	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
            }
        }
    });
	$("#pagination").jqPaginator('option', { 
		totalPages: countindex,
		totalCounts:myPageCount,
	});
	$("#pagination li").eq(0).before('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
}

function removeByValue(arr, val) {
  for(var i=0; i<arr.length; i++) {
	  if(arr[i][0]== val) {
	      arr.splice(i, 1);
	      break;
	  }
  }
}

function inArrays(arr, obj) {  
	if(arr==null)return false;
    var i = arr.length;  
    while (i--) {  
        if (arr[i][0] === obj) {  
            return true;  
        }  
    }  
    return false;  
}  

function changeNull(object){
	object=$.trim(object);
	  if(object==null||object=="null"||object==" "||object==""){
		  object="--";
	  }
	  return object;
}