﻿function exeData(num, type) {
    loadData(num);
    loadpage();
}
function loadData(num){

	$("#pagecontext").html(num);
	var myPageCount = "120";
    var myPageSize = "5";
    var countindex = myPageCount % myPageSize > 0 ? (myPageCount / myPageSize) + 1 : (myPageCount / myPageSize);
	loadpage();
	$("#pagination").jqPaginator('option', { 
		totalPages: countindex
	});
	
}

function loadpage() {
    $.jqPaginator('#pagination', {
        totalPages: 10,
        visiblePages: 5,
        currentPage: 1,
        first: '<li><span class="">188条记录 1/13页</span></li><li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',
        onPageChange: function (num, type) {
            if (type == "change") {
                exeData(num, type); 
            }
        }
    });
}
$(function () {
    loadData(1);
});
