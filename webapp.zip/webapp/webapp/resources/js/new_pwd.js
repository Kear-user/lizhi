$(function(){
	$("#newpwd_error").css("display","none");
	$("#newpwd_like_error").css("display","none");
	$("#floatip_arrow_error").css("display","none");
	$("#save_error").css("display","none");
	
	$("#newPassWord").bind('input propertychange', function() { 
		var pwd=$.trim($("#newPassWord").val());
		var pwdAgain=$.trim($("#againNewPwd").val());
		$("#newpwd_error").html("");
		$("#newpwd_error").css("display","none");
		if(pwd==""||pwd.length==0){
			$("#newpwd_error").html("");
			$("#newpwd_error").css("display","none");
		}
		if(pwd.length<6||pwd.length>20){
			$("#newpwd_error").html("请输入6-20位密码");
			$("#newpwd_error").attr("class","vld-error");
			$("#newpwd_error").css("display","block");
		}
		if(pwd!=pwdAgain&&pwdAgain!=""){
		    $("#newpwd_like_error").html("两次输入的密码不一致");
		    $("#newpwd_like_error").css("display","block");
		    $("#floatip_arrow_error").css("display","block");
		}else{
			$("#newpwd_like_error").html("");
			$("#newpwd_like_error").css("display","none");
			$("#floatip_arrow_error").css("display","none");
		}
	});
	
	$("#againNewPwd").bind('input propertychange', function() { 
		var pwd=$.trim($("#newPassWord").val());
		var pwdAgain=$.trim($("#againNewPwd").val());
		if(pwd!=pwdAgain){
		    $("#newpwd_like_error").html("两次输入的密码不一致");
		    $("#newpwd_like_error").css("display","block");
		    $("#floatip_arrow_error").css("display","block");
		}else{
			$("#newpwd_like_error").html("");
			$("#newpwd_like_error").css("display","none");
			$("#floatip_arrow_error").css("display","none");
		}
	});
	
	$("#btn_save_sub").click(function(){
		$("#save_error").html("");
		$("#save_error").css("display","none");
		var pwd=$.trim($("#newPassWord").val());
		var pwdAgain=$.trim($("#againNewPwd").val());
		if(pwd==""||pwd.length==0){
			$("#newpwd_error").html("请输入新密码");
			$("#newpwd_error").css("display","block");
		}else 
			if(pwd.length<6||pwd.length>20){
				$("#newpwd_error").html("请输入6-20位密码");
				$("#newpwd_error").attr("class","vld-error");
				$("#newpwd_error").css("display","block");
		}else 
			if(pwdAgain!=pwd){
				 $("#newpwd_like_error").html("两次输入的密码不一致");
				 $("#newpwd_like_error").css("display","block");
				 $("#floatip_arrow_error").css("display","block");
		}else{
			$("#form_save_newpwd").cryptPOST({
				success : function(r) {
					if(r.code==0){
						window.location.href=$("#basePath").val()+"user/success_save";
					}else{
						$("#save_error").html(r.msg);
						$("#save_error").css("display","block");
					}
				}
			});
		}
	});
	
});