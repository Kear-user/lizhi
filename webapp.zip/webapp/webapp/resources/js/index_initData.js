var resultArray = new Array();
var ws;
var flagTimer;
var judgeTimer;
var judgeFlag = true;
function resetTimeout(){
    //星期六、星期天就不会再断线重连了。
    var date = new Date();
    if(date.getDay().toString() == "0" || date.getDay().toString() == "6"){
        return;
    }
    if(flagTimer){
        clearTimeout(flagTimer);
    }
    flagTimer = setTimeout(function(){
        getProData();
    },10000);
}

//获取实时点差数据
getProData();

function getProData(){
	if(ws){
		ws.close();
		ws=null;
	}
	resetTimeout();
	ws = new WebSocket("ws://119.28.20.55:7002");
	ws.onopen = function(event){
        ws.send("m&s&1,2,4,5,6,7,8,9,10,11,12,13,14,15,17,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,48");
    };
    //监听消息
    ws.onmessage = function(event){
		if(event.data == "m&s"){
			ws.send("m&i&1");
			resetTimeout();
        }
        var msg = event.data.split("&");
         if(msg.length < 1){
              return ;
         }
         if(msg[0] == "mtd"){
              getData(msg);
         }
    };
    // 监听Socket的关闭
    ws.onclose = function(event) {
    	/**
        console.log('Client notified socket has closed',event);
        */
    };

    // 监听Socket的关闭
    ws.onerror = function(event) {
    	/**
        console.log('Client notified socket has error',event);
        */
    };
}
function getData(msg){
	var msgStr = msg.toString();
	var arrayTemp = msgStr.split(",");
	var num=arrayTemp[1];
	var dateT=arrayTemp[6];
	var dateF=dateT.substr(0,4)+"-"+dateT.substr(4,2)+"-"+dateT.substr(6,2)+" "+dateT.substr(8,2)+":"+dateT.substr(10,2)+":"+dateT.substr(12,2);
	var item={
		buyN:arrayTemp[3],
		sellN:arrayTemp[4],
		diancha:arrayTemp[5],
		dateN:dateF
	};
	
	resultArray[num]=item;
	getFinallyData(num);
	if(num==11){
		num+="T";
		getFinallyData(num);
	}
}
function getNumColor(id,dataNum){
	var code=document.getElementById(id);
	if(id=="buyN9"||id=="sellN9"||id=="diancha9"||id=="shijichengben9"){
		if(parseFloat(code.getAttribute("data-num"))>dataNum){
			judgeFlag = false;
			if(judgeTimer){
				clearTimeout(judgeTimer);
			}
			judgeTimer = setTimeout(function(){
				judgeFlag = true;
			},300);
			code.style.color='#dd292c';
		}else if(parseFloat(code.getAttribute("data-num"))<dataNum){
			judgeFlag = false;
			if(judgeTimer){
				clearTimeout(judgeTimer);
			}
			judgeTimer = setTimeout(function(){
				judgeFlag = true;
			},300);
			code.style.color='green';
		}else{
			if(judgeFlag){
				code.style.color='#6e6e6e';
			}
		}
	}else{
		if(parseFloat(code.getAttribute("data-num"))>dataNum){
			code.style.color='#dd292c';
		}else if(parseFloat(code.getAttribute("data-num"))<dataNum){
			code.style.color='green';
		}else{
			code.style.color='#6e6e6e';
		}
	}
}
function CurentTime(){ 
        var now = new Date();
        var year = now.getFullYear();       //年
        var month = now.getMonth() + 1;     //月
        var day = now.getDate();            //日
        var hh = now.getHours();            //时
        var mm = now.getMinutes();          //分
		var ss = now.getSeconds();			//秒

        var clock = year + "-";
       
        if(month < 10)
            clock += "0";
       
        clock += month + "-";
       
        if(day < 10)
            clock += "0";
           
        clock += day + " ";
       
        if(hh < 10)
            clock += "0";
           
        clock += hh + ":";
        if (mm < 10) clock += '0'; 
        clock += mm + ":"; 
		if (ss < 10) clock += '0';
		clock += ss;
        return(clock); 
} 
function getFinallyData(num){
	var keyNum = num.replace(/[^0-9]/ig,"");
	if(resultArray.length!=0){
		if(!(document.getElementById("sellN"+num))){
			return;
		}
		var buyN = document.getElementById("buyN"+num);
		var sellN = document.getElementById("sellN"+num);
		//var diancha = document.getElementById("diancha"+num);
		var shijichengben = document.getElementById("shijichengben"+num);
		//得到时间成本值
		var shijichengbenV;
		if(typeIdArray[keyNum]==2){
			shijichengbenV=resultArray[keyNum].diancha*(1-waiHuiArray[keyNum]);
		}else{
			shijichengbenV=resultArray[keyNum].diancha-waiHuiArray[keyNum];
		}
		//获取交易商时间
		//document.getElementById("dateN"+num).innerHTML=resultArray[num].dateN;
		//获取当前系统时间
		getNumColor("buyN"+num,parseFloat(resultArray[keyNum].buyN).toFixed(5));
		buyN.setAttribute("data-num",parseFloat(resultArray[keyNum].buyN).toFixed(5));
		buyN.innerHTML=parseFloat(resultArray[keyNum].buyN).toFixed(5);
		getNumColor("sellN"+num,parseFloat(resultArray[keyNum].sellN).toFixed(5));
		sellN.setAttribute("data-num",parseFloat(resultArray[keyNum].sellN).toFixed(5));
		sellN.innerHTML=parseFloat(resultArray[keyNum].sellN).toFixed(5);
		/*if(num==9){
			diancha.innerHTML="--";
			shijichengben.innerHTML="--";
			return;
		}else{*/
		//getNumColor("diancha"+num,parseFloat(resultArray[keyNum].diancha).toFixed(2));
		//diancha.setAttribute("data-num",parseFloat(resultArray[keyNum].diancha).toFixed(2));
		//diancha.innerHTML=parseFloat(resultArray[keyNum].diancha).toFixed(2);
		
		getNumColor("shijichengben"+num,(resultArray[keyNum].diancha-waiHuiArray[keyNum]).toFixed(2));
		shijichengben.setAttribute("data-num",shijichengbenV.toFixed(2));
		shijichengben.innerHTML=shijichengbenV.toFixed(2);
		/*}*/
	}
}

var waiHuiArray = new Array();
var typeIdArray=new Array();
var accttypeArray=new Array();
var nameToPro = [{name:"FxPro浦汇",proName:"1",typeId:"1",waihui:"0.88"},
                 {name:"XM",proName:"2",typeId:"1",waihui:"0.9"},
                 {name:"FXCM福汇",proName:"4",typeId:"1",waihui:"0.25"},
                 {name:"ThinkMarkets智汇",proName:"5",typeId:"1",waihui:"0.4"},
                 {name:"Exness",proName:"6",typeId:"1",waihui:"0.36"},
                 {name:"IFX爱福斯",proName:"7",typeId:"1",waihui:"0.6"},
                 {name:"Forex Club福瑞斯",proName:"8",typeId:"1",waihui:"0.9"},
                 {name:"LMAX",proName:"9",typeId:"1",waihui:"0.0"},
                 {name:"GKFX捷凯金融",proName:"10",typeId:"1",waihui:"0.0"},
                 {name:"Forex(CAY)嘉盛(开曼)",proName:"11T",typeId:"1",waihui:"0.64"},
                 {name:"Forex(UK)嘉盛(英国)",proName:"11",typeId:"1",waihui:"0.64"},
                 {name:"OANDA安达",proName:"12",typeId:"1",waihui:"0.24"},
                 {name:"AETOS艾拓思",proName:"13",typeId:"1",waihui:"1.08"},
                 {name:"VantageFX万致",proName:"14",typeId:"1",waihui:"1.0"},
                 {name:"GMI",proName:"15",typeId:"",waihui:""},
                 {name:"MARKETS迈肯司",proName:"17",typeId:"2",waihui:"0.28"},
                 {name:"icmcapital",proName:"22",typeId:"",waihui:""},
                 {name:"IC Markets",proName:"23",typeId:"1",waihui:"0.32"},
                 {name:"TICKMILL",proName:"24",typeId:"1",waihui:"0.8"},
                 {name:"britanniafx",proName:"25",typeId:"1",waihui:"0.8"},
                 {name:"SVSFX",proName:"26",typeId:"1",waihui:"0.0"},
                 {name:"gmo",proName:"27",typeId:"",waihui:""},
                 {name:"kvbkunlun",proName:"28",typeId:"",waihui:""},
                 {name:"ausforex",proName:"29",typeId:"",waihui:""},
                 {name:"formax",proName:"30",typeId:"",waihui:""},
                 {name:"AVATRADE",proName:"31",typeId:"2",waihui:"0.32"},
                 {name:"charterprime",proName:"32",typeId:"",waihui:""},
                 {name:"mdf",proName:"33",typeId:"",waihui:""},
                 {name:"TAHOE泰浩",proName:"34",typeId:"1",waihui:"0.9"},
                 {name:"AXITRADER",proName:"35",typeId:"1",waihui:"0.5"},
                 {name:"roboforex",proName:"36",typeId:"",waihui:""},
                 {name:"gomarkets",proName:"37",typeId:"",waihui:""},
                 {name:"henyep",proName:"38",typeId:"",waihui:""},
                 {name:"usgfx",proName:"39",typeId:"",waihui:""},
                 {name:"pepperstone",proName:"40",typeId:"",waihui:""},
                 {name:"infinoxcapital",proName:"41",typeId:"",waihui:""},
                 {name:"xcoq",proName:"42",typeId:"",waihui:""},
                 {name:"ig",proName:"43",typeId:"",waihui:""},
                 {name:"ADS达汇",proName:"44",typeId:"1",waihui:"1.0"},
                 {name:"ABS澳盛",proName:"46",typeId:"1",waihui:"0.8"},
                 {name:"FIBO飞博",proName:"47",typeId:"1",waihui:"0.8"},
                 {name:"LCG",proName:"48",typeId:"1",waihui:"0.5"}];

function initTypeAndForex(){
	for(var i=0;i<nameToPro.length;i++){
		var x = nameToPro[i].proName;
		typeIdArray[x]=nameToPro[i].typeId;
		waiHuiArray[x]=nameToPro[i].waihui;
	}
}

initTypeAndForex();