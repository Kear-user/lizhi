/*!
 * jQuery Form crypt Plugin
 * version: 1.0.0-2017.05.20
 * Requires jQuery v1.5 or later
 * Copyright (c) cyg bcic
 */
(function (root, factory)
{
	if (typeof exports !== 'undefined' && typeof module !== 'undefined' && module.exports) {
		// NodeJS
		module.exports = factory();
	} else if (typeof define === 'function' && define.amd) {
		// AMD. Register as an anonymous module.
		define(factory);
	} else {
		// Browser globals
		root.form2js = factory();
	}
}(this, function ()
{
	"use strict";

	/**
	 * Returns form values represented as Javascript object
	 * "name" attribute defines structure of resulting object
	 *
	 * @param rootNode {Element|String} root form element (or it's id) or array of root elements
	 * @param delimiter {String} structure parts delimiter defaults to '.'
	 * @param skipEmpty {Boolean} should skip empty text values, defaults to true
	 * @param nodeCallback {Function} custom function to get node value
	 * @param useIdIfEmptyName {Boolean} if true value of id attribute of field will be used if name of field is empty
	 */
	function form2js(rootNode, delimiter, skipEmpty, nodeCallback, useIdIfEmptyName, getDisabled) {
		getDisabled = getDisabled ? true : false;
		if (typeof skipEmpty == 'undefined' || skipEmpty == null) skipEmpty = true;
		if (typeof delimiter == 'undefined' || delimiter == null) delimiter = '.';
		if (arguments.length < 5) useIdIfEmptyName = false;

		rootNode = typeof rootNode == 'string' ? document.getElementById(rootNode) : rootNode;

		var formValues = [],
			currNode,
			i = 0;

		/* If rootNode is array - combine values */
		if (rootNode.constructor == Array || (typeof NodeList != "undefined" && rootNode.constructor == NodeList)) {
			while(currNode = rootNode[i++]) {
				formValues = formValues.concat(getFormValues(currNode, nodeCallback, useIdIfEmptyName, getDisabled));
			}
		} else {
			formValues = getFormValues(rootNode, nodeCallback, useIdIfEmptyName, getDisabled);
		}

		return processNameValues(formValues, skipEmpty, delimiter);
	}

	/**
	 * Processes collection of { name: 'name', value: 'value' } objects.
	 * @param nameValues
	 * @param skipEmpty if true skips elements with value == '' or value == null
	 * @param delimiter
	 */
	function processNameValues(nameValues, skipEmpty, delimiter) {
		var result = {},
			arrays = {},
			i, j, k, l,
			value,
			nameParts,
			currResult,
			arrNameFull,
			arrName,
			arrIdx,
			namePart,
			name,
			_nameParts;

		for (i = 0; i < nameValues.length; i++) {
			value = nameValues[i].value;

			if (skipEmpty && (value === '' || value === null)) continue;

			name = nameValues[i].name;
			_nameParts = name.split(delimiter);
			nameParts = [];
			currResult = result;
			arrNameFull = '';

			for(j = 0; j < _nameParts.length; j++) {
				namePart = _nameParts[j].split('][');
				if (namePart.length > 1) {
					for(k = 0; k < namePart.length; k++) {
						if (k == 0) {
							namePart[k] = namePart[k] + ']';
						} else if (k == namePart.length - 1) {
							namePart[k] = '[' + namePart[k];
						} else {
							namePart[k] = '[' + namePart[k] + ']';
						}

						arrIdx = namePart[k].match(/([a-z_]+)?\[([a-z_][a-z0-9_]+?)\]/i);
						if (arrIdx) {
							for(l = 1; l < arrIdx.length; l++)
							{
								if (arrIdx[l]) nameParts.push(arrIdx[l]);
							}
						} else {
							nameParts.push(namePart[k]);
						}
					}
				} else
					nameParts = nameParts.concat(namePart);
			}

			for (j = 0; j < nameParts.length; j++) {
				namePart = nameParts[j];

				if (namePart.indexOf('[]') > -1 && j == nameParts.length - 1) {
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrNameFull += arrName;

					if (!currResult[arrName]) currResult[arrName] = [];
					currResult[arrName].push(value);
				} else if (namePart.indexOf('[') > -1) {
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrIdx = namePart.replace(/(^([a-z_]+)?\[)|(\]$)/gi, '');

					/* Unique array name */
					arrNameFull += '_' + arrName + '_' + arrIdx;

					/*
					 * Because arrIdx in field name can be not zero-based and step can be
					 * other than 1, we can't use them in target array directly.
					 * Instead we're making a hash where key is arrIdx and value is a reference to
					 * added array element
					 */

					if (!arrays[arrNameFull]) arrays[arrNameFull] = {};
					if (arrName != '' && !currResult[arrName]) currResult[arrName] = [];

					if (j == nameParts.length - 1) {
						if (arrName == '') {
							currResult.push(value);
							arrays[arrNameFull][arrIdx] = currResult[currResult.length - 1];
						} else {
							currResult[arrName].push(value);
							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					} else {
						if (!arrays[arrNameFull][arrIdx]) {
							if ((/^[0-9a-z_]+\[?/i).test(nameParts[j+1])) currResult[arrName].push({});
							else currResult[arrName].push([]);

							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					}

					currResult = arrays[arrNameFull][arrIdx];
				} else {
					arrNameFull += namePart;

					if (j < nameParts.length - 1) /* Not the last part of name - means object */{
						if (!currResult[namePart]) currResult[namePart] = {};
						currResult = currResult[namePart];
					} else {
						currResult[namePart] = value;
					}
				}
			}
		}

		return result;
	}

    function getFormValues(rootNode, nodeCallback, useIdIfEmptyName, getDisabled) {
        var result = extractNodeValues(rootNode, nodeCallback, useIdIfEmptyName, getDisabled);
        return result.length > 0 ? result : getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName, getDisabled);
    }

    function getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName, getDisabled) {
		var result = [],
			currentNode = rootNode.firstChild;
		
		while (currentNode) {
			result = result.concat(extractNodeValues(currentNode, nodeCallback, useIdIfEmptyName, getDisabled));
			currentNode = currentNode.nextSibling;
		}

		return result;
	}

    function extractNodeValues(node, nodeCallback, useIdIfEmptyName, getDisabled) {
        if (node.disabled && !getDisabled) return [];

        var callbackResult, fieldValue, result, fieldName = getFieldName(node, useIdIfEmptyName);

        callbackResult = nodeCallback && nodeCallback(node);

        if (callbackResult && callbackResult.name) {
            result = [callbackResult];
        } else if (fieldName != '' && node.nodeName.match(/INPUT|TEXTAREA/i)) {
            fieldValue = getFieldValue(node, getDisabled);
            if (null === fieldValue) {
                result = [];
            } else {
                result = [ { name: fieldName, value: fieldValue} ];
            }
        } else if (fieldName != '' && node.nodeName.match(/SELECT/i)) {
	        fieldValue = getFieldValue(node, getDisabled);
	        result = [ { name: fieldName.replace(/\[\]$/, ''), value: fieldValue } ];
        } else {
            result = getSubFormValues(node, nodeCallback, useIdIfEmptyName, getDisabled);
        }

        return result;
    }

	function getFieldName(node, useIdIfEmptyName) {
		if (node.name && node.name != '') return node.name;
		else if (useIdIfEmptyName && node.id && node.id != '') return node.id;
		else return '';
	}


	function getFieldValue(fieldNode, getDisabled) {
		if (fieldNode.disabled && !getDisabled) return null;
		
		switch (fieldNode.nodeName) {
			case 'INPUT':
			case 'TEXTAREA':
				switch (fieldNode.type.toLowerCase()) {
					case 'radio':
			if (fieldNode.checked && fieldNode.value === "false") return false;
					case 'checkbox':
                        if (fieldNode.checked && fieldNode.value === "true") return true;
                        if (!fieldNode.checked && fieldNode.value === "true") return false;
			if (fieldNode.checked) return fieldNode.value;
						break;

					case 'button':
					case 'reset':
					case 'submit':
					case 'image':
						return '';
						break;

					default:
						return fieldNode.value;
						break;
				}
				break;

			case 'SELECT':
				return getSelectedOptionValue(fieldNode);
				break;

			default:
				break;
		}

		return null;
	}

	function getSelectedOptionValue(selectNode) {
		var multiple = selectNode.multiple,
			result = [],
			options,
			i, l;

		if (!multiple) return selectNode.value;

		for (options = selectNode.getElementsByTagName("option"), i = 0, l = options.length; i < l; i++) {
			if (options[i].selected) result.push(options[i].value);
		}

		return result;
	}

	return form2js;

}));

(function (factory) {
    "use strict";
    if (typeof define === 'function' && define.amd) {
        // using AMD; register as anon module
        define(['jquery'], factory);
    } else {
        // no AMD; invoke directly
        factory( (typeof(jQuery) != 'undefined') ? jQuery : window.Zepto );
    }
}

(function($) {
	"use strict";
	
	function random(len) {
		var d, e, b ="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", c ="";
		for (d = 0; len > d; d += 1)
			e = Math.random() * b.length, e = Math.floor(e), c += b.charAt(e);
		return c
	}
	
	function encrypt(srcs){  
		var key = random(16);
		var location = Math.floor(Math.random()*10+1);
		var AES_KEY = CryptoJS.enc.Utf8.parse(key);
	    var iv = CryptoJS.enc.Utf8.parse(key.split('').reverse().join('')||key);
	    var opration = {iv:iv,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.ZeroPadding};
	    var encrypt = CryptoJS.AES.encrypt(srcs, AES_KEY, opration).toString();
	    
	    return location + encrypt.substring(0,location) + key + encrypt.substring(location);
	}  
	
	function decrypt(srcs){
		var location = parseInt(srcs.substring(0,1));
		var key = srcs.substring(location+1,location+17);
		srcs = srcs.substring(1,1+location) + srcs.substring(location+17);
		
		var AES_KEY = CryptoJS.enc.Utf8.parse(key);
	    var iv = CryptoJS.enc.Utf8.parse(key.split('').reverse().join('')||key);
	    var opration = {iv:iv,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.ZeroPadding};
	    var decrypt = CryptoJS.AES.decrypt(srcs, AES_KEY, opration);
	
	    return CryptoJS.enc.Utf8.stringify(decrypt);
	}
	
	function encryptJSON(srcs){  
		//return encrypt(JSON.stringify(srcs));
		return JSON.stringify(srcs);
	}  
	function decryptJSON(srcs){
	    //return JSON.parse(decrypt(srcs));
		return JSON.parse(srcs);
	}
	
	$.fn.clear = function(includeHidden) {
	    return this.each(function() {
	        $('input,select,textarea', this).clearFields(includeHidden);
	    });
	};
	$.fn.clearFields = $.fn.clearInputs = function(includeHidden) {
	    var re = /^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i; // 'hidden' is not in this list
	    return this.each(function() {
	        var t = this.type, tag = this.tagName.toLowerCase();
	        if (re.test(t) || tag == 'textarea') {
	            this.value = '';
	        }
	        else if (t == 'checkbox' || t == 'radio') {
	            this.checked = false;
	        }
	        else if (tag == 'select') {
	            this.selectedIndex = -1;
	        }
			else if (t == "file") {
				if (/MSIE/.test(navigator.userAgent)) {
					$(this).replaceWith($(this).clone(true));
				} else {
					$(this).val('');
				}
			}
	        else if (includeHidden) {
	            // includeHidden can be the value true, or it can be a selector string
	            // indicating a special test; for example:
	            //  $('#myForm').clearForm('.special:hidden')
	            // the above would clean hidden inputs that have the class of 'special'
	            if ( (includeHidden === true && /hidden/.test(t)) ||
	                 (typeof includeHidden == 'string' && $(this).is(includeHidden)) ) {
	                this.value = '';
	            }
	        }
	    });
	};

	//获取url中的参数
    function getUrlParam(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); 
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    }
        
	$.fn.cryptPOST = function(options) {
		var url = options.url  || $(this).attr('action');

	    url = (typeof url === 'string') ? $.trim(url) : '';
	    url = url || window.location.href || '';
	    if (url) {
	        // clean url (don't include hash vaue)
	        url = (url.match(/^([^#]+)/)||[])[1];
	    }

	    var method = options.type || $(this).attr('method') || 'POST';
	    var temp = form2js($(this).get(0));
		if (getUrlParam("ReturnURL")!=="undefined") {
			temp.ReturnURL = getUrlParam("ReturnURL");
		}
	    var data = encryptJSON(temp);
	    if (typeof data !=='undefined' && data.length>0) {
	    	var form = $(this);
			var loadingLayer = (typeof options.loadinglayer === 'string') ? $($.trim(options.loadinglayer)) : 
	                           (typeof options.loadinglayer === 'undefined') ? null : options.loadinglayer;
	        if (!loadingLayer) {
	        	var parent = $(this).parents('.modal-content');
	        	if (parent) loadingLayer = parent.get(0);
	        }
	        
	    	$.ajax({
				type: method, dataType:'text', contentType: "application/text;charset=utf-8",
				url: url, data: data, 
				context: this,
				beforeSend: function( xhr ) {
					if (loadingLayer)$(loadingLayer).loadingLayer({
                        // bgcolor: '#F6F6F6', 
                        // opacity: '0.5', 
                    	classname: 'loading-plug',
                        icon: 'resources/images/loader.gif'
                    });
                },
				success:function(r) {
					if (loadingLayer)$('#loading-plug').remove();
					if (options.success&&typeof(options.success)=="function") {
						var temp = decryptJSON(r.toString());
						options.success(temp);
						if (temp.code == 0)$(form).clear(true);
					}
				}, 
				error:function(XMLHttpRequest, textStatus, errorThrown) {
					if (loadingLayer)$('#loading-plug').remove();
					if (options.error&&typeof(options.error)=="function") {
						options.error(XMLHttpRequest, textStatus, errorThrown);
					} else {
						alert(textStatus);
					}
		        }
			});
	    }
	};
}));