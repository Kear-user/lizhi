function isSure(accountId,type){
	if(type==0){
		$("#isSureMsg").text("确认设置改账号为默认账号？");
		$("#dlg-issure-name").modal('show');
		$("#isSureMsg_btn").click(function(){
			setDefault(accountId);
		});
	}else if(type==1){
		$("#isSureMsg").text("确认删除该提现账号？");
		$("#dlg-issure-name").modal('show');
		$("#isSureMsg_btn").click(function(){
			cancelAccount(accountId);
		});
	}
}

//设置默认账号
function setDefault(accountId){
	$.get("ecustomeraccountinfo/updatedefault/"+accountId,function(r){
		var result = JSON.parse(eval(r));
		if(result.code==0){
			window.location.reload();
		}else{
			alert(result.msg);
		}
	});
}
//解绑提现账号
function cancelAccount(accountId){
	$.get("ecustomeraccountinfo/cancelamount/"+accountId,function(r){
		var result = JSON.parse(eval(r));
		if(result.code==0){
			window.location.reload();
		}else{
			alert(result.msg);
		}
	});
}
