$(function() {	
    var ele_pass = $("#zcPassWord");
	var ele_eye = $("#zc_pwd_i");
	ele_eye.click(function(){
		var state = this.getAttribute("state");
		if(state === "off") {
			ele_pass.attr("type", "text");
			ele_eye.attr("state", "on");
			ele_eye.css("opacity",0.5);
		} else {
			ele_pass.attr("type", "password");
			ele_eye.attr("state", "off");
			ele_eye.css("opacity",1);
		}
	});
    
    $("#zc_btn_sub_phone").attr("disabled",true);
	var formName="#form_zc_phone";
	$("#zcphone").click(function(){
		formName="#form_zc_phone";
	});
	$("#zcemail").click(function(){
		formName="#form_zc_email";
	});
	
	if(formName=="#form_zc_phone"){
		$("#phone_ok").css("display","none");
		$("#phone_error").html("");
		$("#phone_error").css("display","none");
		$("#sms_error").html("");
		$("#sms_error").css("display","none");
	}
	
	if(formName=="#form_zc_email"){
		$("#email_ok").css("display","none");
		$("#zc_email_error").html("");
		$("#zc_email_error").css("display","none");
		$("#zc_pwd_safe").html("");
		$("#zc_pwd_safe").css("display","none");
		$("#zc_pwd_like").html("");
		$("#zc_pwd_like").css("display","none");
	}
	
	var reg=/^1(3|4|5|7|8)\d{9}$/;
	$("#phone").bind('input propertychange', function() { 
		var phone=$.trim($("#phone").val());
		if(reg.test(phone)){
			$("#phone_ok").css("display","block");
			$("#zc_phone_error").html("");
			$("#zc_phone_error").css("display","none");
		}else{
			$("#phone_ok").css("display","none");
		}
	});
	//
//	var reg_email=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
	var reg_email=/^[A-Za-z0-9_-]+([-_.][A-Za-z0-9_-]+)*@([A-Za-z0-9_-]+[-.])+[A-Za-zd]{2,5}$/;
	$("#loginEamil").bind('input propertychange', function() { 
		var email=$.trim($("#loginEamil").val());
		if(reg_email.test(email)){
			$("#email_ok").css("display","block");
			$("#zc_email_error").html("");
			$("#zc_email_error").css("display","none");
		}else{
			$("#email_ok").css("display","none");
		}
	});
	$("#zcPassWord").bind('input propertychange', function() { 
		var pwd=$.trim($("#zcPassWord").val());
		var pwdAgain=$.trim($("#passWordAgain").val());
		if(pwd==""||pwd.length==0){
			$("#zc_pwd_safe").html("");
			$("#zc_pwd_safe").css("display","none");
		}
		if(pwd.length<6||pwd.length>20){
			$("#zc_pwd_safe").html("请输入6-20位密码");
			$("#zc_pwd_safe").attr("class","vld-error");
			$("#zc_pwd_safe").css("display","block");
		}else{
			$("#zc_pwd_safe").attr("class","vld-ok");
			CheckIntensity(pwd);
		}
		if(pwd!=pwdAgain&&pwdAgain!=""){
		    $("#zc_pwd_like").html("两次输入的密码不一致");
		    $("#zc_pwd_like").css("display","block");
		}else{
			$("#zc_pwd_like").html("");
			$("#zc_pwd_like").css("display","none");
		}
	});
	
	$("#passWordAgain").bind('input propertychange', function() { 
		var pwd=$.trim($("#zcPassWord").val());
		var pwdAgain=$.trim($("#passWordAgain").val());
		if(pwd!=pwdAgain){
		    $("#zc_pwd_like").html("两次输入的密码不一致");
		    $("#zc_pwd_like").css("display","block");
		}else{
			$("#zc_pwd_like").html("");
			$("#zc_pwd_like").css("display","none");
		}
	});
	
	
	$("#zcSmsCode").bind('input propertychange', function() { 
		var smsCode=$.trim($("#zcSmsCode").val());
		if(smsCode==""||smsCode.length==0){
			$("#zc_btn_sub_phone").attr("disabled",true);
		}else{
			if($("#phone_ck_go").is(":checked")){
				$("#zc_btn_sub_phone").attr("disabled",false);
			}else{
				$("#zc_btn_sub_phone").attr("disabled",true);
			}
		}
	});
	
	$("#phone_ck_go").click(function(){
		if($("#phone_ck_go").is(":checked")) {
			var smsCode=$.trim($("#zcSmsCode").val());
			if(smsCode==""||smsCode.length==0){
				$("#zc_btn_sub_phone").attr("disabled",true);
			}else{
				$("#zc_btn_sub_phone").attr("disabled",false);
			}
		}else{
			$("#zc_btn_sub_phone").attr("disabled",true);
		}
	});
	//
//    $("#btn_sub_email").attr("disabled",true);
	$("#email_ck_go").click(function(){
		if($("#email_ck_go").is(":checked")) {
			$("#btn_sub_email").attr("disabled",false);
		}else{
			$("#btn_sub_email").attr("disabled",true);
		}
	});
	
	//
	$("#zc_btn_sms_code").click(function(){
		var phone=$.trim($("#phone").val());
		if(phone==""||phone.length==0){
			$("#zc_phone_error").html("请输入手机号");
			$("#zc_phone_error").css("display","block");
		}else 
			if(!reg.test(phone)){
				$("#zc_phone_error").html("请输入正确的手机号");
				$("#zc_phone_error").css("display","block");
		}else{
			$.get("user/smsCode?phone="+phone+"&registType=0",function(r){
				r=eval("("+r+")");
				if(r.code==0){
					addCookie("zc_secondsremained",60,60);//
					settime($("#zc_btn_sms_code"));
					$("#zc_sms_error").html(r.msg);
					$("#zc_sms_error").attr("class","vld-ok");
					$("#zc_sms_error").css("display","block");
				}else{
					$("#zc_sms_error").html(r.msg);
					$("#zc_sms_error").attr("class","vld-error");
					$("#zc_sms_error").css("display","block");
				}
			});
		}
	});
	
	//
	$("#zc_btn_sub_phone").click(function(){
		$("#registTypePhone").attr("value",0);
		var phone=$.trim($("#phone").val());
		var smsCode=$.trim($("#zcSmsCode").val());
		if(phone==""||phone.length==0){
			$("#zc_phone_error").html("请输入手机号");
			$("#zc_phone_error").css("display","block");
		}else 
			if(!reg.test(phone)){
			$("#zc_phone_error").html("请输入正确的手机号");
			$("#zc_phone_error").css("display","block");
		}else 
			if(smsCode==""||smsCode.length==0){
			$("#zc_sms_error").html("请输入验证码");
			$("#zc_sms_error").css("display","block");
		}else{
			zcSub(formName,$("#zc_sms_error"),phone,"phone");
		}
	});
	
	//
	$("#btn_sub_email").click(function(){
		$("#registTypeEmail").attr("value",1);
		var email=$.trim($("#loginEamil").val());
		var zcPassWord=$.trim($("#zcPassWord").val());
		var pwdAgain=$.trim($("#passWordAgain").val());
		if(email==""||email.length==0){
			$("#zc_email_error").html("请输入邮箱");
			$("#zc_email_error").css("display","block");
		}else 
			if(!reg_email.test(email)){
			$("#zc_email_error").html("请输入正确的邮箱");
			$("#zc_email_error").css("display","block");
		}else 
			if(zcPassWord==""||zcPassWord.length==0){
			$("#zc_pwd_safe").html("请输入密码");
			$("#zc_pwd_safe").attr("class","vld-error");
			$("#zc_pwd_safe").css("display","block");
		}else 
			if(pwdAgain!=zcPassWord){
				$("#zc_pwd_like").html("两次输入的密码不一致");
				$("#zc_pwd_like").css("display","block");
		}else{
			if(zcPassWord.length<6||zcPassWord.length>20){
				$("#zc_pwd_safe").html("请输入6-20位密码");
				$("#zc_pwd_safe").attr("class","vld-error");
				$("#zc_pwd_safe").css("display","block");
			}else{
				zcSub(formName,$("#zc_pwd_like"),email,"email");
			}
		}
	});
});


function zcSub(formName,vld_error,name,type){
	$(formName).cryptPOST({
		success : function(r) {
			if(r.code==0){
				addCookie("zc_secondsremained",0,0);//
				if(type=="phone"){
					if(r.isphone){
						window.location.href="user/singUpSuccessWap?n="+name;
					}else{
						window.location.href="user/signUpSuccess?n="+name;
					}
					
				}
				if(type=="email"){
					addCookie("sendEamilAgain",60,60);
					window.location.href="user/emailRegist?email="+name;
				}
			}else{
				vld_error.html(r.msg);
				vld_error.css("display","block");
			}
		}
	});
}

function btnZc(){
	v = getCookieValue("zc_secondsremained");//获取
    if(v>0){
        settime($("#zc_btn_sms_code"));//开始倒计时
    }
}

function settime(obj) { 
	countdown=getCookieValue("zc_secondsremained");
    if (countdown == 0) { 
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送(" + countdown + "s)"); 
        countdown--; 
        editCookie("zc_secondsremained",countdown,countdown+1);
    } 
    setTimeout(function(){settime(obj)},1000);
}


function CheckIntensity(pwd){ 
	  var m=0; 
	  var Modes=0; 
	  for(i=0; i<pwd.length; i++){ 
	    var charType=0; 
	    var t=pwd.charCodeAt(i); 
	    if(t>=48 && t <=57){charType=1;} 
	    else if(t>=65 && t <=90){charType=2;} 
	    else if(t>=97 && t <=122){charType=4;} 
	    else{charType=4;} 
	    Modes |= charType; 
	  } 
	  for(i=0;i<4;i++){ 
		  if(Modes & 1){m++;} 
	      Modes>>>=1; 
	  } 
	  if(pwd.length<=4){m=1;} 
	  if(pwd.length<=0){m=0;} 
	  switch(m){ 
	    case 1 : 
	      $("#zc_pwd_safe").html("密码安全程度：<span style='color:red'>弱</span>");
		  $("#zc_pwd_safe").css("display","block");
	    break; 
	    case 2 : 
    	  $("#zc_pwd_safe").html("密码安全程度：<span style='color:red'>中</span>");
		  $("#zc_pwd_safe").css("display","block");
	    break; 
	    case 3 : 
	      $("#zc_pwd_safe").html("密码安全程度：<span style='color:red'>强</span>");
		  $("#zc_pwd_safe").css("display","block");
	    break; 
	    default : 
	    break; 
	  }
} 
