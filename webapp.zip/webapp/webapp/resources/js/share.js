var share = {};
share.weibo=function(url,title){
	 var shareUrl = 'http://service.weibo.com/share/share.php?';
		shareUrl += '&url='+url;
		shareUrl +=	'&title='+title;
		shareUrl +=	'&content=gb2312';
		window.open(shareUrl);
}
share.qq=function(url,title){
	var shareUrl = 'http://connect.qq.com/widget/shareqq/index.html';
		shareUrl +='?url='+url;
		shareUrl +='&title='+title;
		window.open(shareUrl);
}
share.weixin=function(url){
    $('#weixin').qrcode({
		render: "canvas", //也可以替换为table
	    width: 150,
	    height: 150,
	    text: url
    });

}