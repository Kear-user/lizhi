//对象属性为null时转换成""字符串
function getWithoutNull(object){
	for(var i in object){
	      if(object[i]==null||object[i]=="null"){
	    	  object[i]="";
	      }
    }
	return object;
}

//对象属性为NaN时转换成""字符串
function getWithoutNaN(object){
	if(isNaN(object)){
		object ="";
	}
	return object;
}

//去两端空格
function getByTrim(obj){
	if(obj!=null) {
		return obj.replace(/(^\s*)|(\s*$)/g,"");
	}
	return null;
}

//去所有空格
function toWithoutTrim(obj){
	if(obj!=null) {
		return obj.replace(/\s+/g,"");
	}
	return null;
}

//判断数据是否为空,是空返回false
function isNull(str){
	if( str==null || str==undefined || getByTrim(str)==""){
		return false;
	}else{
		return true;
	}	
}

//添加cookie
function addCookie(name,value,expiresHours){ 
    var cookieString=name+"="+escape(value); 
    //判断是否设置过期时间,0代表关闭浏览器时失效
    if(expiresHours>0){ 
        var date=new Date(); 
        date.setTime(date.getTime()+expiresHours*1000); 
        cookieString=cookieString+";expires=" + date.toUTCString(); 
    } 
        document.cookie=cookieString; 
} 
//修改
function editCookie(name,value,expiresHours){ 
    var cookieString=name+"="+escape(value); 
    if(expiresHours>0){ 
      var date=new Date(); 
      date.setTime(date.getTime()+expiresHours*1000); //单位是毫秒
      cookieString=cookieString+";expires=" + date.toGMTString(); 
    } 
      document.cookie=cookieString; 
} 
//获取
function getCookieValue(name){ 
      var strCookie=document.cookie; 
      var arrCookie=strCookie.split(";"); 
      for(var i=0;i<arrCookie.length;i++){ 
        var arr=arrCookie[i].split("="); 
        if($.trim(arr[0])==name){
          return unescape(arr[1]);
          break;
        }
      }  
      return "";
}

//是否含有中文（也包含日文和韩文）
function isChineseChar(str){   
   var reg = /[\u4E00-\u9FA5\uF900-\uFA2D]$/;
   return reg.test(str);
}
//是否含有全角符号
function isFullwidthChar(str){
   var reg = /[\uFF00-\uFFEF]$/;
   return reg.test(str);
} 
//同理，是否含有全角符号的函数
function isCardNo(card) {
	var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
	return reg.test(card);
} 
//是否是邮箱地址
function isEmail(str) {
	var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;  
	return reg.test(str);
} 
//是否是银行卡
function isBankCard(str) {
	var reg = /^([1-9]{1})(\d{14}|\d{15}|\d{18})$/;  
	return reg.test(str);
} 
//是否是电汇
function isWireTransfer(str) {
	var reg = /^[0-9a-zA-Z_\-\/]{8,20}$/; 
	return reg.test(str);
} 
//是否是电话
function isPhone(str) {
	var reg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
	return reg.test(str);
} 
//是否是两位小数
function isFloatTwo(str) {
	var reg = /^([+-]?)\d+(\.([0-9]){0,2})?$/; 
	return reg.test(str);
} 

function changeNfcSetp(obj){
	$(".nfx-step-row").each(function(){
		$(this).attr("class","nfx-step-row");
	});
	$(obj).attr("class","nfx-step-row active");
}

//去尾法
Number.prototype.toFloor = function (num,weishu) {
	return Math.floor(num * Math.pow(10, weishu)) / Math.pow(10, weishu);
};

//进一法
Number.prototype.toCeil = function (num,weishu) {
	return Math.ceil(num * Math.pow(10, weishu)) / Math.pow(10, weishu);
};

//四舍五入法
Number.prototype.toRound = function (num,weishu) {
	return Math.round(num * Math.pow(10, weishu)) / Math.pow(10, weishu);
};


