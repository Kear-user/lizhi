var isName = "no";
$(function(){
	$("#radio1").change(function(){
		getPays();
	});
	$("#radio2").change(function(){
		getPays();
	});
	$("#wantAmount").change(function(){
		getRate();
	});
	$("#input12").change(function(){
		getRate();
	});
	
	$("#btn_withdrawl_sub").click(function(){
		if(!isFloatTwo($("#wantAmount").val())){
			alert("请输入不多于两位小数的金额！");
			$("#wantAmount").focus();
			$("#btn_withdrawl_sub").attr("disabled",true);
			return false;
		}
		var type = $('input[name="currencyType"]:checked').val();
		if(type=="1"&&isName!="yes"){
			$("#dlg-set-name").modal('show');
			return false;
		}
		$("#form_withdrawl").cryptPOST({
			success : function(r) {
				if(r.code==0){
					alert(r.msg);
					window.location.reload();
				}else if(r.code==500){
					alert(r.msg);
				}
			}
		});
	});
	
});
var feeRateTemp;
//验证账号是否被限制
function isLimit(){
	$("#wantAmount").val("");
	$("#wantAmount").next().val("");
	feeRateTemp = getFeeRate();
	$.ajax({
		  url:"customer/islimit",
		  type: "POST",
		  contentType: "application/json",
		  dataType: 'json', 
		  async:false,//取消异步请求
		  success: function(r) {
			  if(r.code==500){
				  alert(r.msg);
				  return false;
			  }else{
				  getPays();
			  }
		  }
	 });
}
//先判断有没有实名认证
function haveName(isName1){
	isName = isName1;
	isLimit();
}

var moneyType=null;

//获取账号
function getPays(){
	var radio3 = $("#radio3").val(); 
	var type = $('input[name="currencyType"]:checked').val();
	
	if(!isNull(type) && radio3!='3'){
		$("#dlg-without-withdrawl-account").modal("show");
		return false;
	}
	$("#input12 option[class='option12']").remove();
	if(type=="0"||type=="1"){
		$.ajax(
		  {
		  url:"ewithdrawal/getpays/"+type,
		  type: "POST",
		  contentType: "application/json",
		  dataType: 'json', 
		  async:false,//取消异步请求
		  success: function(result) {
			  var r = eval(result);
			  var selectAcct = $("#input12");
			  if(r.length>0){
				  var html = "";
				  for(var i in r){
					  html+="<option class='option12' value='"+r[i].accountId+"'>"+r[i].accountAcctView+"("+r[i].typeName+")</option>";
				  }
				  selectAcct.append(html);
			  }else{
				  var html="<option class='option12' value=''>选择提现账号</option>";
				  selectAcct.append(html);
				  var typeName="";
				  var typeName2="";
				  if(type=="1"){
					  typeName ="元";
					  typeName2 ="人名币";
					  $("#rateShow").css("display","");
					  $("#wantAmount").attr("placeholder","最多可提现   "+$("#amountRmb").text()+" 元");
				  }else if(type=="0"){
					  typeName="美元";
					  typeName2="美元";
					  $("#rateShow").css("display","none");
					  $("#wantAmount").attr("placeholder","最多可提现   "+$("#allbalance").text()+" 美元");
				  }
				  $("#actual").html("0.00"+typeName);
				  $("#shouxufei").html("0.00"+typeName);
				  $("#wantAmount").next().next().text(typeName);
				  $("#btn_withdrawl_sub").attr("disabled",true);
				  if(confirm("还没有添加"+typeName2+"提现账号，请前往添加！")){
					  window.location.href=$("#basePath").val()+"customer/setting/receipt";
				  }
				  return false;
			  }
			  $("#dlg-tixian").modal('show');//弹框弹出
		  }
	  });
	}else if(type==""){
		$("#rateShow").css("display","none");
		var html="<option class='option12' value=''>选择提现账号</option>";
		$("#input12 option[class='option12']").remove();
		$("#input12").append(html);
		 $("#btn_withdrawl_sub").attr("disabled",true);
		$("#actual").text("0.00元");
		$("#shouxufei").text("0.00元");
	}else if(radio3=="3"){
		var html="<option class='option12' value=''>选择提现账号</option>";
		$("#input12 option[class='option12']").remove();
		$("#actual").html("0.00元");
		$("#shouxufei").html("0.00元");
		$("input:radio[value='1']").attr('checked','true');
		getPays();
		$(".option:first").before(html);
	}
	getRate();
}
//获取汇率
function getFeeRate(){
	$.ajax({
		type: "POST",
		contentType: "application/json",
		async:false,//取消异步请求
	    url: "ewithdrawal/getrate",
	    success:function(result){
	    	var r = eval("("+result+")");
	    	if(r.code == 0){
	    		feeRate = r.msg;
	    	}else if(r.code == 500){
	    		alert(r.msg);
	    	}
	    }
    });
	return feeRate;
}
//计算手续费和提现金额
function getRate(){
	var type = $('input:radio:checked').val();//收款方式(RMB或则美元)
	var acctNum = $("#input12").val();
	var wantAmount = parseFloat("0.00");
	if(isNull($("#wantAmount").val())){
		wantAmount = parseFloat($("#wantAmount").val());
		$("#wantAmount").next().val(wantAmount);
	}
	if(!isFloatTwo($("#wantAmount").val()) && isNull($("#wantAmount").val())){
		alert("请输入不多于两位小数的金额！");
		$("#wantAmount").focus();
		$("#btn_withdrawl_sub").attr("disabled",true);
		return false;
	}
	
	if(!isNull(type)||!isNull(acctNum)){
		return false;
	}
	var feeSet = getColRate(acctNum,type,0);//获取手续费
	var fee ="";
	var shouxufei=0.00;
	var feeRate = 0;
	if(type=="1"&&type!=""){//人民币的手续费计算
		$("#wantAmount").next().next().text("元");
		if(feeSet[0].exchangeRateType!=null && feeSet[0].exchangeRateType !=""){
			if(feeSet[0].rmbExchangeRate!=null && feeSet[0].rmbExchangeRate !="" && feeSet[0].exchangeRateType =='0'){
				feeRate = (feeRateTemp * parseFloat(feeSet[0].rmbExchangeRate)*0.01).toFixed(2);//汇率
			}else if(feeSet[0].rmbExchange!=null && feeSet[0].rmbExchange !="" && feeSet[0].exchangeRateType =='1'){
				feeRate = (feeRateTemp - parseFloat(feeSet[0].rmbExchange)).toFixed(2);//汇率
			}
		}
		
		wantAmount = getWithoutNaN((parseFloat($("#wantAmount").val())/feeRate).toFixed(2));
		//这里要把值放页面上
		
		feeSet = getColRate(acctNum,type,$("#wantAmount").val());//获取手续费
		if(feeSet[0].feeWay=="0"){//按比例收取
			fee = feeSet[0].feePercent;
			shouxufei = (wantAmount*(parseFloat(fee)/100)*feeRate).toFixed(2);
		}else if(feeSet[0].feeWay=="1"){//单笔收取
			fee = feeSet[0].fee;
			shouxufei = parseFloat(fee).toFixed(2);
		}
		
		var actual = $("#wantAmount").next().val();//实际金额展示
    	if(actual==null||actual==""||isNaN(actual)){
    		actual = 0.00.toFixed(2);
    	}
    	actual = actual-shouxufei;
    	if(actual<0||isNaN(actual))actual=0.00;
    	if(isNaN(shouxufei))shouxufei=0.00;
    	$("#feeRate").text(feeRate);
    	$("#amountRmb").text((parseFloat($("#allbalance").text())*feeRate).toFixed(2));
    	$("#wantAmount").attr("placeholder","最多可提现   "+$("#amountRmb").text()+" 元");
    	$("#actual").html(actual.toFixed(2)+"元");
    	$("#rateShow").css("display","");
    	if(!isNull($("#wantAmount").val())||$("#wantAmount").val()==0){
    		$("#shouxufei").html("0.00元");
    	}else{
    		$("#shouxufei").html(shouxufei+"元");
    	}
    	if(actual.toFixed(2)==0.00 || wantAmount > parseFloat($("#allbalance").text())){//实际提现金额为0使不可提现
			$("#btn_withdrawl_sub").attr("disabled",true);
    	}else{
    		$("#btn_withdrawl_sub").attr("disabled",false);
    	}
	}else if(type=="0"&&type!=""){//美元计算手续费
		feeSet = getColRate(acctNum,type,wantAmount);//获取手续费
		$("#wantAmount").next().next().text("美元");
		$("#wantAmount").attr("placeholder","最多可提现   "+$("#allbalance").text()+" 美元");
		$("#rateShow").css("display","none");
		if(feeSet[0].feeWay=="0"){//比例
			fee = feeSet[0].feePercent;
			shouxufei = (wantAmount*(parseFloat(fee)/100)).toFixed(2);
		}else if(feeSet[0].feeWay=="1"){//单笔收取
			fee = feeSet[0].fee;
			shouxufei = parseFloat(fee).toFixed(2);
		}
		var actual = wantAmount - shouxufei;
		if(actual<0||isNaN(actual))actual=0;
		if(isNaN(shouxufei))shouxufei=0;
		$("#actual").html(actual.toFixed(2)+"美元");
		if(!isNull($("#wantAmount").val())||$("#wantAmount").val()==0){
			$("#shouxufei").html("0.00美元");
		}else{
			$("#shouxufei").html(shouxufei+"美元");
		}
		if(actual.toFixed(2)==0.00 || wantAmount > parseFloat($("#allbalance").text())){//实际提现金额为0使不可提现
			$("#btn_withdrawl_sub").attr("disabled",true);
    	}else{
    		$("#btn_withdrawl_sub").attr("disabled",false);
    	}
		
	}
	if(type=="0"){
		if(wantAmount > parseFloat($("#allbalance").text())){
			$("#wantAmount").focus();
			$("#btn_withdrawl_sub").attr("disabled",true);
			$("#actual").text("0.00美元");
			$("#shouxufei").text("0.00美元");
			$("#rateShow").css("display","none");
			alert("账户余额不足，请重新输入！");
			return false;
		}
		if(wantAmount>5000){
			$("#wantAmount").focus();
			$("#btn_withdrawl_sub").attr("disabled",true);
			$("#actual").text("0.00元");
			$("#shouxufei").text("0.00元");
			$("#rateShow").css("display","");
			alert("单笔提现不得超过5000美元！")
			return false;
		}
	}else if(type=="1"){
		if($("#wantAmount").next().val() > parseFloat($("#amountRmb").text())){
			$("#wantAmount").focus();
			$("#btn_withdrawl_sub").attr("disabled",true);
			$("#actual").text("0.00元");
			$("#shouxufei").text("0.00元");
			$("#rateShow").css("display","");
			alert("账户余额不足，请重新输入！");
			return false;
		}
		if(wantAmount>5000){
			$("#wantAmount").focus();
			$("#btn_withdrawl_sub").attr("disabled",true);
			$("#actual").text("0.00元");
			$("#shouxufei").text("0.00元");
			$("#rateShow").css("display","");
			alert("单笔提现不得超过5000美元！")
			return false;
		}
	}
	
	$("#feeRate").val(feeRate);
	$("#amountFee").val(shouxufei);
}

//获取手续费计算方式
function getColRate(col,mtype,wantAmount){
	if((col!=null&&col!="")&&(mtype!=null&&mtype!="")){
		var fee;
		var eWithdrawalColWay={};
		eWithdrawalColWay.acctNum = col;
		eWithdrawalColWay.currency = mtype;
		eWithdrawalColWay.wantAmount = wantAmount;
		$.ajax({
			type: "POST",
			contentType: "application/json",
			data: JSON.stringify(eWithdrawalColWay),
			async:false,//取消异步请求
		    url: "ewithdrawal/getcolrate",
		    success:function(r){
		    	fee = eval(r);
		    }
	    });
		return fee;
	}
}