$(function(){
	searchFlow();
});
var offset=0;
var limit = 10;
var currentPage = 1;
function loadData(num,total){
	var myPageCount = total;//分页的总页数
    var myPageSize = limit;//分页的展示条数
    var countindex = Math.ceil(myPageCount/myPageSize);
    loadpage(countindex,myPageCount,num);
}

function loadpage(countindex,myPageCount,num) {
    $.jqPaginator('#pagination', {
        totalPages: countindex,
        visiblePages: 5,
        currentPage: 1,
        first: '<li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',
        onPageChange: function (num, type) {
            if (type == "change") {
            	currentPage  = num;
            	offset = limit * (num-1);
            	searchFlow();
            	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
            	$(window).scrollTop(0);
            }
        }
    });
	$("#pagination").jqPaginator('option', { 
		totalPages: countindex,
		totalCounts:myPageCount,
	});
	$("#pageInfo").html('<li><span>'+myPageCount+'条记录 '+num+'/'+countindex+'页</span></li>');
}

function searchFlow(){
	var wSearchParms = {};
	wSearchParms.limit = limit;
	wSearchParms.offset = offset;
	$.ajax({
		type: "POST",
	    url: "customer/loadsysmsg",
        dataType:"json",
        contentType:"application/json", 
	    async:false,//取消异步请求
	    data: JSON.stringify(wSearchParms),
	    success:function(result){
	    	var r = eval(result);
	    	var msgCounts = r.msgCounts;
	    	var html = "";
	    	var isNew = "";
	    	if(r.messages==null||r.messages.length == 0){
	    		html+="<span style='font-size: 16px;position: absolute;left: 45%;top:20px;'>还没有记录</span>";
	    		$("#pageInfo").html('');
	    		$("#msgLoad").css("height","486px");
	    		$.jqPaginator('#pagination', {
    				totalPages:1,
    				first:'',
    		        prev: '',
    		        next: '',
    		        last: '',
    		        page: '',
	    		});
	    	}else{
	    		$(".btn-del").css("display","");
		    	for(var i in r.messages){
		    		var message = getWithoutNull(r.messages[i]);
		    		if(message.status=='0'){
		    			isNew = "<span id='isNew"+message.messageId+"' class='text_red'>NEWS</span>";
		    		}else{
		    			isNew = "<span id='isNew"+message.messageId+"'></span>";
		    		}
		    		html+= "<div class='msg-item'>"+
				               "<div class='msg-hd'>"+
				                    "<input class='msg-check' value='"+message.messageId+"' type='checkbox' />"+
				                    "<span onclick='changeRead("+message.messageId+")' class='titl'>  "+message.title+isNew+"</span>"+
				                    "<div class='time'>  "+message.createDate+"</div>"+
				                "</div>"+
				                "<div class='msg-text'>  "+
				                	message.content +
				                "</div>"+
				            "</div>";
		    	}
	    	}
	    	$("#msgLoad").html(html);
	    	//消息中心 , 点击消息标题显示内容
	    	$(".msg-hd .titl").click(function(){
	    		$self=$(this);
	    		$(".msg-text").hide();
	    		$self.parentsUntil(".msg-item").siblings(".msg-text").show();
	    	});
	    	$("#select-all-msg").click(function(){
	    		$self=$(this);
	    		$(".msg-hd :checkbox").prop("checked",$self.prop("checked"));
	    	});
	    	loadData(currentPage,msgCounts);
	    }
	});
}

function deleteSome(){
	var  obj = $(".msg-check");
    check_val = [];
    for(k in obj){
        if(obj[k].checked)
            check_val.push(obj[k].value);
    }
    if(check_val.length>0){
		$("#dlg-delete-sysmsg").modal('show');
		$("#btn_delete_sysmsg").click(function(){
			deleteSomeAction(check_val);
		});
    }
}

function deleteSomeAction(check_val){
	    $.ajax({
			type: "POST",
		    url: "customer/deleteMsgs",
	        dataType:"json",
	        contentType:"application/json", 
		    async:false,//取消异步请求
		    data: JSON.stringify(check_val),
		    success:function(result){
		    	var r = eval(result);
				if(r.code==0){
					$("#dlg-delete-sysmsg").modal('hide');
					window.location.reload();
				}else{
					$("#dlg-delete-sysmsg").modal('hide');
					alert("删除失败！请稍后再试！");
				}
		    }
	    });
}
var msgUnReadNumValue = parseInt($("#msgUnReadNumValue").val());
function changeRead(msgId){
	if($("#isNew"+msgId).text()=="NEWS"){
		$.get("customer/changeRead/"+msgId,function(result){
			var r = eval('('+result+')');
			if(r.code==0){
				$("#isNew"+msgId).text("");
				msgUnReadNumValue = msgUnReadNumValue-1;
				if(msgUnReadNumValue>0 && msgUnReadNumValue<100){
					$(".msgUnReadNum").html(msgUnReadNumValue);
				}else if(msgUnReadNumValue>99){
					$(".msgUnReadNum").html("99+");
				}else{
					$(".msgUnReadNum").html("0");
					$("#msgUnReadNumLeft").css("display","none");
				}
			}
		});
	}
}