p = {}
p.wordLen = 6
p.init = function(){
    $phone = $('#userName')
    $word = $('#passWord')
    $sendResult = $('#sendResult')
    $entry  = $('#entry')
    $myform = $('#form_login_pwd')
    $entry.click(p.entryClickHandler)
    $('.outwrap').css("visibility","visible")
}
p.checkPhone = function($this){
    if($this.hasClass(misc.vars.disable)) return false
    if(!$phone.val()){
        $phone.focus()
        return false
    }
    if(!misc.validatePhone($phone.val())){
        p.textShowThenHide($sendResult,'请输入正确的手机号码！')
        return false
    }
    return true
}
p.entryClickHandler = function(){
    var $this=$(this)
    if(p.checkPhone($this)){
        if(!$word.val()){
            $word.focus()
            return false
        }
        if($word.val().length < p.wordLen){
            p.textShowThenHide($sendResult,'密码长度为6-12位字符')
            return false
        }
        $this.addClass(misc.vars.disable).text('正在登录...')
       
        $myform.cryptPOST({
    		success : function(r) {
    			if(r.code===0){
				    $this.text('登录成功！')
		            setTimeout(function(){
		                location.href=misc.vars.base+'index.html'
		            },500)
    			}else{
    				$this.text('验证码错误！')
    			}
    		}
        });
        
        
       /* setTimeout(function(){
            // succ
            $this.text('登录成功！')
            setTimeout(function(){
                location.href=misc.vars.base+'index.html'
            },500)

            // error
            // $this.text('验证码错误！')
            // setTimeout(function(){
            //     $this.removeClass(misc.vars.disable).text('立即注册')
            //     $code.val('')
            // },800)
        },800)*/
    }
}
p.textShowThenHide = function($this,str,time){
    $this.html(str).show()
    time=time || 800
    setTimeout(function(){
        $this.empty().hide()
    }, time)
}