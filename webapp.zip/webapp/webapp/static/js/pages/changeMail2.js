p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$changeMailList = $('.changeMailList')
	changeMailList = [
		{
			mail:'88*******@qq.com'
		}
	]
}                 
p.render = function(){
		p.changeMailListRender(changeMailList)
}
p.changeMailListItem = function(data,index){
	return [
		'<div class="phone3_top">',
			'<div class="phone3_img"><img src="../static/images/pages/changeMail2/mail.png"></div>',
			'<div class="pone_text">您绑定邮箱为</div>',
			'<div class="phone_number">',data.mail,'</div>',
		'</div>'
	].join('')
}
p.changeMailListRender = function(datas){
	$changeMailList.append(datas.map(function(data,index){
		return p.changeMailListItem(data,index)
	}).join(''))
}
	