var did = null;
if(T.p("did")!=null && T.p("did") != ""){
	did = T.p("did");
	dname = T.p("dname");
	$("#dealerId").val(did);
	$(".set_rightText").text(dname);
}

$("#acctSub").click(function(){
	 var dealerId = toWithoutTrim($("#dealerId").val());
	 var acctNo = toWithoutTrim($("#acctNo").val());
	 var holdName = toWithoutTrim($("#holdName").val());
	 var holderEmail = toWithoutTrim($("#holderEmail").val());
	 if(dealerId==null||dealerId==""){
		 $("#error_msg").text("请选择一个交易商");
		 $("#error_msg").css("opacity","1");
		 $("#dealerId").focus();
		 return false;
	 }else{
		 $("#error_msg").attr("opacity","0");
	 } 
	 if(acctNo==null || acctNo ==""){
		 $("#error_msg").text("请输入交易账号");
		 $("#error_msg").css("opacity","1");
		 $("#acctNo").focus();
		 return false;
	 }else{
		 $("#error_msg").css("opacity","0");
	 } 
	 if(holdName==null || holdName ==""){
		 $("#error_msg").text("请输入开户人");
		 $("#error_msg").css("opacity","1");
		 $("#holdName").focus();
		 return false;
	 }else{
		 $("#error_msg").css("opacity","0");
	 } 
	 if(!isEmail(holderEmail)){
		 $("#error_msg").text("邮箱格式不合法");
		 $("#error_msg").css("opacity","1");
		 $("#holderEmail").focus();
		 return false;
	 }else{
		 $("#error_msg").css("opacity","0");
	 } 
	$("#form_add_acct").cryptPOST({
		success : function(r) {
			if(r.code === 0){
				alert(r.msg);
				window.location.href = "tradeUser.html";
			}else if(r.code === 500){
				alert(r.msg);
			}
		}
	})
});

