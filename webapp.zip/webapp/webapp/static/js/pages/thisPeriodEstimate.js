p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$EstimateList = $('.EstimateList')
	EstimateList = [
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
		{
			icon:'../static/images/pages/thisPeriodEstimate/XM.png',
			number:'38.88',
			order:'123456789',
			time:'2017-10-28'
		},
	]
}
p.render = function(){
		p.EstimateListRender(EstimateList)
}
p.EstimateListItem = function(data,index){
	return [
		'<div class="set_column">',
			'<img src="',data.icon,'"class="icon">',
			'<div class="set_columnContent">',
				'<div class="firstColumnText">',
					'<span class="leftText"> ',data.number,'</span>',
					'<span class="rightText"> 预估返现</span>',
				'</div>',
				'<div class="secondColumnText">',
					'<span class="leftText"> ',data.order,'</span>',
					'<span class="rightText"> ',data.time,'</span>',
				'</div>',
			'</div>',
		'</div>',
	].join('')
}
p.EstimateListRender = function(datas){
	$EstimateList.append(datas.map(function(data,index){
		return p.EstimateListItem(data,index)
	}).join(''))
}
	