p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$newPersonList = $('.newPersonList')
	newPersonList = [
		{
			href:'inviterFriend.html',
			img:'../static/images/pages/newPerson/banner.png',
			time:'活动日期:2017-7-20至2017-11-01'
		},
	]
}
p.render = function(){
		p.newPersonListRender(newPersonList)
}
p.newPersonListItem = function(data,index){
	return [
		'<div class="new_person">',
			'<div class="plate">',
				'<a href="',data.href,'"><img src="',data.img,'" class="banner"></a>',
				'<div class="actTime">',data.time,'</div>',
			'</div>',
		'</div>'
	].join('')
}
p.newPersonListRender = function(datas){
	$newPersonList.append(datas.map(function(data,index){
		return p.newPersonListItem(data,index)
	}).join(''))
}
