var p = {};

p.init = function(){
	p.info();
}

p.info = function(){
	var url = "../broker/alldealer";
	var tradeAccts = [];
	$.get(url,function(r){
		dealerList = r;
		var html ="";
		if(dealerList.length>0){
			for(var i in dealerList){
				var dealer = dealerList[i];
				html+='<div class="set_column">'+
						  '<div class="set_columnContent" onclick="selectThis('+ dealer.dealerId +',\''+dealer.name+'\')">'+
							 '<img src="../showFile?url='+dealer.logoUrl+'" class="icon">'+
							 '<div class="set_text">'+dealer.name+' '+dealer.chnName+'</div>'+
							 '<div class="border_bottom"></div>'+
						  '</div>'+
					 '</div>';
			}
		}
		$(".set").html(html);
	},"json")
}
function selectThis(did,dname){
	window.location.href = "addTrade.html?did="+did+"&dname="+dname;
}