p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$changePhoneList = $('.changePhoneList')
	changePhoneList = [
		{
			mobile:'159****9999'
		}
	]
}                 
p.render = function(){
		p.changePhoneListRender(changePhoneList)
}
p.changePhoneListItem = function(data,index){
	return [
			'<div class="phone3_top">',
				'<div class="phone3_img"><img src="../static/images/pages/changePhone3/Smartphone.png"></div>',
				'<div class="pone_text">您绑定的手机号为</div>',
				'<div class="phone_number">',data.mobile,'</div>',
			'</div>'
	].join('')
}
p.changePhoneListRender = function(datas){
	$changePhoneList.append(datas.map(function(data,index){
		return p.changePhoneListItem(data,index)
	}).join(''))
}
	