$(document).ready(function(){
	initData();
	cilckEvent();
});
var paytype = 1;
function initData(){
	$addReceivablesList = $('.addReceivablesList');
	var url = misc.vars.api.host+"/ecustomeraccountinfo/getamounts/"+paytype;
	$.get(url,function(data){
		if(data!=null && data !=""){
			creathtml(data);
		}
	});
}
function creathtml(datas){
	datas = eval("("+datas+")");
	var html ="";
	for(var i=0;i<datas.length;i++){
		html += '<div class="bankCard_plate">';
		html +=			'<div class="bankCard">';
		html +=				'<div class="cardTop">';
		if(datas[i].type == 0){//银行卡
		html +=				'<img src="../static/images/banks/'+datas[i].bankPng+'.png" />';
		}else if(datas[i].type == 1){//美元电汇
		html +=				'<img src="../static/images/banks/dianhui.png" />';	
		}
		html +=			    '<span class="bankName">'+datas[i].bankName+'</span>';
		html +=				'<span class="cardKind">'+datas[i].typeName+'</span>';
		html +=			'</div>';
		html +=			'<div class="cardBottom">';
		html +=				'<span class="name">'+datas[i].acctName+'</span>';
		html +=				'<span class="number">'+datas[i].accountAcctView+'</span>';
		html +=				'<span onclick="cancelBind('+datas[i].accountId+')" class="delete">删除</span>';
		html +=			'</div>';
		html +=		'</div>';
		html +=	'</div>';
	}
	$(".addReceivablesList").html(html);
}

function cancelBind(id){
	if(window.confirm('您确定要删除该收款账号吗？')){
		var url = misc.vars.api.host+"/ecustomeraccountinfo/cancelamount/"+id;
		$.get(url,function(data){
			if(data!=null && data !=""){
				data = eval("("+data+")");
				if(data.code == 0){
					window.location.reload();
				}else{
					alert("删除失败");
					window.location.reload();
				}
			}
		});
     }
}

function cilckEvent(){
	$(".rmb").click(function(){
		$(".dollar").css("border-bottom","0px");
		$(this).css("border-bottom","solid 0.15rem #fd4d4c");
		paytype = 1;
		initData();
		$("#addRec").attr("href","addReceivables2.html");
	});
	
	$(".dollar").click(function(){
		$(".rmb").css("border-bottom","0px");
		$(this).css("border-bottom","solid 0.15rem #fd4d4c");
		paytype = 2;
		initData();
		$("#addRec").attr("href","addReceivables3.html");
	});
}
