p = {}
p.timeLimit = p.TOTAL_TIME = 6
p.codeLen = 4
p.init = function(){
    $phone = $('#phone')
    $code = $('#code')
    $sendCode = $('#sendCode')
    $sendResult = $('#sendResult')
    $register  = $('#register')
    $myform = $('#myform')
    $sendCode.click(p.sendCodeHandler)
    $register.click(p.registerClickHandler)
    $('.outwrap').css("visibility","visible")
}
p.timerHandler = function(){
    $sendResult.text('验证码已发送，请注意查收')
    $sendCode.text('重新发送('+p.timeLimit+')')
    p.timeLimit--
    if(p.timeLimit < 0){
        clearInterval(p.timerKey)
        p.timeLimit = p.TOTAL_TIME
        $sendCode.text('发送验证码')
        $sendResult.text('')
        $sendCode.removeClass(misc.vars.disable)
    }
}
p.checkPhone = function($this){
    if($this.hasClass(misc.vars.disable)) return false
    if(!$phone.val()){
        $phone.focus()
        return false
    }
    if(!misc.validatePhone($phone.val())){
        p.textShowThenHide($sendResult,'请输入正确的手机号码！')
        return false
    }
    return true
}
p.sendCodeHandler = function(){
    var $this=$(this)
    if(p.checkPhone($this)){
        // request sms code 
        $this.addClass(misc.vars.disable).text('发送中...')
        p.timerKey = setInterval(p.timerHandler, 1000)

        // $myform.cryptPOST({
        //     type: 'get',
        //     url: '/user/smsCode',
        //     data: {
        //         mobile:$phone.val(),
        //         register:0
        //     },
        //     success : function(r) {
        //         if(r.code==0){
        //             alert(r.msg);
        //             window.location.reload();
        //         }else if(r.code==500){
        //             alert(r.msg);
        //         }
        //     }
        // });

        // misc.ajax.CDPOST(0, misc.api.get_verify_code, postData, function(){
        //     p.timerKey = setInterval(p.timerHandler, 1000);
        //     p.timerHandler();
        // }, function(err){
        //     that.removeClass(misc.vars.disable);
        //     misc.warmTip('ierror', err);
        // });
    }
}
p.registerClickHandler = function(){
    var $this=$(this)
    if(p.checkPhone($this)){
        if(!$code.val()){
            $code.focus()
            return false
        }
        if($code.val().length !== p.codeLen){
            p.textShowThenHide($sendResult,'请输入'+p.codeLen+'位数字验证码！')
            return
        }
        $this.addClass(misc.vars.disable).text('正在注册...')
       
        $myform.cryptPOST({
            type: 'get',
            url: '/user/smsCode',
            data: {
                mobile:$phone.val(),
                register:0
            },
            success : function($this) {
                debugger
                if($this.code==0){
                    debugger
                    $this.text('注册成功！')
                    setTimeout(function(){
                        location.href=misc.vars.base+'index.html'
                    },500)
                }else if($this.code==500){
                    debugger
                    $this.text('验证码错误！')
                    setTimeout(function(){
                        $this.removeClass(misc.vars.disable).text('立即注册')
                        $code.val('')
                    },800)
                }
            }
        });
            // succ
            // $this.text('注册成功！')
            // setTimeout(function(){
            //     location.href=misc.vars.base+'index.html'
            // },500)

            // error
            // $this.text('验证码错误！')
            // setTimeout(function(){
            //     $this.removeClass(misc.vars.disable).text('立即注册')
            //     $code.val('')
            //     },800)
    }
    // var postData = {
    //     mobile:telVal,
    //     code:codeVal,
    //     src: 1
    // };
    // misc.ajax.CDPOST(0, misc.api.check_mobile_login, postData, function(result){
    //     if(result.code === 0){
    //         misc.clearCookie('_tk');
    //         misc.clearCookie('uid');
    //         misc.setCookie('uid',result.data.id,30);
    //         var referrer=document.referrer;
    //         if(~referrer.indexOf('/info?id=')||~referrer.indexOf('/my')||~referrer.indexOf('activities')||~referrer.indexOf('/draw')){
    //             location.replace(referrer)
    //         }else{
    //             location.replace(misc.vars.base+'index')
    //         }
    //     }else{
    //         alertStr = result.msg;
    //         misc.warmTip('ierror', alertStr);
    //         p.btnText(that, '快速登录', 0);
    //         that.removeClass(misc.vars.disable);
    //     }
    // }, function(err){
    //     misc.warmTip('ierror', err);
    //     p.btnText(that, '快速登录', 0);
    //     that.removeClass(misc.vars.disable);
    // });
}
p.textShowThenHide = function($this,str,time){
    $this.html(str).show()
    time=time || 800
    setTimeout(function(){
        $this.empty().hide()
    }, time)
}