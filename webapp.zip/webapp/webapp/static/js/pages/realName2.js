var flage = 1;
$(document).ready(function(){
	clickEvent();
})
function clickEvent(){
	$(".bt_return").click(function(){
		yzIDcardNum();
	});
}
//防止有些人走捷径
function appendCode(form){
	console.log(getCookieValue("code"));
	if(flage == 1){
		var codeInput=$("<input type='text' name='code' style='display:none'/>");
		codeInput.attr("value",getCookieValue("code"));
		form.append(codeInput);
		flage = 0;
	}
}
function yzIDcardNum(){//实名认证
	var username = $("input[name='userName']");
	var idcard = $("input[name='idNumb']");
	if(!isNull(getByTrim(username.val()))){
		username.focus();
		username.css("border","1px solid #fd4d4c");
		return; 
	}else{
		username.css("border","0px");
	}
	if(!isNull(getByTrim(idcard.val()))){
		idcard.focus();
		idcard.css("border","1px solid #fd4d4c");
		return; 
	}else{
		idcard.css("border","0px");
	}
	var url = '/user/updateCardNumb';
	var form = $(".items_phone2");
	appendCode(form);//防止有些人走捷径
	form.attr("action",url);
	form.cryptPOST({
		success : function(r) {
			if(r!=null && r.code==0){
				flage = 1;
				alert("认证成功");
			}else{
				alert("认证失败");
			}
		}
	});
}