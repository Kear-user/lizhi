p={}
p.template={
	items_phone1:function(list){
		list=list||[]
		return [
			list.length?p.template.addresslist():p.template.addressnone(),
			p.template.address_bottom(),
		].join('')
	},
	addressnone:function () {
		return '<div class="noaddress"><img src="../static/images/pages/addresslist/noaddress.png" class="center_img"></div>'
	},
	addresslist:function () {
		return [
			'<div class="items_phone1">',
				'<div class="phone1_top">',
					'<img src="../static/images/pages/addresslist/bgBall.png">',
					'<span class="phone1_text">',data.name,'</span>',
					'<span class="phone1_number">',data.mobile,'</span>',
					'<div class="phone1_address">',data.address,'</div>',
				'</div>',
				'<div class="phone1_middle">',
					'<div class="middle_content">',
						'<span class="code">已设默认</span>',
						'<img src="../static/images/pages/addresslist/check.png">',
						'<span class="edit_code edit_firstlifecode">编辑</span>',
						'<span class="edit_code ">删除</span>',
					'</div>',
				'</div>',
				'<div class="phone1_top topheight">',
					'<img src="../static/images/pages/addresslist/bgBall.png">',
					'<span class="phone1_text">',data.name,'</span>',
					'<span class="phone1_number">',data.mobile,'</span>',
					'<div class="phone1_address">',data.address,'</div>',
				'</div>',
				'<div class="phone1_middle">',
					'<div class="middle_content">',
						'<span class="code code_second">设为默认</span>',
						'<span class="edit_code edit_secondlifecode">编辑</span>',
						'<span class="edit_code ">删除</span>',
					'</div>',	
				'</div>',
			'</div>'
		].join('')
	},
	address_bottom:function () {
		return '<div class="address_bottom"><a href="" class="add_address">+新建收货地址</a></div>'
	}
}
p.init=function(){
	p.render()
}
p.render=function(){
	$('.out-box').html(p.template.items_phone1(information))
}
(function(){
	$(document).ready(function() {
		p.init() 
	})
})

var information = [
	{
		name:'张三',
		mobile:'13699996666',
		address:'上海市浦东新区三林镇'
	},
	{
		name:'李四',
		mobile:'13688882222',
		address:'上海市浦东新区昌里'
	},
	{
		name:'张三',
		mobile:'13699996666',
		address:'上海市浦东新区三林镇'
	},
	{
		name:'李四',
		mobile:'13688882222',
		address:'上海市浦东新区昌里'
	}
]