$(document).ready(function(){
	initData();
	clickEvent();
});

function initData(){
	//先判断有没有设置交易密码
	var banksHtml = '';
	var url = misc.vars.api.host+"/ecustomeraccountinfo/initData";
	$.get(url,function(data){
		if(data!=null && data!=""){
			data = eval('('+data+')');
			banks = data.backs;
			for(var i in banks){
				banksHtml+='<option value="'+banks[i]+'">'+banks[i]+'</option>';
			}
			$("select[name='accountName']").append(banksHtml);
			$(".nameColumn .name").html(data.userName);
		}else{
			if(window.confirm('您还没有实名认证')){
				location.href = "addReceivables.html";
             }else{
            	 location.href = "addReceivables.html";
            }
		}
	});
}

function clickEvent(){
	$(".bt_return").click(function(){
		var accountAcct = $("input[name='accountAcct']");
		var openingBank = $("input[name='openingBank']");
		var bank  = $("select[name='accountName']");
		
		if(!isNull(accountAcct.val())){
			accountAcct.focus();
			accountAcct.css("border","1px solid #fd4d4c");
			return false;
		}else{
			accountAcct.css("border","0px");
		}
		if(!isBankCard(accountAcct.val())){
			accountAcct.focus();
			accountAcct.css("border","1px solid #fd4d4c");
			return false;
		}else{
			accountAcct.css("border","0px");
		}
		if(!isNull(bank.val())){
			bank.focus();
			bank.css("border","1px solid #fd4d4c");
			return false;
		}else{
			bank.css("border","0px");
		}
		if(!isNull(openingBank.val())){
			openingBank.focus();
			openingBank.css("border","1px solid #fd4d4c");
			return false;
		}else{
			openingBank.css("border","0px");
		}
		var url = '/ecustomeraccountinfo/save';
		var form = $("#form_account");
		form.attr("action",url);
		form.cryptPOST({
			success : function(r) {
				if(r.code==0){
					alert("添加成功");
				}else{
					alert(r.msg);
				}
			}
		});	
	});
}