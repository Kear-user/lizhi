p = {}
p.init = function () {
	p.vars ()
	p.render ()
	
}

//用户数据
p.info = function(){
	$.ajax({
		type: "GET",
		contentType: "application/json",
		async:false,//取消异步请求
	    url: "../customer/userInfo",
	    success:function(r){
	    	p.user = eval("("+r+")").eCustomer;
	    }
    });
	return p.user;
}
var user = p.info ();

p.vars = function(){
	$assetList = $('#assetList')
	assetList = [
		{
			dollar1: user.uncollected,
			dollar2: user.inviteAmount,
			dollar3: user.rebateAmount,
			dollar4: user.withDrawAmount,
			dollar5: user.integral
		}
	],
	$userPlate = $('.userPlate')
	userPlate = [
		{
			logo:'../static/images/pages/personal/XM.png',
			mobile: user.loginPhoneView
		}
	],
	$balancePlate = $('.balancePlate')
	balancePlate = [
		{
			dollar:user.available
		}
	]
}
p.render = function(){
		p.userPlateRender(userPlate)
		p.balancePlateRender(balancePlate)
		p.assetListRender(assetList)
}

p.assetListItem = function(data,index){
	return [
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/yugufanxian.png" class="yugufanxian">',
				'<div class="assetText"> ',
					'<span>本期预估返现</span>',
					'<span class="meiYuan">',data.dollar1,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="rightList">',
				'<img src="../static/images/pages/personal/tuijianfeileiji.png" class="tuijianfeileiji">',
				'<div class="assetText"> ',
					'<span>推荐费累计</span>',
					'<span class="meiYuan">',data.dollar2,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/jiaoyifeileiji.png" class="jiaoyifeileiji">',
				'<div class="assetText"> ',
					'<span>交易费累计返现</span>',
					'<span class="meiYuan">',data.dollar3,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="rightList">',
				'<img src="../static/images/pages/personal/chenggongtixian.png" class="chenggongtixian">',
				'<div class="assetText"> ',
					'<span>已成功提现</span>',
					'<span class="meiYuan">',data.dollar4,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/jifen.png" class="jifen">',
				'<div class="assetText"> ',
					'<span>积分</span>',
					'<span class="meiYuan">',data.dollar5,' 荔枝</span>',
				'</div>',
			'</li>',
		'</a>'
	].join('')
}
p.assetListRender = function(datas){
	$assetList.append(datas.map(function(data,index){
		return p.assetListItem(data,index)
	}).join(''))
}



p.userPlateItem = function(data,index){
	return [
		'<div class="userContent">',
			'<img src="',data.logo,'" class="userFigure" />',
			'<span class="uesrNumber">',data.mobile,'</span>',
			'<a href="signIn.html"><span class="btQianDao">签到</span></a>',
		'</div>'
	].join('')
}
p.userPlateRender = function(datas){
	$userPlate.append(datas.map(function(data,index){
		return p.userPlateItem(data,index)
	}).join(''))
}


p.balancePlateItem = function(data,index){
	return [
		'<div class="balanceContent">',
			'<div class="balance">账户余额</div>',
			'<span class="meiYuanNumber">',data.dollar,'</span>',
			'<span class="meiYuan">美元</span>',
			'<a href="withdrawalsRmb.html"><span class="btTiXian">提现</span></a>',
		'</div>'
	].join('')
}
p.balancePlateRender = function(datas){
	$balancePlate.append(datas.map(function(data,index){
		return p.balancePlateItem(data,index)
	}).join(''))
}
