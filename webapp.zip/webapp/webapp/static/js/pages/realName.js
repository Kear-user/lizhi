$(document).ready(function(){
	p.init()
});
p = {}
p.eCustomer = {}
p.init = function () {
 	misc.request('get','/user/settingCfc',{},function(res) {
		res=JSON.parse(res);
		p.eCustomer.loginPhoneView = res.eCustomer.loginPhoneView;
		p.vars ()
		p.render ()
	})
	clickEvent();
}
p.vars = function(){
	$realNameList = $('.realNameList')
	realNameList = [
		{
			mobile:p.eCustomer.loginPhoneView
		}
	]
}
p.render = function(){
	p.realNameListRender(realNameList)
}
p.realNameListItem = function(data,index){
	return [
		'<div class="phone1_top">',
				'<span class="phone1_text">当前绑定手机号</span>',
				'<span class="phone1_number">',data.mobile,'</span>',
				'<div class="phone1_cue">该号码不能正常使用？请联系客服</div>',
			'</div>'
	].join('')
}
p.realNameListRender = function(datas){
	$realNameList.append(datas.map(function(data,index){
		return p.realNameListItem(data,index)
	}).join(''))
}
var smscodeFlag = 1;
function clickEvent(){
	//获取验证码
	$("#smscode").click(function(){
		if(smscodeFlag == 0){
			return;	
		}
		smscodeFlag = 0;
		$.ajax({
		 	url: misc.vars.api.host+'/user/smrzCode',
		 	type: 'GET',
		 	dataType:"json",
		 	success:function(r){
				if(r.code==0){
					addCookie("cfc_validate_secondsremained",60,60);
					settimes($("#smscode"));
				}
		 	},
		 	error:function(err) {
		 		console.log("error");
		 	}
		});
	});
	
	$("#smssub").click(function(){
		var codeObj = $("input[name='code']");
		if(!isNull(getByTrim(codeObj.val()))){
			codeObj.focus();
			codeObj.css("border","1px solid #fd4d4c");
			return; 
		}else{
			codeObj.css("border","0px");
		}
		var url = '/user/yzCode';
		var form = $(".phone1_middle form");
		form.attr("action",url);
		form.cryptPOST({
    		success : function(r) {
    			if(r.code==0){
    				addCookie("cfc_validate_secondsremained",0,0);
    				addCookie("code",codeObj.val(),60*60*5);//用户输入验证码
    				window.location.href="realName2.html";
    			}else{
    				alert("验证码错误");
    			}
    		}
    	});
		
	});
}


function settimes(obj) { 
	countdown=getCookieValue("cfc_validate_secondsremained");
    if (countdown == 0) {
    	smscodeFlag = 1;//发送开关
        obj.css({
        	"margin-left":"-10px",
        	"padding-left":"0.5rem"
        });
    	obj.attr("disabled",false);    
    	obj.text("获取验证码"); 
        countdown = 60; 
        return;
    } else { 
    	obj.attr("disabled", true); 
    	obj.text("重新发送("+countdown+"s)"); 
        countdown--; 
        editCookie("cfc_validate_secondsremained",countdown,countdown+1);
        obj.css({
        	"margin-left":"-10px",
        	"padding-left":"0px"
        });
       
    } 
    setTimeout(function(){settimes(obj)},1000);
}