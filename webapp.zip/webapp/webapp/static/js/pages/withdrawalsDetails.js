p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$withdrawalsList = $('.withdrawalsList')
	withdrawalsList = [
		{
			time:'2017-10-10 10:10:10',
			dollar:'$678.10',
			kind:'人民币',
			procedures:'8.88',
			arrival:'6.66',
			receivables:'6222**********3325',
			reasonText:'如果审核原因文字很多如果审核原因文字很多，如果审核原因文字很多如果审核原因文字很多，如果审核原因文字很多如果审核原因文字很多，如果审核原因文字很多如果审核原因文字很多如果审核原因文字很多如果审核原因文字很多如果审核原因文字很多'
		}
	]
}
p.render = function(){
		p.withdrawalsListRender(withdrawalsList)
}
p.withdrawalsListItem = function(data,index){
	return [
		'<div class="withdrawals_details">',
			'<div class="detailsTop">',
				'<div class="detailsText">',data.time,'</div>',	
				'<div class="detailsState">这里是状态</div>',
				'<div class="detailsDollar">',data.dollar,'</div>', 
			'</div>', 
			'<div class="detailsPlate">',
				'<div class="showdetails">',
					'<div>收款币种:',		
						'<span class="rmb">',data.kind,'</span>',
					'</div>',
					'<div class="column">手续费:',
						'<span class="procedures">',data.procedures,'</span>元',
					'</div>',
					'<div class="column">实际到账:',
						'<span class="arrival">',data.arrival,'</span>元',
					'</div>',
					'<div class="column">收款账号:',		
						'<span class="receivables">',data.receivables,'</span>',
					'</div>',
					'<div class="column">备注</div>',		
				'</div>',
				'<div class="reasonPlate">',
					'<div class="reasonText">',data.reasonText,'</div>',
				'</div>',
			'</div>',
		'</div>'
	].join('')
}
p.withdrawalsListRender = function(datas){
	$withdrawalsList.append(datas.map(function(data,index){
		return p.withdrawalsListItem(data,index)
	}).join(''))
}
	