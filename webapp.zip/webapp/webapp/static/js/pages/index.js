p = {}
p.init = function () {
	p.vars()
	p.render()
}
p.vars = function () { // 声明所有变量
	$businessList = $('.businessList');
	businessList = new Array();
	$.ajax({
	 	url: 'http://localhost:8080/ieforex-app-ch/broker/home',
	 	type: 'GET',
	 	success:function(res) {
	 		res=JSON.parse(res);
	 		businessList = res;
	 		console.log(res);
	 		p.businessListRender(businessList.dealerAds);
	 	},
	 	error:function(err) {
	 		console.log("error");
	 	},
	 	complete:function(xhr) {
	 		console.log("complete");
	 	} 
	 });

	$bannerList = $('.bannerList')
	bannerList = new Array()
	$.ajax({
	 	url: 'http://localhost:8080/ieforex-app-ch/home',
	 	type: 'GET',
	 	success:function(res) {
	 		res=JSON.parse(res);
	 		bannerList = res;
	 		console.log(res);
	 		p.bannerListRender(bannerList.bannerAds)
	 		TouchSlide({ 
	 			slideCell:"#focus",
	 			titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
	 			mainCell:".bd ul", 
	 			effect:"left", 
	 			autoPlay:true,//自动播放
	 			autoPage:true, //自动分页
	 			switchLoad:"_src" //切换加载，真实图片路径为"_src" 
	 		});
	 	},
	 	error:function(err) {
	 		console.log("error");
	 	},
	 	complete:function(xhr) {
	 		console.log("complete");
	 	} 
	 });
	$noticeList = $('.noticeList')
	noticeList = [
  		{	
  			notice:'恭喜159****3451成功邀请1位好友，获得11.75$'
  		},
  		{	
  			notice:'恭喜133****5115成功邀请2位好友，获得22.75$'
  		},
  		{	
  			notice:'恭喜136****2113成功邀请3位好友，获得33.75$'
  		},
  		{	
  			notice:'恭喜189****6656成功邀请5位好友，获得55.75$'
  		}
	]
}
p.render = function () { // 声明所有页面渲染
	p.noticeListRender(noticeList)
	var myscroll=new Scroll("hotNewsUl",24)
}
p.businessListRender = function (datas) {
	$businessList.append(datas.map(function(data,index){
		return p.businessListItem(data,index)
	}).join(''))
}
p.businessListItem = function(data,index) {
	return [
		'<li class="list">',
			'<div class="business_name">',
				'<img src=../showFile?url="',data.picUrl,'">',
				'<span>',data.mainTitle,'</span>',
				'<a href="',data.linkUrl,'" class="see">查看+</a>',
			'</div>',
			'<div class="act_message">',data.subhead,'</div>',
			'<a href="',data.picUrl,'"><img src=../showFile?url="',data.linkUrl,'" class="act_icon"></a>',
			'<div class="act_time">',data.createDate,'+',data.endDate,'</div>',
		'</li>'
	].join('')
}
p.bannerListRender = function (datas) {
	$bannerList.append(datas.map(function(data,index){
		return p.bannerListItem(data,index)
	}).join(''))
}
p.bannerListItem = function(data,index) {
	return [
		'<li><a href="',data.linkUrl,'"><img _src=../showFile?url="',data.picUrl,'" src="#" /></a></li>'
	].join('')
}
p.noticeListRender = function (datas) {
	$noticeList.append(datas.map(function(data,index){
		return p.noticeListItem(data,index)
	}).join(''))
}
p.noticeListItem = function(data,index) {
	return [
	        '<li><a href="inviterFriend.html">',data.notice,'</a></li>',
	].join('')
}
//Notice Roll
function scollNew(element){
	 if(arguments.length>1){
	  for(var i=0,length=arguments.length,elements=[];i<length;i++){
	   elements.push(scollNew(arguments[i]));
	  }
	  return elements;
	 }
	 if(typeof element=="string"){
	  return document.getElementById(element);
	 }else{
	  return element;
	 }
	}
	var Class={
	 create:function(){
	  return function(){
	   this.initialize.apply(this,arguments);
	  }
	 }
	}
	Function.prototype.bind=function(object){
	 var method=this;
	 return function(){
	  method.apply(object,arguments);
	 }
	}
	var Scroll=Class.create();
	Scroll.prototype={
		initialize:function(element,height){
			this.element=scollNew(element);
			this.element.innerHTML+=this.element.innerHTML;
			this.height=height;
			this.maxHeight=this.element.scrollHeight/2;
			this.counter=0;
			this.scroll();
			this.timer="";
			this.element.onmouseover=this.stop.bind(this);
			this.element.onmouseout=function(){this.timer=setTimeout(this.scroll.bind(this),1000);}.bind(this);
		},
		scroll:function(){
		  	if(this.element.scrollTop<this.maxHeight){
			   this.element.scrollTop++;
			   this.counter++;
		  	}else{
			   this.element.scrollTop=0;
			   this.counter=0;
			}
			if(this.counter<this.height){
			   this.timer=setTimeout(this.scroll.bind(this),20);
			}else{
			   this.counter=0;
			   this.timer=setTimeout(this.scroll.bind(this),1000);
			}
		},
		stop:function(){
			clearTimeout(this.timer);
		}
	}