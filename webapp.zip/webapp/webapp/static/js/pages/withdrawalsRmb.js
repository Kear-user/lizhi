p = {}
p.shouxufei = 0.00.toFixed(2);
p.amount = 0.00.toFixed(2);
p.init = function () {
	p.vars ();
	p.render ();
	p.getAcctNum();
	$("#subWithdrawl").click(function(){
		var acctNum = $("#acctNum").val();
		var wantAmount = $("#wantAmount").val();
		if(acctNum == null || acctNum =="" || acctNum == undefined){
			$("#acctNum").focus();
			return ;
		}else if(wantAmount==null || wantAmount=="" || wantAmount == undefined){
			$("#wantAmount").focus();
			return ;
		}else if(wantAmount>parseFloat(user.available*p.feeRate).toFixed(2)){
			alert("可用余额不足！请重新输入")
			$("#wantAmount").focus();
			return;
		}
		
		$("#form_withdrawl").cryptPOST({
			success : function(r) {
				if(r.code==0){
					alert(r.msg);
					window.location.reload();
				}else if(r.code==500){
					alert(r.msg);
				}
			}
		});
	});
	$("#acctNum").blur(function(){
		p.reckonFee();
	});
	$("#wantAmount").blur(function(){
		p.reckonFee();
	});
}
//用户数据
p.info = function(){
	$.ajax({
		type: "GET",
		contentType: "application/json",
		async:false,//取消异步请求
	    url: "../customer/userInfo",
	    success:function(r){
	    	p.user = eval("("+r+")").eCustomer;
	    }
    });
	return p.user;
}
var user = p.info ();

//获取提款账号
p.getAcctNum = function(){
		$.ajax({
			  url: "../ewithdrawal/getpays/1",
			  type: "POST",
			  contentType: "application/json",
			  dataType: 'json',
			  async:false,//取消异步请求
			  success: function(result) {
				  var r = result;
				  var html = "";
				  if(r.length>0){
					  for(var i in r){
						  html+="<option class='option12' value='"+r[i].accountId+"'>"+r[i].accountAcctView+"("+r[i].typeName+")</option>";
					  }
				  }else{
					  html = "<option class='option12' value=''>选择提现账号</option>";
				  }
				  $("#acctNum").append(html);
			  }
		});
}
//获取手续费
p.getColRate = function(col,mtype,wantAmount){
	if((col!=null&&col!="")&&(mtype!=null&&mtype!="")){
		var fee;
		var eWithdrawalColWay={};
		eWithdrawalColWay.acctNum = col;
		eWithdrawalColWay.currency = mtype;
		eWithdrawalColWay.wantAmount = wantAmount;
		$.ajax({
			type: "POST",
			contentType: "application/json",
			data: JSON.stringify(eWithdrawalColWay),
			async:false,//取消异步请求
		    url: "../ewithdrawal/getcolrate",
		    success:function(r){
		    	fee = eval(r);
		    }
	    });
		return fee;
	}
}


//获取汇率
p.getFeeRate= function (){
	var feeSet = p.getColRate(3573,1,0);
	var url = "../ewithdrawal/getrate";
	$.ajax({
		type: "GET",
		contentType: "application/json",
		async:false,//取消异步请求
	    url: url,
	    success:function(result){
	    	var r = eval("("+result+")");
	    	if(r.code == 0){
	    		feeRateTemp = r.msg;
	    		if(feeSet[0].exchangeRateType!=null && feeSet[0].exchangeRateType !=""){
	    			if(feeSet[0].rmbExchangeRate!=null && feeSet[0].rmbExchangeRate !="" && feeSet[0].exchangeRateType =='0'){
	    				feeRate = (feeRateTemp * parseFloat(feeSet[0].rmbExchangeRate)*0.01).toFixed(2);//汇率
	    			}else if(feeSet[0].rmbExchange!=null && feeSet[0].rmbExchange !="" && feeSet[0].exchangeRateType =='1'){
	    				feeRate = (feeRateTemp - parseFloat(feeSet[0].rmbExchange)).toFixed(2);//汇率
	    			}
	    		}
	    	}else if(r.code == 500){
	    		alert(r.msg);
	    	}
	    }
    });
	
	return feeRate;
}
p.feeRate = p.getFeeRate();

p.reckonFee = function(){
	
	var acctNum = $("#acctNum").val();
	var wantAmount = $("#wantAmount").val();
	if(wantAmount==null || wantAmount=="" || wantAmount == undefined){
		return ;
	}
	if(acctNum == null || acctNum =="" || acctNum == undefined){
		return ;
	}
	var feeSet = p.getColRate(acctNum,1,wantAmount);
	if(feeSet[0].feeWay=="0"){//按比例收取
		fee = feeSet[0].feePercent;
		shouxufei = (wantAmount*(parseFloat(fee)/100)*p.feeRate).toFixed(2);
	}else if(feeSet[0].feeWay=="1"){//单笔收取
		fee = feeSet[0].fee;
		shouxufei = parseFloat(fee).toFixed(2);
	}
	p.shouxufei = shouxufei;
	if(shouxufei<=0 || isNaN(shouxufei))p.shouxufei = "0.00";
	p.amount = wantAmount - shouxufei;
	if(p.amount<=0 || isNaN(p.amount))p.amount = "0.00";
	if(p.amount<=0 || parseFloat(wantAmount) > parseFloat(user.available*p.feeRate)){
		$("#wantAmount").focus();
		$(".middle_content>.procedures").text('￥0.00');
		$(".middle_content>.dollar").text('￥0.00');
		return;
	}
	$(".middle_content>.procedures").text('￥'+ parseFloat(p.shouxufei).toFixed(2));
	$(".middle_content>.dollar").text('￥'+ parseFloat(p.amount).toFixed(2));
}

p.vars = function(){
	$withdrawalsTopList = $('.withdrawalsTopList')
	withdrawalsTopList = [
		{
			dollar:'$'+parseFloat(user.available).toFixed(2),
			rateNow:parseFloat(p.feeRate).toFixed(2),
			rmb:'￥'+ parseFloat(user.available*p.feeRate).toFixed(2)
		}
	],
	
	$withdrawalsBottomList = $('.withdrawalsBottomList')
	withdrawalsBottomList = [
		{
			cash:parseFloat(user.available*p.getFeeRate()).toFixed(2),
			procedures:'￥'+parseFloat(p.shouxufei).toFixed(2),
			dollar:'￥'+parseFloat(p.amount).toFixed(2)
		}
	]
}

p.render = function(){
		p.withdrawalsTopListRender(withdrawalsTopList)
		p.withdrawalsBottomListRender(withdrawalsBottomList)
}


p.withdrawalsTopListItem = function(data,index){
	return [
		'<div class="withdrawalsShow">',
			'<div class="Text">可提现金额</div>',
			'<div class="dollar">',data.dollar,'</div>',
			'<div class="rate">',
				'<span class="rateNow">(当前汇率</span>', 
				'<span>',data.rateNow,')</span>',
			'</div>',
			'<div class="rmb">',
				'<span class="rmbText">折合人民币</span>',
				'<span class="rmbColor">',data.rmb,'</span>',
			'</div>',
		'</div>'
	].join('')
}


p.withdrawalsTopListRender = function(datas){
	$withdrawalsTopList.append(datas.map(function(data,index){
		return p.withdrawalsTopListItem(data,index)
	}).join(''))
}


p.withdrawalsBottomListItem = function(data,index){
	return [
		'<div class="items_phone2">',
			'<div class="phone2_middle">',
				'<div class="middle_content">',
					'<span class="code">提现金额</span>',
					'<input type="hidden" name = "currencyType" value="1" >',
					'<input type="text" name="withdrawalAmount" id ="wantAmount" class="username" placeholder="最多可提现',data.cash,'元" />',
				'</div>',
			'</div>',
			'<div class="phone2_middle">',
				'<div class="middle_content">',
					'<span class="code">手 续 费</span>',
					'<span class="procedures">',data.procedures,'</span>',
				'</div>',
			'</div>',	
			'<div class="phone2_middle">',
				'<div class="middle_content">',
					'<span class="code">实际到帐( 元 )</span>',
					'<span class="dollar ">',data.dollar,'</span>',
				'</div>',	
			'</div>',			
		'</div>'
	].join('')
}


p.withdrawalsBottomListRender = function(datas){
	$withdrawalsBottomList.append(datas.map(function(data,index){
		return p.withdrawalsBottomListItem(data,index)
	}).join(''))
}

// function dollarTabClick(){
// 	$('.selectColumn .dollarTabClick').click(function(){
// 		$('.selectColumn .dollarTabClick').addClass('.selectColumn .dollarClick')
// 		$('.selectColumn .dollarTabClick').removeClass('.selectColumn .dollar')
// 		$('.selectColumn .rmbTabClick').removeClass('.selectColumn .rmbClick')
// 		$('.selectColumn .rmbTabClick').addClass('.selectColumn .rmb')
// 	})
// }
// function rmbTabClick(){
// 	$('.selectColumn .rmbTabClick').click(function(){
// 		$('.selectColumn .rmbTabClick').addClass('.selectColumn .rmbClick')
// 		$('.selectColumn .rmbTabClick').removeClass('.selectColumn .rmb')
// 		$('.selectColumn .dollarTabClick').removeClass('.selectColumn .dollarClick')
// 		$('.selectColumn .dollarTabClick').addClass('.selectColumn .dollar')
// 	})
// }

