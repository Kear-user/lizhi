var tid = T.p("tid");
p = {}
p.tradeTask = {};
p.init = function () {
	p.getReson ()
}

p.getReson = function(){
	var url = "../customer/trading/faild/"+tid;
	$.get(url,function(r){
		p.tradeTask = r
		p.vars ();
	},"json");
}

p.vars = function(){
	var tradeTask = p.tradeTask;
	if(tradeTask.checkStatus=="0" || tradeTask.checkStatus=="1")tradeTask.checkStatus = "审核中"
	if(tradeTask.checkStatus=="2")tradeTask.checkStatus = "审核驳回"
	$tradeUserList = $('.tradeUserList')
	tradeUserList = [
		{
			name:tradeTask.dealerEnName+'  '+tradeTask.dealerChnName,
			order:tradeTask.acctNo,
			time:tradeTask.acctCreateDate,
			discribe:tradeTask.reasonDetail,
			status:tradeTask.checkStatus
		},
	]
	p.render ()
}
p.render = function(){
		p.tradeUserListRender(tradeUserList)
}
p.tradeUserListItem = function(data,index){
	return [
		'<div class="set">',
			'<div class="set_column">',
				'<div class="set_columnContent">',
					'<div class="firstColumnText">',
						'<span class="leftText">',data.name,'</span>',
						'<span class="rightText">',data.status,'</span>',
					'</div>',
					'<div class="secondColumnText">',
						'<span class="leftText">',data.order,' </span>',
	  				'</div>',
				'</div>',	
			'</div>',
			'<div class="trade_user">',
				'<div class="binding">申请绑定时间',		
					'<span class="bindingTime">',data.time,'</span>',
					'<div class="remark">备注</div>',		
				'</div>',
				'<div class="reasonPlate">',
					'<div class="reasonText">',data.discribe,'</div>',
				'</div>',
			'</div>',
		'</div>'
	].join('')
}
p.tradeUserListRender = function(datas){
	$tradeUserList.append(datas.map(function(data,index){
		return p.tradeUserListItem(data,index)
	}).join(''))
}
	