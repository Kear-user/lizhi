p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$changePhoneList = $('.changePhoneList')
	changePhoneList = [
		{
			mobile:'159****9999'
		}
	]
}               
p.render = function(){
		p.changePhoneListRender(changePhoneList)
}
p.changePhoneListItem = function(data,index){
	return [
		'<div class="phone1_top ">',	
				'<span class="phone1_text">当前绑定手机号</span>',	
				'<span class="phone1_number">',data.mobile,'</span>',	
				'<div class="phone1_cue">该号码不能正常使用？请联系客服</div>',	
			'</div>'
	].join('')
}
p.changePhoneListRender = function(datas){
	$changePhoneList.append(datas.map(function(data,index){
		return p.changePhoneListItem(data,index)
	}).join(''))
}
	