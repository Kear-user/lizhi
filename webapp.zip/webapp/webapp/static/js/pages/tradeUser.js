var p = {};

p.init = function(){
	p.infoView();
}

p.info = function(){
	var url = "../customer/trading/acctno";
	var tradeAccts = [];
	$.get(url,function(r){
		var html = "";
		var $tradeUserList = $(".tradeUserList");
		tradeAccts = r;
		if(tradeAccts.length > 0){
			for(var i in tradeAccts){
				var html2 = '';
				var tradeAcct = tradeAccts[i];
				if(tradeAcct.checkStatus=="0" || tradeAcct.checkStatus=="1"){
					html2 = '<div class="set_column">'+
								'<img src="../showFile?url='+ tradeAcct.dealerLogoUrl +'" class="icon"/>'+
								'<div class="set_columnContent">'+
									'<div class="firstColumnText">'+
										'<span class="leftText">'+tradeAcct.dealerEnName+'  '+tradeAcct.dealerChnName+'</span>'+
										'<span class="rightText">审核中</span>'+
									'</div>'+
									'<div class="secondColumnText">'+
										'<span class="leftText">'+ tradeAcct.acctNo +' </span>'+
										'<a href="tradeUser2.html?tid='+tradeAcct.tradeAcctTaskId+'"><span class="rightText">查看</span></a>'+
									'</div>'+
								'</div>'+
							'</div>';
			    }else if(tradeAcct.checkStatus=="2"){
					html2 = '<div class="set_column">'+
								'<img src="../showFile?url='+ tradeAcct.dealerLogoUrl +'" class="icon"/>'+
								'<div class="set_columnContent">'+
									'<div class="firstColumnText">'+
										'<span class="leftText">'+tradeAcct.dealerEnName+'  '+tradeAcct.dealerChnName+'</span>'+
										'<span class="rightText">审核驳回</span>'+
									'</div>'+
									'<div class="secondColumnText">'+
										'<span class="leftText">'+ tradeAcct.acctNo +' </span>'+
										'<a href="tradeUser2.html?tid='+tradeAcct.tradeAcctTaskId+'"><span class="rightText">查看原因</span></a>'+
									'</div>'+
								'</div>'+
							'</div>';
				}else if(tradeAcct.checkStatus=="3"){
					html2 = '<div class="set_column">'+
								'<img src="../showFile?url='+ tradeAcct.dealerLogoUrl +'" class="icon" />'+
								'<div class="set_columnContent">'+
									'<div class="firstColumnText">'+
										'<span class="leftText">'+ tradeAcct.dealerEnName+'  '+tradeAcct.dealerChnName+'</span>'+
										'<span class="rightText">绑定成功 </span>'+
									'</div>'+
									'<div class="secondColumnText">'+
										'<span class="leftText"> '+ tradeAcct.acctNo +'</span>'+
										'<a href="javascript:;" onclick="unBindAcctNo('+ tradeAcct.tradeAcctId +')"><span class="rightText jiebang">解绑 </span></a>'+
									'</div>'+
								'</div>'+	
							'</div>';
				}
				html+=html2;
			}
			$tradeUserList.html(html);
		}
		
		
	},"json")
	
	return tradeAccts;
}

p.infoView = function(){
	p.info();
}
//解绑
function unBindAcctNo(taskId){
	if(confirm("确定要解绑该交易账号？")){
		$.get("../customer/trading/unbind/"+taskId,function(r){
			if(r.code===0){
				alert("解绑成功！");
				window.location.reload();
			}else if(r.code===500){
				alert("解绑失败，请稍后再试！");
			}
		},"json");
	}
	
}
	