﻿var curWwwPath=window.document.location.href;
var pathName=window.document.location.pathname;
var pos=curWwwPath.indexOf(pathName);
var baseUrl=curWwwPath.substring(0,pos)+'/home/';
$(function(){
    var scale = 1 / devicePixelRatio;
    function setHtmFontSize(){
        var deviceWidth = document.documentElement.clientWidth >1300 ?1300 : document.documentElement.clientWidth;
        deviceWidth = document.documentElement.clientWidth;
        document.documentElement.style.fontSize = (deviceWidth /7.5) + 'px';
    }
    $(window).resize(function(){
        setHtmFontSize();
    });
    setHtmFontSize();
}); 

// function mAjax(url,param,method){
	// alert('--url:'+url+"----param"+param);
    // $.ajax({
        // type:"POST",
        // dataType:"json",
        // url:baseUrl+url,
        // data:param,
        // success:method,
        // error:function(error){
            // console.log(JSON.stringify(error));
        // }
    // });
// }


//javascript 验证手机号码的正确性 
function isMobile(value){ 
   var pattern=/^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
        
    if(!pattern.test(value)){ 
        return false; 
    } 
    return true; 
} 
//javascript 验证电子邮箱的正确性 
function isEmail(value){ 
   var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	if (!reg.test(value) ) {		
		return false;
	}
	return true;
}

function isMyEmpty(verifyValue){
    if(verifyValue==null||verifyValue=='undefined'||verifyValue=='null'||verifyValue.length==0){
		return true;
	}
	return false;
}

//检查邮箱或手机号是否正确
function checkIsEmailOrPhone(value){
	if(value.length<1){
		tknoty('请输入正确的手机号或邮箱');
		return false;
	}else if(value.indexOf('@')>0){
		if(!isEmail(value)){
			tknoty('邮箱输入不正确');
			return false;
		}
		return true;
	}else{
		if(!isMobile(value)){
			tknoty('手机输入不正确');
			return false;
		}
		return true;
	}
}

//手机
function checkIsPhone(value){
	if(value.length<1){
		tknoty('请输入正确的手机号!');
		return false;
	}else{
		if(!isMobile(value)){
			tknoty('手机输入不正确');
			return false;
		}
		return true;
	}
}
//检查正确手机号
function checkPhoneNmber(id){
	//获取输入的手机号
	var loginPhone=$('#'+id).val();
	if(!checkInput(id,'请输入手机号！')){
		return false;
	}
	if(!isMobile(loginPhone)){
		tknoty('请输入正确手机号！');
		return false;
	}
	return true;
}
//消息提醒
function tknoty(msg){
    //$().toastmessage('showNoticeToast', msg);
    //messages=msg;
	$('#error>div').html(msg);
	$('#error').css('display', 'block');
	setTimeout("document.getElementById('error').style.display='none'", 3000);
}
//检查输入框
function checkInput(id,msg){
	var value=$('#'+id).val();
	if(value.length < 1){
		$('#'+id).focus();
		tknoty(msg);
		return false;
	}
	return true;
}


function isUserName(value){
	//var reg= /^(?![0-9a-z]+$)(?![a-zA-Z]+$)[0-9a-zA-Z\u4e00-\u9fa5]{3,16}$/;   //只能由数字和字母组成(排除特殊符号):
	//验证用户名是否为数字
	var s = /^\d+$/;
	//验证用户名是否包含特殊符号
	var re =/[`~!@#$%^&*_+<>{}\/'[\]]/im;
	//var reg=/^(?[0-9])(!\w)([0-9a-zA-Z\u4e00-\u9fa5])$/;

	if(value.length < 1){
		tknoty('用户名不能为空！');
		return 1;
	}

	if(s.test(value)){
		tknoty('用户名不能为纯数字');
		return 1;
	}
	if(re.test(value)){
		tknoty('用户名不能包含特殊字符');
		return 2;
	}

	if(value.length<3 || value.length>16){
		tknoty('用户名长度为3-16个字符');
		return 3;
	}
	if(value.indexOf(" ")!=-1){
		tknoty('用户名不能包含空格');
		return 4;
	}

	return 0;
}
//检查密码的重要性
function isPswd(value){ 
    //var reg=/^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{8,20}$/; 
	//验证密码是否为数字
	var number = /^\d+$/.test(value);
	var zimu= /^[A-Za-z]+$/.test(value);
	var teShu = /^[^\w\s]+$/.test(value);
	if(value.length<8 || value.length>20){
		tknoty('请输入8-20位密码！');
		return false;
	}else if(number){
		tknoty('密码为字母，数字或特殊字符的组合！');
		return false;
	}else if(value.indexOf(" ")!= -1){
		tknoty('密码不能包含有空格！');
		return false;
	}else if(zimu){
		tknoty('密码为字母，数字或特殊字符的组合！');
		return false;
	}else if(teShu){
		tknoty('密码为字母，数字或特殊字符的组合！');
		return false;
	}
      
    return true; 
}

function isPswdForReset(value){ 
    //var reg=/^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{8,20}$/; 
	//验证密码是否为数字
	var number = /^\d+$/.test(value);
	var zimu= /^[A-Za-z]+$/.test(value);
	var teShu = /^[^\w\s]+$/.test(value);
	if(value.length<8 || value.length>20){
		tknoty('请输入8-20位新密码！');
		return false;
	}else if(number){
		tknoty('新密码为字母，数字或特殊字符的组合！');
		return false;
	}else if(value.indexOf(" ")!= -1){
		tknoty('新密码不能包含有空格！');
		return false;
	}else if(zimu){
		tknoty('新密码为字母，数字或特殊字符的组合！');
		return false;
	}else if(teShu){
		tknoty('新密码为字母，数字或特殊字符的组合！');
		return false;
	}
      
    return true; 
}
function isCardNo(card) {
	// 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
	var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
	if(card.length < 1){
		tknoty('省份证号码不能为空！');
		return  false;
	}else if(reg.test(card) === false) {
		tknoty("身份证输入不合法");
		return  false;
	}
		return true
}

//获取当期日期
function getNowData() {
    var d = new Date();
    var year = d.getFullYear();
    var month = d.getMonth() + 1; // 记得当前月是要+1的
    if (month < 10) {
        month = '0' + month;
    }
    var dt = d.getDate();
    if (dt < 10) {
        dt = '0' + dt;
    }
    return today = year + "-" + month + "-" + dt;
}
function dateLongToString(longDate){
    var dDate = new Date(longDate);
	var year = dDate.getFullYear();
	var month = dDate.getMonth() + 1;
	
	if (month < 10) {
		month = '0' + month;
	}
	var date=dDate.getDate();
	if (date < 10) {
		date = '0' + date;
	}
	return year+"-"+month+"-"+date;
}
function getAllTime(){
	var date=new Date();
	var year=date.getFullYear();
	var month=date.getMonth()+1;
	var dt=date.getDate();
	var hour=date.getHours();
	var minute=date.getMinutes();
	var second=date.getSeconds();
	if (month < 10) {
		month = '0' + month;
	}
	if (dt < 10) {
		dt = '0' + dt;
	}
	if (hour < 10) {
		hour = '0' + hour;
	}
	if (minute < 10) {
		minute = '0' + minute;
	}
	if (second < 10) {
		second = '0' + second;
	}
	console.log(year,month,dt,hour,minute,second);
}
//解析参数
function getRequest(url) {
	if(isMyEmpty(url)){
		return null;
	}
	var theRequest = new Object();
	if (url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i ++) {
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest;
}



//判断字符长度
function getLength(value){
	var obj=value.replace(/(.)(?=[^$])/g,"$1,").split(",");
	var len = 0;
	for(var i=0;i<obj.length;i++){
		if(/^[\u4e00-\u9fa5]+$/.test(obj[i])){
			len +=2;
		}else{
			len +=1;
		}
	}
	return len;
}
function limitCharacterLength(title){
	//在common.js总的转换字符串长度，返回值是len
	var length = getLength(title);
	if(/^[\u4e00-\u9fa5]*$/.test(title)){//中文
		if(length>44){
			title = title.substr(0, 22) + "...";
		}else{
			title=title;
		}
	}else{
		if(length>44){
			title = title.substr(0,23) + "...";
		}else{
			title=title;
		}
	}
	return title;
}
function limitCharacterLength2(title){
	//在common.js总的转换字符串长度，返回值是len
	var length = getLength(title);
	if(/^[\u4e00-\u9fa5]*$/.test(title)){//中文
		if(length>58){
			title = title.substr(0, 29) + "...";
		}else{
			title=title;
		}
	}else{
		if(length>58){
			title = title.substr(0,58) + "...";
		}else{
			title=title;
		}
	}
	return title;
}

//loading条加载
function showLoding(){
	var html='<div id="bgHidden" style="width: 100%;height: 100%;position: fixed;z-index: 1000 ;top: 0;left:0">'
			+'<div id="loding" style="position: fixed;width: 2rem;height: 2rem;border-radius:5%;background-color: #525252;top:40%;left:40%;font-size: 0.3rem;color:#fff;z-index: 10000;">'
			+'<div style="margin: 0 auto;text-align: center;height: 1.2rem;line-height: 1.2rem;" >'
			+'<img src="weChatImg/loading.gif" alt="" style="border:0; margin-top:0.1rem"/></div>'
			+' <p style="text-align: center;color: #f2f2f2">加载中...</p>'
			+'</div>'
			+'</div>'
		;
	$('body').append(html)
}
function hideLoding(){
	$('#bgHidden').remove();

}

//小的加载图
function smallLoding(id){
	$('#'+id).hide();
	$('#loading').show();
}

function smallLoadingFinish(id,loadid){
	$('#'+id).show();
	$('#'+loadid).hide();
}


function smallLodings(id){
	$('#'+id).hide();
	$('#loadings').show();
}






