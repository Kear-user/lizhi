$(function () {
    bindShareClick();
    initView();
})
function bindShareClick(){
    var inviterText=$('#showDetailMessage').css('width');
    $('.invitermaskOver').css('width',inviterText);
    $('#shareInviter').click(function () {
        $('#fxInviter').show();
    })
    $('#fxInviter .modalGray').click(function () {
        $('#fxInviter').hide();
    })
    $('#faceInviter').click(function () {
        $('#mdmInviter').show();
    })
    $('#mdmInviter #quxiao').click(function () {
        $('#mdmInviter').hide();
    })
}

function initView(){
    var liHtmlOne = '';
    var lihtmlTwo='';
    for(var i=0;i<30;i++){
        var jf_name = ['137****5105','131****7688','tr***e@163.com','182****1989','op***f','156****8463','132****2223','188****2636','ic***3','be***3@163.com','188****6710','bo***k','d***b@hotmail.com','151****1156','76***6@qq.com','jx***g@sohu.com','186****3521','11****9@qq.com','186****6401','159****3220','8c***8@163.com','ki***x','150****4828','139****1785','151****7485','177****9069','18***9@163.com','153****8561','ya***n@126.com','156****8463'];
        var jf_num  = ['31','26','23','22','21','20','20','20','19','18','18','18','17','17','17','16','16','15','12','12','11','10','10','9','9','9','8','7','7','7'];
        var jf_lizhi = ['1302','1029','966','924','882','840','840','798','756','756','756','714','714','672','672','630','504','504','462','420','420','378','378','336','294','294','294','252','252','252'];
        var tjf_name = ['131****7688','137****5105','tr***e@163.com','188****2636','ic***3','182****1989','op***f','151****1156','be***3@163.com','156****8463','bo***k','76***6@qq.com','d***b@hotmail.com','185****5559','188****6710','jx***g@sohu.com','159****3220','186****3521','11****9@qq.com','186****6401','ki***x','8c***8@163.com','150****4828','139****1785','ya***n@126.com','151****7485','177****9069','18***9@163.com','153****8561','139****1785'];
        var tjf_lizhi = ['52.67','45.53','30.6','28.75','26.38','22.92','22.64','19.83','18.76','18.09','15.52','15.35','14.81','14.67','14.67','13.48','12.14','9.82','9.74','9.5','9.46','9.21','8.45','7.37','6.77','5.92','5.46','5.12','4.49','4.03'];
        liHtmlOne +='<li class="noticeElem">'+
        '<span>'+jf_name[i]+'</span>' +
        '<span>已推荐'+ jf_num[i] +'人</span>' +
        '<span>'+jf_lizhi[i] +'荔枝</span>' +
        '</li>';
        lihtmlTwo+='<li class="noticeElem">'+
        '<span>'+tjf_name[i]+'</span>' +
        '<span></span>' +
        '<span>'+tjf_lizhi[i]+'荔枝</span>' +
        '</li>';
    }
    $('.stareLunbo').html(liHtmlOne);
    $('.stare').html(lihtmlTwo);
}

/*三模块切换*/
function tab(pid){
    var tabs=["tab1","tab2"];
    for(var i=0;i<2;i++){
        if(tabs[i]==pid){
            /*  document.getElementById(tabs[i]).style.display="block";*/
            $('#'+tabs[i]).show();
            $('.'+tabs[i]+'mm').addClass('clickRed');
        }else{
            /*  document.getElementById(tabs[i]).style.display="none";*/
            $('#'+tabs[i]).hide()
            $('.'+tabs[i]+'mm').removeClass('clickRed');
        }
    }
}

p = {}
p.init = function () {
    p.vars()
    p.render()
}
p.vars = function () {
    $noticeList = $('.noticeList')
    noticeList = [
        {   
            notice:'恭喜159****3451成功邀请1位好友，获得11.75$'
        },
        {   
            notice:'恭喜133****5115成功邀请2位好友，获得22.75$'
        },
        {   
            notice:'恭喜136****2113成功邀请3位好友，获得33.75$'
        },
        {   
            notice:'恭喜189****6656成功邀请5位好友，获得55.75$'
        }
    ]
}
p.render = function () { // 声明所有页面渲染
    p.noticeListRender(noticeList)
    var myscroll=new Scroll("hotNewsUl",24)
}
p.noticeListRender = function (datas) {
    $noticeList.append(datas.map(function(data,index){
        return p.noticeListItem(data,index)
    }).join(''))
}
p.noticeListItem = function(data,index) {
    return [
            '<li><a href="inviterFriend.html">',data.notice,'</a></li>',
    ].join('')
}
//Notice Roll
function scollNew(element){
     if(arguments.length>1){
      for(var i=0,length=arguments.length,elements=[];i<length;i++){
       elements.push(scollNew(arguments[i]));
      }
      return elements;
     }
     if(typeof element=="string"){
      return document.getElementById(element);
     }else{
      return element;
     }
    }
    var Class={
     create:function(){
      return function(){
       this.initialize.apply(this,arguments);
      }
     }
    }
    Function.prototype.bind=function(object){
     var method=this;
     return function(){
      method.apply(object,arguments);
     }
    }
    var Scroll=Class.create();
    Scroll.prototype={
        initialize:function(element,height){
            this.element=scollNew(element);
            this.element.innerHTML+=this.element.innerHTML;
            this.height=height;
            this.maxHeight=this.element.scrollHeight/2;
            this.counter=0;
            this.scroll();
            this.timer="";
            this.element.onmouseover=this.stop.bind(this);
            this.element.onmouseout=function(){this.timer=setTimeout(this.scroll.bind(this),1000);}.bind(this);
        },
        scroll:function(){
            if(this.element.scrollTop<this.maxHeight){
               this.element.scrollTop++;
               this.counter++;
            }else{
               this.element.scrollTop=0;
               this.counter=0;
            }
            if(this.counter<this.height){
               this.timer=setTimeout(this.scroll.bind(this),20);
            }else{
               this.counter=0;
               this.timer=setTimeout(this.scroll.bind(this),1000);
            }
        },
        stop:function(){
            clearTimeout(this.timer);
        }
    }