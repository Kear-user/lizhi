/**
 * Created by wwwieforexcom on 2017/11/14.
 */
var list=[1,2,3,4,5,6,7]
$(function(){
    lunboHtml()
    clickJF();
})
function clickJF(){
    /*中奖及兑换记录*/
    $('#click_zjjl').click(function(){
        $('#dlg-win-change').fadeIn(100);
    });
    $('#close_zjjl').click(function(){
        $('#dlg-win-change').fadeOut(100);
    });
}
function lunboHtml(){
    var html='';
    for(var i=0;i<list.length;i++){
        html+= '<li><span>180*****@183.com</span><b>111'+i+'颗荔枝</b></li>'
    }
    $('#lunbo').html(html)
}
