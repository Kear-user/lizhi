/**
 * Created by QZJ on 2016/12/19.
 */
function SkyTimer(time,cycle,textID){
    //生命时长(秒)
    this.initTime = parseInt(time);
    this.time = parseInt(time);
    //周期(毫秒，多少秒执行一次)
    if(!cycle || cycle < 1000){
        cycle = 1000;
    }
    this.cycle = parseInt(cycle/1000)*1000;
    //剩余时间
    this.freeTime = 0;
    //计时器
    this.timer;
    //计时器状态 0.未进行，1.进行中
    this.timerStatus = 0;
    this.textArea = document.getElementById(textID);
}

SkyTimer.prototype = {
    //设置生命时长
    setTime : function(time){
        this.time = time;
    },
    callTimer : function(self){
        this.timer = setTimeout(function(){
            self.execute();
        },this.cycle);
    },
    //执行函数
    execute : function(){
        //倒计时尚未结束
        if(this.time != 1){
            this.time--;
            console.log("lalala:"+this.time);
            $(this.textArea).html(this.time+'(秒)后重发');
            //当前状态为进行中
            if(this.timerStatus == 1){
                this.callTimer(this);
            }
        } else{
            this.reset();
             $(this.textArea).html('重新获取');
        }

    },
    //获取计时器状态
    getStatus : function(){
        return this.timerStatus;
    },
    //启动
    start : function(){
        if(this.timerStatus != 1){
            this.timerStatus = 1;
            this.callTimer(this);
        }
    },
    //停止
    stop : function(){
        this.timerStatus = 2;
    },
    //复位
    reset: function(){
        clearTimeout(this.timer);
        this.time = this.initTime;
        this.timerStatus = 0;
    }
}