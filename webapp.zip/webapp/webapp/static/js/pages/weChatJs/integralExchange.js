/**
 * Created by wwwieforexcom on 2017/11/14.
 */
$(function () {
    integerClick()
})
function integerClick(){
    $('#close_detailJf').click(function(){
        $('#dlg-jf-change').slideUp(100);
    });
    $('.jf_lists li').click(function(){
        $('#dlg-jf-change').slideDown(120);
    })
}