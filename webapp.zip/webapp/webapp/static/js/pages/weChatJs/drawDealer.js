$(function () {
    bindClick()
})

function bindClick(){
    /*积分攻略*/
    $('#click_jfgl').click(function(){
        $('#dlg-pointer-strategy').fadeIn(100);
    });
    $('#close_jfgl').click(function(){
        $('#dlg-pointer-strategy').fadeOut(100);
    });
/*活动说明*/
    $('#click_hdsm').click(function(){
        $('#dlg-active-explain').fadeIn(100);
    });
    $('#close_hdsm').click(function(){
        $('#dlg-active-explain').fadeOut(100);
    });
/*抽奖按钮关闭*/
    $('#close_win').click(function(){
        $('#dlg-draw-success').fadeOut(100);
    });

    lottery.init('lottery');
    $('.draw-btn').click(function() {
        if (click) {//click控制一次抽奖过程中不能重复点击抽奖按钮，后面的点击不响应
            return false;
        }else{
            lottery.speed=100;
            lottery.prizeInfor = '12345';
            roll();   //转圈过程不响应click事件，会将click置为false
            click=true; //一次抽奖完成后，设置click为true，可继续抽奖
            console.log(lottery.prize)
            /* $.ajax({
             async : true,
             type : "get",
             url : "indiana/lottery",
             success : function(data){
             data = eval("("+data+")");
             if(data.status == 0){
             lottery.prizeInfor = data.prize;
             roll();   //转圈过程不响应click事件，会将click置为false
             click=true; //一次抽奖完成后，设置click为true，可继续抽奖
             }else if(data.status == 1){
             $("#showFail .hd .titl").html("积分抽奖");
             $("#showFail .bd p").html("活动未开启");
             $('#dlg-wining-no').modal('show');
             }else if(data.status == 2){
             $("#showFail .hd .titl").html("积分抽奖");
             $("#showFail .bd p").html("您的积分不足，去“积分攻略”查看更多积分获取方式");
             $('#dlg-wining-no').modal('show');
             }else if(data.status==-2){
             /!*未登录*!/
             $("#dlg-login").modal('show');
             }else if(data.status == -1){
             $("#showFail .hd .titl").html("积分抽奖");
             $("#showFail .bd p").html("奖品去哪里啦？");
             $('#dlg-wining-no').modal('show');
             }
             }
             });*/
            return false;
        }
    });
}
var click = false;
var lottery = {
    index: -1, //当前转动到哪个位置，起点位置
    count: 0, //总共有多少个位置
    timer: 0, //setTimeout的ID，用clearTimeout清除
    speed: 20, //初始转动速度
    times: 0, //转动次数
    cycle: 50, //转动基本次数：即至少需要转动多少次再进入抽奖环节
    prize: -1, //中奖位置
    prizeInfor:{},
    init: function(id) {
        if($('#' + id).find('.lottery-unit').length > 0) {
            $lottery = $('#' + id);
            $units = $lottery.find('.lottery-unit');
            this.obj = $lottery;
            this.count = $units.length;
            $lottery.find('.lottery-unit.lottery-unit-' + this.index).addClass('active');
        };
    },
    roll: function() {
        var index = this.index;
        var count = this.count;
        var lottery = this.obj;
        $(lottery).find('.lottery-unit.lottery-unit-' + index).removeClass('active');
        index += 1;
        if(index > count - 1) {
            index = 0;
        };
        $(lottery).find('.lottery-unit.lottery-unit-' + index).addClass('active');
        this.index = index;
        return false;
    },
    stop: function(index) {
        this.prize = index;
        return false;
    }
};

function roll() {
    lottery.times += 1;
    lottery.roll(); //转动过程调用的是lottery的roll方法，这里是第一次调用初始化

    if(lottery.times > lottery.cycle + 10 && lottery.prize == lottery.index) {
        clearTimeout(lottery.timer);

        var infor = lottery.prizeInfor;
        lottery.times=0;
        click=false;
        //log("抽中了: "+lottery.index);
        //抽奖结束，1秒后显示结果
        setTimeout(function(){
            /*if(infor[1]==0 || infor[1] == 1){
             $("#showGood .hd .titl").html("恭喜");
             $("#showGood .bd p").eq(0).html("恭喜您获得"+infor[2]+"，我们会线下联系您");
             $('#dlg-wining-san').modal('show');
             }else if(infor[1] == 2 || infor[1]==3){
             $("#showGood .hd .titl").html("恭喜");
             $("#showGood .bd p").eq(0).html("恭喜您获得"+infor[2]);
             $('#dlg-wining-san').modal('show');
             }else if(infor[1] == 4){
             $("#showFail .hd .titl").html("谢谢参与");
             $("#showFail .bd p span").html("再接再厉，下次好运");
             $('#dlg-wining-no').modal('show');
             }
             //同步个人信息
             if(infor[5]>0){
             $(".cj_count").text("抽奖次数 "+infor[5]);
             }else{
             $(".cj_count").text("消耗荔枝"+infor[6]);
             }
             $("#curIntegral").text(infor[4]);*/
            $("#showTime").html("恭喜您获得"+infor+ lottery.prize+"，我们会线下联系您");
            $('#dlg-draw-success').fadeIn(200);
        },1000);

    } else {
        if(lottery.times < lottery.cycle) {
            lottery.speed -= 10;
        } else if(lottery.times == lottery.cycle) {
            var index = Math.random() * (lottery.count) | 0; //静态演示，随机产生一个奖品序号，实际需请求接口产生
            lottery.prize = index;
            /*   lottery.prize = lottery.prizeInfor[0]-1;*/
        } else {
            if(lottery.times > lottery.cycle + 10 && ((lottery.prize == 0 && lottery.index == 7) || lottery.prize == lottery.index + 1)) {
                lottery.speed += 110;
            } else {
                lottery.speed += 20;
            }
        }
        if(lottery.speed < 40) {
            lottery.speed = 40;
        };
        lottery.timer = setTimeout(roll, lottery.speed); //循环调用
    }
    return false;
}

