$(function(){
    bindClick();
    initData();
})
function initData(){
	var url = misc.vars.api.host+"/user/attendanceInfo";
	$.get(url,function(data){
		data = JSON.parse(data);
		if(data != null && data != ""){
 			//积分数据
 			$("#userIntegral").html(data.userIntegral+" 积分");
 			var attendanceInfo = data.attendanceInfo;
 		    qiandaoHtml(attendanceInfo);
		}
	});
}

/*签到说明*/
function bindClick(){
    $('#click_qdsm').click(function(){
        $('#dlg-sign-in').fadeIn(100);
    });
    $('#close_qdsm').click(function(){
        $('#dlg-sign-in').hide();
    })
}
function qiandaoHtml(data){
    var aa=analizeTime();
    var timeArr = new Array();
    timeArr.push(null,'周一:'+getNowFormatDate(aa.monday),'周二:'+getNowFormatDate(aa.tuesday),
        '周三:'+getNowFormatDate(aa.wednesday),'周四:'+getNowFormatDate(aa.thursday),
        '周五:'+getNowFormatDate(aa.friday),'周六:'+getNowFormatDate(aa.saturday),'周日:'+getNowFormatDate(aa.sunday)
    )
    var timeHtml=''
    //当今天为星期一的时候
    if(analizeTime().day==1) {
        //今天
        timeHtml+=todayShow(data,analizeTime().day,timeArr);
        for (var i = 2; i < timeArr.length; i++) {
        	//初始化过去几天页面数据
        	var infor = overShow(data,i);
            var newDate = timeArr[i].split(':');
            timeHtml+=' <li>'
            +' <div class="lf"><img src="../static/images/pages/weChatImg/sign_daiqiandao.png" alt=""/><span>'+newDate[0] +'&nbsp;&nbsp;'+newDate[1]  +' </span> </div>'
            +'<div class="rt"><span>待签到</span></div>' +
            '<i class="weidao"></i>'
            +'</li>'
        }
    }
    //当今天不是星期一的时候
    if(analizeTime().day!=1){
    	//初始化过去几天页面数据
        for(var i=1;i<analizeTime().day;i++){
        	var infor = overShow(data,i);
            var newDate=timeArr[i].split(':');
            var lineClass='';//第一个没有右侧线条
            if(i==1){
                lineClass='hidden'
            }else{
                lineClass='shows'
            }
            timeHtml+=' <li>'
            +' <div class="lf"><img src="../static/images/pages/weChatImg/'+infor.pngurl+'" alt=""/><span>'+newDate[0] +'&nbsp;&nbsp;'+newDate[1]  +' </span> </div>'
            +'<div class="rt"><span >'+infor.signStatus+'</span></div>' +
            '<i class="'+lineClass+'"></i>'
            +'</li>'
        }
        //今天
        timeHtml+=todayShow(data,analizeTime().day,timeArr);
        //以后
        for(var i=analizeTime().day+1;i<timeArr.length;i++){
            var newDate=timeArr[i].split(':');
            timeHtml+=' <li>'
            +' <div class="lf"><img src="../static/images/pages/weChatImg/sign_daiqiandao.png" alt=""/><span>'+newDate[0] +'&nbsp;&nbsp;'+newDate[1]  +' </span> </div>'
            +'<div class="rt"><span >待签到</span></div>' +
            '<i class="weidao"></i>'
            +'</li>'
        }
    }
    $('.detailTimes').html(timeHtml);
    $(".detailTimes").on('click','#qiandao',(function(){//签到（按钮）
            /* if(_handle&&!$('.able-qiandao').hasClass('checked')){*/
            qiandao(this);
            _handle=false;
            /*  }*/
        })
    )
}

//签到的接口调用
function qiandao(){
	var url = misc.vars.api.host+"/customer/attendance";
	 $.get(url,function(r){
		 r = JSON.parse(r);
 	     if(r.code == 0){
 	    	 
 	    	 
 	    	location.reload();
 	    	
 	    	
 	    	
 	     }else if(r.code == 500){
 	    	alert(r.msg);
 	     }
 	});
}
//获取从星期日到星期六这一周的时间
function  analizeTime(){
    var now = new Date();
    var nowTime = now.getTime() ;
    var day = now.getDay();
    var oneDayTime = 24*60*60*1000 ;
    //显示周一
    var MondayTime = nowTime - (day-1)*oneDayTime ;
    var TuesdayTime = nowTime - (day-2)*oneDayTime ;
    var WednesdayTime = nowTime - (day-3)*oneDayTime ;
    var ThrusdayTime = nowTime - (day-4)*oneDayTime ;
    var FirdayTime = nowTime - (day-5)*oneDayTime ;
    var SaturdayTime = nowTime - (day-6)*oneDayTime ;
    //显示周日TuesdaySunday Sun 星期日
    var sundayTime = new Date(MondayTime- oneDayTime);

    //初始化日期时间
    var monday = new Date(MondayTime);
    var tuesday = new Date(TuesdayTime);
    var wednesday = new Date(WednesdayTime);
    var thursday = new Date(ThrusdayTime);
    var friday = new Date(FirdayTime);
    var saturday = new Date(SaturdayTime);
    var sunday = new Date(sundayTime);
    return {
        'sunday':sunday,
        'monday':monday,
        'tuesday':tuesday,
        'wednesday':wednesday,
        'thursday':thursday,
        'friday':friday,
        'saturday':saturday,
        'day':day
    }
}
//将获取的日期转换成自己想要的格式
function getNowFormatDate(timestamp) {
    /* var year = new Date(timestamp).getFullYear();*/
    var month = new Date(timestamp).getMonth() + 1;
    var date = new Date(timestamp).getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (date >= 0 && date <= 9) {
        date = "0" + date;
    }
    var dateByTime =  month + "月" + date + "日";
    return dateByTime;
}

function todayShow(data,i,timeArr){//数据 今天 汉化
	//判断今天的签到情况
	var flage = todayFlag(data,i);
	if(flage){//已经签到
       var lineClass='';//第一个没有右侧线条
       if(i==1){
           lineClass='hidden'
       }else{
           lineClass='shows'
       }
       var timeHtml=' <li>'
            +' <div class="lf"><img src="../static/images/pages/weChatImg/sign_yiqiandao.png" alt=""/><span>'+timeArr[i].split(':')[0] +'&nbsp;&nbsp;'+timeArr[i].split(':')[1] +' </span> </div>'
            +'<div class="rt"><span >'+data.attendanceIntegral+'积分</span></div>' +
            '<i class="'+lineClass+'"></i>'
            +'</li>'
       return timeHtml;   
	}else{
	    var lineClass='';//第一个没有右侧线条
	    if(i==1){
	       lineClass='hidden'
	    }else{
	       lineClass='shows'
	    }
        var timeHtml=' <li>'
            +' <div class="lf"><img src="../static/images/pages/weChatImg/sign_onqiandao.png" alt=""/><span>'+timeArr[i].split(':')[0] +'&nbsp;&nbsp;'+timeArr[i].split(':')[1] +' </span> </div>'
            +'<div class="rt"><a onclick="qiandao()">签到</a></div>' +
            '<i class="'+lineClass+'"></i>'
            +'</li>'
		return timeHtml;
	}	
}

function todayFlag(data,i){//data:数据 i:今天
	if(i == 1 && data.monday == "1"){//周一
		return true;
	}else if(i == 2 && data.tuesday == "2"){//周二
		return true;
	}else if(i == 3 && data.wednesday == "3"){//周三
		return true;
	}else if(i == 4 && data.thursday == "4"){//周四
		return true;
	}else if(i == 5 && data.friday == "5"){//周五
		return true;
	}else if(i == 6 && data.saturday == "6"){//周六
		return true;
	}else if(i == 7 && data.sunday == "7"){//周日
		return true;
	}	
	return false;
}

function overShow(data,i){//data:数据 i:星期几
	var retObj = {};
	/**过去的几天*/
	var signStatus = "未签到";
	var pngurl = "sign_weiqiandao.png";
	if(i == 1 && data.monday == "1"){//周一
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral +"积分";
	}else if(i == 2 && data.tuesday == "2"){//周二
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral + "积分";
	}else if(i == 3 && data.wednesday == "3"){//周三
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral + "积分";
	}else if(i == 4 && data.thursday == "4"){//周四
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral + "积分";
	}else if(i == 5 && data.friday == "5"){//周五
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral + "积分";
	}else if(i == 6 && data.saturday == "6"){//周六
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral + "积分";
	}else if(i == 7 && data.sunday == "7"){//周日
		pngurl = "sign_yiqiandao.png";
		signStatus = data.attendanceIntegral +"积分";
	}
	retObj.pngurl = pngurl;
	retObj.signStatus = signStatus;
	return retObj;
}