var p = {};
p.timerKey;
p.timeLimit = p.TOTAL_TIME = 60;
p.codeLen = 6;
p.init = function(){
    $('.outwrap').css("visibility","visible");
    $('.code-block a').click(this.sendCodeHandler);
    $('.login-btn').click(this.loginClickHandler);
    p.initForFanli();
};

p.sendCodeHandler = function(){
    if($(this).hasClass(misc.vars.disable)){
        return;
    }
    var telText =  $('.tel-block input');
    var telVal = telText.val();
    if(!telVal){
        telText.focus();
        return;
    }
    if(!misc.validatePhone(telVal)){
        misc.warmTip('ierror', '手机号不合规定！');
        return;
    }
    $(this).addClass(misc.vars.disable);
    var postData = {
        mobile:telVal
    };
    var that = $(this);
    $('.code-block a').text('发送中...');
    misc.ajax.CDPOST(0, misc.api.get_verify_code, postData, function(){
        p.timerKey = setInterval(p.timerHandler.bind(p), 1000);
        p.timerHandler();
    }, function(err){
        that.removeClass(misc.vars.disable);
        misc.warmTip('ierror', err);
    });
};

p.timerHandler = function(){
    $('.code-block a').text('再次发送('+this.timeLimit+'）');
    this.timeLimit--;
    if(this.timeLimit < 0){
        clearInterval(this.timerKey);
        this.timeLimit = this.TOTAL_TIME;
        $('.code-block a').text('发送验证码');
        $('.code-block a').removeClass(misc.vars.disable);
    }
};

p.loginClickHandler = function(){
    var telText =  $('.tel-block input');
    var telVal = telText.val();
    var alertStr = '';
    if(!telVal){
        telText.focus();
        return;
    }
    if(!misc.validatePhone(telVal)){
        misc.warmTip('ierror', '手机号不合规定！');
        return;
    }
    var codeText =  $('.code-block input');
    var codeVal = codeText.val();
    if(!codeVal){
        codeText.focus();
        return;
    }
    if(codeVal.length != p.codeLen){
        misc.warmTip('ierror', '请输入6位数字验证码！');
        return;
    }
    p.btnText($(this), '正在登录...', 0);
    $(this).addClass(misc.vars.disable);
    var that = $(this);
    var postData = {
        mobile:telVal,
        code:codeVal,
        src: 1
    };
    misc.ajax.CDPOST(0, misc.api.check_mobile_login, postData, function(result){
        if(result.code == 0){
            misc.clearCookie('_tk');
            misc.clearCookie('uid');
            misc.setCookie('uid',result.data.id,30);
            var referrer=document.referrer;
            if(~referrer.indexOf('/info?id=')||~referrer.indexOf('/my')||~referrer.indexOf('activities')||~referrer.indexOf('/draw')){
                location.replace(referrer)
            }else{
                location.replace(misc.vars.base+'index')
            }
        }else{
            alertStr = result.msg;
            misc.warmTip('ierror', alertStr);
            p.btnText(that, '快速登录', 0);
            that.removeClass(misc.vars.disable);
        }
    }, function(err){
        misc.warmTip('ierror', err);
        p.btnText(that, '快速登录', 0);
        that.removeClass(misc.vars.disable);
    });
};

p.btnText = function(element,s,time){
    time = time ? time : (time==0?0:600);
    setTimeout(function(){
        element.text(s);
    },time);
};

p.initForFanli = function(){
    var isFanli = misc.getCookie('aff') == 'linkhaitao';
    if(!isFanli){
        return;
    }
    $('.logo').addClass('hide');
    $('.logo-text').removeClass('hide');
};