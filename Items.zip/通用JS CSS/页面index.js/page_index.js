var p={};
p.init=function(){
	p.initVar();
	p.initLoad();
	p.initForFanli();
};
p.initVar=function(){
	trackParam={
		activity_platform:"55zhigou",
		activity_page:"index"
	};
	p.template={
		sales:function(ds){
			return ds.map(function(d,i) {
				var tempParam = misc.cloneObj(trackParam);
				tempParam.activity_code="首页_潮流风尚_"+d.uri.replace("55haitao://","")+"_";
				tempParam=misc.getTrackParams(tempParam);
				return [
					'<a href="',misc.getUrlBySchemeUri(d.uri),"?",tempParam,"&activity_position=",i+1,'" class="icon isale" style="background-image: url(',d.image,');" data-name="',d.name,'"><i></i></a>',
	                '<div class="goods-box"><div class="goods-panel">',
	                	p.template.goods(d.items,5,0.5,false,tempParam),
					'</div></div>'
				].join(misc.vars.empty);
			}).join(misc.vars.empty);
		},
		goods:function(ds,width,mRight,needPrice,trackParam){
			return [
				'<div class="goods" style="width:',(Math.ceil((ds.length*(width+mRight)-mRight)*fontSize)),'px">',
					ds.map(function(d,i) {
						var name=misc.vars.empty;
						name+=d.name||misc.vars.empty;
						name+=d.title||misc.vars.empty;
						return [
							'<a class="good" href="',misc.vars.base,"info?id=",d.spuid,trackParam,d.spuid,"&activity_position=",i+1,'">',
								'<div class="icon img" data-origin="',d.img_cover||d.coverImgUrl,'" data-echo-background="',misc.getImgUrlCDN(d.img_cover,misc.vars.thumb(200))||d.coverImgUrl,'"></div>',
								'<div class="name text-elip">',d.brand,'</div>',
								'<div class="name text-elip color">',name,'</div>',
								needPrice?[
									'<div class="price">',
										'<span class="real">¥',misc.centToYuan(d.realPrice),'</span>',
										d.realPrice!==d.mallPrice?['<span class="origin">&nbsp;¥',misc.centToYuan(d.mallPrice),'&nbsp;</span>'].join(misc.vars.empty):misc.vars.empty,
									'</div>'
								].join(misc.vars.empty):[
									'<div class="price">',
										'<span class="real">¥',misc.centToYuan(d.real_price),'</span>',
										d.real_price!==d.mall_price?['<span class="origin">&nbsp;¥',misc.centToYuan(d.mall_price),'&nbsp;</span>'].join(misc.vars.empty):misc.vars.empty,
									'</div>'
								].join(misc.vars.empty),
							'</a>'
						].join(misc.vars.empty);
					}).join(misc.vars.empty),
				'</div>'
			].join(misc.vars.empty);
		},
		banners:function(ds){
			return [
				ds.map(function(d,i) {
					var tempParam = misc.cloneObj(trackParam);
					tempParam.activity_code="首页_轮播Banner_"+d.uri.replace("55haitao://","")+"_";
					tempParam.activity_position=i+1;
					tempParam=misc.getTrackParams(tempParam);
					return ['<li><a href="',misc.getUrlBySchemeUri(d.uri),"?",tempParam,'" class="icon good" style="background-image:url(',d.image,')"></a></li>'].join('');
				}).join('')
			].join(misc.vars.empty);
		}
	};
    lk_aff=misc.getParam('aff');
    lk_to=misc.getParam('to');
    lk_trackid=misc.getParam('trackid');
    lk_aff && misc.setCookie('aff',lk_aff,30);
    lk_trackid && misc.setCookie('trackid',lk_trackid,30);
    lk_to && misc.setCookie('to',lk_to,30);
};
p.initLoad=function(){
	$.ajax({
		url: misc.api.index,
		type: 'GET',
		data: {},
		success:function(res) {
			p.json=JSON.parse(res);
			p.initRender();
		},
		error:function(err) {
			console.log("error");
		},
		complete:function(xhr) {
			console.log("complete");
		}
	});

};
p.initRender=function(){
	misc.loadingHide();
	banner_data=p.json.data.filter(function(d){return d.module=="banner"})[0];
	p.renderBanners(banner_data.body.data);
	hot_goods_data=p.json.data.filter(function(d){return d.module=="热卖单品"})[0];
	p.renderHotGoods(hot_goods_data.body.data);
	hot_sales_data=p.json.data.filter(function(d){return d.module=="潮流风尚"})[0];
	p.renderHotSales(hot_sales_data.body.data.entries);
	echo.init({
	    offset: 0, 
	    throttle: 0 
	});
	$('.outwrap').css("visibility","visible");
	$('.goods-panel').scroll(function(event) {
		echo.render();
	});
};
p.renderHotSales=function(ds){
	$('.j_hot_sales').append(p.template.sales(ds));	
};
p.renderHotGoods=function(ds){
	var tempParam = misc.cloneObj(trackParam);
	tempParam.activity_code="首页_热卖单品_";
	tempParam=misc.getTrackParams(tempParam);
	$('.j_hot_goods').html(p.template.goods(ds,7,0.5,true,tempParam));

};
p.renderBanners=function(ds) {
	$('.j_banners').html(p.template.banners(ds));
	if(ds.length>1){
		TouchSlide({ 
			slideCell: "#slideBox",
			titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			mainCell:".bd ul", 
			effect:"leftLoop", 
			autoPage: true, //自动分页
			autoPlay: true, //自动播放
			delayTime: 100,
			interTime: 4000,
		});
	}
	else{
		$('.hd').hide();
	}
};
p.initForFanli = function(){
	var isFanli = misc.getCookie('aff') == 'linkhaitao';
	if(!isFanli){
		return;
	}
	$('.j_fixed_top').remove();
	// $('.buy-notice').click(function(e){
	// 	e.preventDefault();
	// 	return false;
	// });
};
// p.initForFanli=function(){
// 	$('.ilogohome').css('background-image','url(https://www.linkhaitao.com/static/images/logo.png)');
// };


// $('#id').html(p.template.sales(ds));
// 直接引用就可以了