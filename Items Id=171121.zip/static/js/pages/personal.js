p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$assetList = $('#assetList')
	assetList = [
		{
			dollar1:'2.22',
			dollar2:'3.33',
			dollar3:'5.55',
			dollar4:'6.66',
			dollar5:'222222.22'
		},
	]
}
p.render = function(){
		p.assetListRender(assetList)
}

p.assetListRender = function(datas){
	$assetList.append(datas.map(function(data,index){
		return p.assetListItem(data,index)
	}).join(''))
}

p.assetListItem = function(data,index){
	return [
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/yugufanxian.png" class="yugufanxian">',
				'<div class="assetText"> ',
					'<span>本期预估返现</span>',
					'<span class="meiYuan">',data.dollar1,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="rightList">',
				'<img src="../static/images/pages/personal/tuijianfeileiji.png" class="tuijianfeileiji">',
				'<div class="assetText"> ',
					'<span>推荐费累计</span>',
					'<span class="meiYuan">',data.dollar2,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/jiaoyifeileiji.png" class="jiaoyifeileiji">',
				'<div class="assetText"> ',
					'<span>交易费累计返现</span>',
					'<span class="meiYuan">',data.dollar3,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="rightList">',
				'<img src="../static/images/pages/personal/chenggongtixian.png" class="chenggongtixian">',
				'<div class="assetText"> ',
					'<span>已成功提现</span>',
					'<span class="meiYuan">',data.dollar4,' 美元</span>',
				'</div>',
			'</li>',
		'</a>',
		'<a href="">',
			'<li class="leftList">',
				'<img src="../static/images/pages/personal/jifen.png" class="jifen">',
				'<div class="assetText"> ',
					'<span>积分</span>',
					'<span class="meiYuan">',data.dollar5,' 荔枝</span>',
				'</div>',
			'</li>',
		'</a>'
	].join('')
}
