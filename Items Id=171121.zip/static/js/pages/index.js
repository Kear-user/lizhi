p = {}
p.init = function () {
	p.vars()
	p.render()
}
p.vars = function () { // 声明所有变量
	$businessList = $('#businessList')
	businessList = [
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		},
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		},
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		},
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		},
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		},
		{
			logo: '../static/images/pages/index/taihao.png',
			name: 'aaaa',
			text: 'balabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabalabala',
			cover: '../static/images/pages/index/youhuihuodong1.png',
		}
	]
}
p.render = function () { // 声明所有页面渲染
	p.businessListRender(businessList)
}
p.businessListRender = function (datas) {
	$businessList.append(datas.map(function(data,index){
		return p.businessListItem(data,index)
	}).join(''))
}
p.businessListItem = function(data,index) {
	return [
		'<li class="list">',
			'<div class="business_name">',
				'<img src="',data.logo,'">',
				'<span>',data.name,'</span>',
				'<a href="" class="see">查看+</a>',
			'</div>',
			'<div class="act_message">',data.text,'</div>',
			'<a href=""><img src="',data.cover,'" class="act_icon"></a>',
			'<div class="act_time">2017/09/11-2017/09/21</div>',
		'</li>'
	].join('')
}
// p.render
// return [
// 	'<li class="menu">',
// 		'<div class="menu_m">',
// 			'<a href="">',
// 				'<img src="../static/images/pages/index/home_select.png">',
// 				'<div class="bottom_selectText">首页</div>',
// 			'</a>',
// 		'</div>',
// 	'</li>'
// ].join('')