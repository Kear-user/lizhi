p = {}
p.init = function () {
	p.vars ()
	p.render ()
}
p.vars = function(){
	$businessList = $('#businessList')
	businessList = [
		{
			logo:'../static/images/pages/index/XM.png',
			name:'aaa',
			information:'bbbbbbbbbb',
			cover:'../static/images/pages/index/youhuihuodong2.png',
			time:'2017/09/11-2017/09/21'
		},
		{
			logo:'../static/images/pages/index/XM.png',
			name:'aaa',
			information:'bbbbbbbbbb',
			cover:'../static/images/pages/index/youhuihuodong2.png',
			time:'2017/09/11-2017/09/21'
		},
		{
			logo:'../static/images/pages/index/XM.png',
			name:'aaa',
			information:'bbbbbbbbbb',
			cover:'../static/images/pages/index/youhuihuodong2.png',
			time:'2017/09/11-2017/09/21'
		},
	]
}
p.render = function(){
		p.businessListRender(businessList)
}
p.businessListRender = function(datas){
	$businessList.append(datas.map(function(data,index){
		return p.businessListItem(data,index)
	}).join(''))
}
p.businessListItem = function(data,index){
	return [
		'<li class="list">',
			'<div class="business_name">',
				'<img src="',data.logo,'">',
				'<span >',data.name,'</span>',
				'<a href="" class="see">查看+</a>',
			'</div>',
			'<div class="act_message">',data.information,'</div>',
			'<a href=""><img src="',data.cover,'" class="act_icon"></a>',
			'<div class="act_time">',data.time,'</div>',
		'</li>'
	].join('')
}
